# io_analysis.py: Top-B(20)+BC1 vs A1(20)+BC1의 전체 물리 I/O (최초 Fetch + C2 추가 Fetch), 로그 기반 계산. CPU만.
# 실행: python -B -I scripts/io_analysis.py
import os, sys, re, json, unicodedata, numpy as np, pandas as pd
sys.path.insert(0, '/workspace/jaeeun/sel_fetch_c2x/scripts')
from pf3_rules import select          # c2x에서 복사한 C2 규칙 (md5 2754643f)
IO = '/workspace/jaeeun/sel_fetch_io'; OUT = f'{IO}/results'; C2X = '/workspace/jaeeun/sel_fetch_c2x'
V2D = '/workspace/jaeeun/sel_fetch_v2/sel_fetch/data'; STORE = '/workspace/jaeeun/sel_fetch/data/chunk_store_seq.bin'; PF = '/workspace/junlim/pf3_out'
BLK, B = 4096, 20; A1HP = dict(agg='maxlog', alpha=0.3)   # v2 dev에서 정한 값 그대로
off = np.load(f'{V2D}/chunk_store_off.npy'); doc = np.load(f'{V2D}/chunk_meta.npz')['doc_idx']; ntok = np.load(f'{C2X}/results/chunk_tokens_gpt2.npy')
TOKC = int(round(float(ntok.mean())))
WORD = re.compile(r'\w+', re.UNICODE)
def toks(s):
    s = unicodedata.normalize('NFD', s); s = ''.join(ch for ch in s if unicodedata.category(ch) != 'Mn'); return ' '.join(WORD.findall(s.lower()))
fd = os.open(STORE, os.O_RDONLY); TK = {}
def tk(c):
    if c not in TK: TK[c] = toks(os.pread(fd, int(off[c + 1] - off[c]), int(off[c])).decode('utf-8'))
    return TK[c]
def segments(S):
    out, cur = [], []
    for c in sorted(S):
        if cur and c == cur[-1] + 1 and doc[c] == doc[cur[-1]]: cur.append(c)
        else:
            if cur: out.append(cur)
            cur = [c]
    if cur: out.append(cur)
    return [' ' + ' '.join(tk(c) for c in seg) + ' ' for seg in out]
def has_ans(S, A): return any(a in s for s in segments(S) for a in A)
def blks(cids): return {k for c in cids for k in range(int(off[c]) // BLK, (int(off[c + 1]) - 1) // BLK + 1)}
def extents(bset):
    if not bset: return 0
    b = np.array(sorted(bset)); return 1 + int((np.diff(b) > 1).sum())
def a1_select(cid, ann):
    x = int(round(A1HP['alpha'] * B)); M = np.arange(100) < B - x; d = doc[cid]; u, inv = np.unique(d, return_inverse=True)
    smax = np.full(len(u), -9.0); np.maximum.at(smax, inv, ann); dsc = (smax * np.log1p(np.bincount(inv)))[inv]
    cand = np.where(~M)[0]; o = np.lexsort((-ann[cand], -dsc[cand])); M[cand[o[:x]]] = True; return np.where(M)[0]
def nb_order(R, sel):
    sel = set(sel); out = []
    for p in R:
        for k in (p - 1, p + 1):
            if k in sel and k not in out: out.append(k)
    return out + [k for k in sorted(sel) if k not in out]
def fill(order, T):
    o, t = [], 0
    for c in order:
        if t + ntok[c] > T: break
        o.append(c); t += ntok[c]
    return o, t

def load(setname):
    if setname == 'test':
        rr = pd.read_csv(f'{C2X}/results/test_rerank_top100.csv')
        ANS = {r['q_idx']: [' ' + a + ' ' for a in r['ans']] for r in map(json.loads, open(f'{C2X}/results/test_queries.jsonl', encoding='utf-8'))}; PAS = None
    else:
        rr = pd.read_csv(f'{V2D}/rerank_top100_real.csv'); ANS = {}
        for l in open(f'{PF}/nq_gold.jsonl', encoding='utf-8'):
            r = json.loads(l)
            if r.get('ans'):
                a = [' ' + toks(x) + ' ' for x in r['ans'] if toks(x)]
                if a: ANS[r['qi']] = a
        qr = pd.read_csv(f'{V2D}/qrels_chunk.tsv', sep='\t'); PAS = {}
        for q, c, p in zip(qr.q_idx, qr.chunk_id, qr.corpus_id): PAS.setdefault(q, {}).setdefault(c, set()).add(p)
    return rr.sort_values(['q_idx', 'rank']), ANS, PAS

rows = []
for setname in ('test', 'dev'):
    rr, ANS, PAS = load(setname)
    for q, g in rr.groupby('q_idx'):
        if q not in ANS: continue
        cid = g.chunk_id.values.astype(np.int64); ann = g.ann_score.values; ce = g.ce_score.values; A = ANS[q]
        sel = {'TopB': np.arange(B), 'A1': a1_select(cid, ann)}
        info = {}
        for m, idx in sel.items():
            S = cid[idx]; top10 = list(S[np.argsort(-ce[idx], kind='stable')][:10]); nb = select('BC1', top10, doc)
            info[m] = dict(S=set(S.tolist()), top10=top10, nb=set(nb), nbo=nb_order(top10, nb))
        r0 = dict(set=setname, q=q,
                  S_overlap=len(info['TopB']['S'] & info['A1']['S']), S_docs_TopB=len(set(doc[list(info['TopB']['S'])])), S_docs_A1=len(set(doc[list(info['A1']['S'])])),
                  top10_overlap=len(set(info['TopB']['top10']) & set(info['A1']['top10'])), top10_same_order=float(info['TopB']['top10'] == info['A1']['top10']),
                  top10_docs_TopB=len(set(doc[info['TopB']['top10']])), top10_docs_A1=len(set(doc[info['A1']['top10']])),
                  nb_TopB=len(info['TopB']['nb']), nb_A1=len(info['A1']['nb']), nb_overlap=len(info['TopB']['nb'] & info['A1']['nb']),
                  nb_jacc=len(info['TopB']['nb'] & info['A1']['nb']) / max(len(info['TopB']['nb'] | info['A1']['nb']), 1))
        for m in ('TopB', 'A1'):
            S = info[m]['S']; bS = blks(S)
            # 2단계 통계: 최초 후보끼리 블록 공유, 이웃-부모 같은 블록
            share = sum(1 for c in S if any(blks([c]) & blks([d]) for d in S if d != c)) / len(S)
            par_same = [bool(blks([k]) & blks([p])) for p in info[m]['top10'] for k in (p - 1, p + 1) if k in info[m]['nb']]
            r0.update({f'{m}_S_share_block': share, f'{m}_nb_same_block_as_parent': float(np.mean(par_same)) if par_same else np.nan,
                       f'{m}_first_blocks': len(bS), f'{m}_first_req': extents(bS)})
            for N in (15, 20, None):
                order = info[m]['top10'] + info[m]['nbo']
                final, tot = fill(order, N * TOKC) if N else (order, int(ntok[order].sum()))
                extra = [c for c in final if c not in S]; bE = blks(extra); bnew = bE - bS
                tag = f'{m}_N{N or "inf"}'
                r0.update({f'{tag}_extra': len(extra), f'{tag}_uniq_chunks': len(S | set(extra)), f'{tag}_tokens': int(tot),
                           f'{tag}_c2_blocks_reuse': len(bnew), f'{tag}_c2_req_reuse': extents(bnew),
                           f'{tag}_c2_blocks_noreuse': len(bE), f'{tag}_c2_req_noreuse': extents(bE),
                           f'{tag}_tot_blocks_reuse': len(bS) + len(bnew), f'{tag}_tot_req_reuse': extents(bS) + extents(bnew),
                           f'{tag}_tot_blocks_noreuse': len(bS) + len(bE), f'{tag}_tot_req_noreuse': extents(bS) + extents(bE),
                           f'{tag}_ans': float(has_ans(set(final), A))})
                if PAS is not None:
                    P = PAS.get(q, {}); r0[f'{tag}_pas_any'] = float(any(c in P for c in final))
                    tp = set().union(*[P[c] for c in final if c in P] or [set()]); r0[f'{tag}_pas_recall'] = len(tp) / max(len({p for s in P.values() for p in s}), 1)
        rows.append(r0)
df = pd.DataFrame(rows); df.to_pickle(f'{OUT}/io_per_query.pkl')
def boot(d, n=2000):
    d = np.asarray(d, float); rng = np.random.default_rng(0); m = d[rng.integers(0, len(d), (n, len(d)))].mean(1); return d.mean(), np.quantile(m, .025), np.quantile(m, .975)
summ, pc = [], []
for s, g in df.groupby('set'):
    base = {k: g[k].mean() for k in ('S_overlap', 'S_docs_TopB', 'S_docs_A1', 'top10_overlap', 'top10_same_order', 'top10_docs_TopB', 'top10_docs_A1', 'nb_TopB', 'nb_A1', 'nb_overlap', 'nb_jacc',
                                     'TopB_S_share_block', 'A1_S_share_block', 'TopB_nb_same_block_as_parent', 'A1_nb_same_block_as_parent', 'TopB_first_blocks', 'A1_first_blocks', 'TopB_first_req', 'A1_first_req')}
    base['n_q'] = len(g); base['set'] = s; summ.append(base)
    for N in ('15', '20', 'inf'):
        for metric in ('extra', 'uniq_chunks', 'tokens', 'c2_blocks_reuse', 'c2_req_reuse', 'c2_blocks_noreuse', 'c2_req_noreuse', 'tot_blocks_reuse', 'tot_req_reuse', 'tot_blocks_noreuse', 'tot_req_noreuse', 'ans', 'pas_any', 'pas_recall'):
            a, b = f'A1_N{N}_{metric}', f'TopB_N{N}_{metric}'
            if a not in g: continue
            m_, lo, hi = boot(g[a] - g[b]); pc.append(dict(set=s, N=N, metric=metric, TopB=g[b].mean(), A1=g[a].mean(), diff=m_, lo=lo, hi=hi, rel=m_ / g[b].mean() if g[b].mean() else np.nan))
summ = pd.DataFrame(summ); pc = pd.DataFrame(pc); summ.to_csv(f'{OUT}/structure_summary.csv', index=False); pc.to_csv(f'{OUT}/io_quality_paired.csv', index=False)
# 3단계: IOPS 상한 (계산)
io3 = []
for s, g in df.groupby('set'):
    for N in ('15', '20'):
        for mode in ('reuse', 'noreuse'):
            for m in ('TopB', 'A1'):
                req = g[f'{m}_N{N}_tot_req_{mode}'].mean(); blk = g[f'{m}_N{N}_tot_blocks_{mode}'].mean()
                io3.append(dict(set=s, N=N, mode=mode, method=m, req_per_q=req, blocks_per_q=blk, bytes_per_q=blk * BLK,
                                **{f'qps_cap_iops{L}_req': L / req for L in (1000, 3000, 10000)}, **{f'qps_cap_iops{L}_4k': L / blk for L in (1000, 3000, 10000)}))
io3 = pd.DataFrame(io3)
io3['A1_vs_TopB_qps_req'] = io3.groupby(['set', 'N', 'mode']).req_per_q.transform(lambda x: x.iloc[0] / x.iloc[1] - 1)   # (TopB req / A1 req) - 1 = A1 처리량 상한 증가율
io3['A1_vs_TopB_qps_4k'] = io3.groupby(['set', 'N', 'mode']).blocks_per_q.transform(lambda x: x.iloc[0] / x.iloc[1] - 1)
io3.to_csv(f'{OUT}/iops_cap_calc.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200)
print(summ.round(3).T.to_string()); print(pc.round(4).to_string(index=False)); print(io3.round(3).to_string(index=False))
