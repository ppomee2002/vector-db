# a1io_stage1.py: 1단계 - 파일 저장소 O_DIRECT 실제 읽기 (Fetch 단계만), 동시 요청 N=1,4,16,64, 3회, 순서 섞기, diskstats(loop1)
import os, sys, json, time, mmap, pickle, random, threading, numpy as np, pandas as pd
A = '/workspace/jaeeun/sel_fetch_a1io'; OUT = f'{A}/results'; BLK = 4096
FILES = {'seq': '/workspace/jaeeun/sel_fetch/data/chunk_store_seq.bin', 'rand': '/workspace/jihyeon/c1_w13/store/rand.bin'}
plans = pickle.load(open(f'{OUT}/read_plans_test.pkl', 'rb'))
QS = sorted({k[3] for k in plans}); NS = (1, 4, 16, 64); REPS = 3
FD = {k: os.open(p, os.O_RDONLY | os.O_DIRECT) for k, p in FILES.items()}
def ds():
    for l in open('/proc/diskstats'):
        f = l.split()
        if f[2] == 'loop1': return int(f[3]), int(f[5]) * 512
def run(method, budget, layout, N, qs):
    key = lambda q: (method.replace('_AA', ''), budget, layout, q); fd = FD[layout]
    lat = np.zeros(len(qs)); idx = iter(range(len(qs))); lock = threading.Lock(); app = [0, 0]
    def worker():
        buf = mmap.mmap(-1, 4 << 20); mv = memoryview(buf); nreq = nb = 0
        while True:
            with lock: i = next(idx, None)
            if i is None: break
            ex = plans[key(qs[i])]; t = time.perf_counter()
            for a, b in ex: os.preadv(fd, [mv[:(b - a + 1) * BLK]], a * BLK)
            lat[i] = (time.perf_counter() - t) * 1e3; nreq += len(ex); nb += sum(b - a + 1 for a, b in ex) * BLK
        with lock: app[0] += nreq; app[1] += nb
    d0 = ds(); t0 = time.perf_counter(); th = [threading.Thread(target=worker) for _ in range(N)]
    for t in th: t.start()
    for t in th: t.join()
    wall = time.perf_counter() - t0; d1 = ds()
    return dict(method=method, budget=budget, layout=layout, N=N, n_q=len(qs), app_req=app[0], app_bytes=app[1], dev_reads=d1[0] - d0[0], dev_bytes=d1[1] - d0[1],
                wall_s=wall, qps=len(qs) / wall, p50=float(np.median(lat)), p99=float(np.percentile(lat, 99)), mean=float(lat.mean()))
CONF = [(m, b, 'seq') for m in ('TopB', 'A1', 'TopB_AA') for b in ('S', '15', '20')] + [(m, '15', 'rand') for m in ('TopB', 'A1')]
print('before', os.popen('uptime').read().strip(), flush=True)
a = ds(); time.sleep(10); b = ds(); idle = dict(idle_10s_reads=b[0] - a[0], idle_10s_bytes=b[1] - a[1]); print('idle', idle, flush=True)
run('TopB', '15', 'seq', 4, QS[:500])   # warmup (버림)
rows = []
for rep in range(REPS):
    order = [(c, N) for c in CONF for N in NS]; random.Random(rep).shuffle(order)
    for (m, bud, lay), N in order:
        r = run(m, bud, lay, N, QS); r['rep'] = rep; rows.append(r)
    print('rep', rep, 'done', flush=True)
a = ds(); time.sleep(10); b = ds(); idle.update(idle_after_reads=b[0] - a[0], idle_after_bytes=b[1] - a[1])
pd.DataFrame(rows).to_csv(f'{OUT}/stage1_runs.csv', index=False)
others = os.popen("ps -eo user:12,pcpu,comm --sort=-pcpu --no-headers | awk '$1!=\"vdb01\" && $1!=\"root\"' | head -5").read()
json.dump(dict(idle=idle, others_top=others, reps=REPS, Ns=NS, n_q=len(QS), file_dio=open('/sys/block/loop1/loop/dio').read().strip(),
               cmd='python -B -I scripts/a1io_stage1.py'), open(f'{OUT}/stage1_config.json', 'w'), indent=1)
print('after', os.popen('uptime').read().strip(), idle, flush=True); print('ALL DONE')
