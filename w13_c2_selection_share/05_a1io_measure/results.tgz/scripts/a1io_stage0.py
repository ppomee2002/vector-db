# a1io_stage0.py: 0단계 - 배치 3종(seq, doc, rand) × 방식 2종의 읽기 요청·블록 (오프라인 계산) + 1단계용 읽기 계획 저장
import os, sys, json, time, numpy as np, pandas as pd
sys.path.insert(0, '/workspace/jaeeun/sel_fetch_c2x/scripts')
from pf3_rules import select
A = '/workspace/jaeeun/sel_fetch_a1io'; OUT = f'{A}/results'; C2X = '/workspace/jaeeun/sel_fetch_c2x'
V2D = '/workspace/jaeeun/sel_fetch_v2/sel_fetch/data'; JS = '/workspace/jihyeon/c1_w13/store'
BLK, B = 4096, 20
doc = np.load(f'{V2D}/chunk_meta.npz')['doc_idx']; ntok = np.load(f'{C2X}/results/chunk_tokens_gpt2.npy'); TOKC = int(round(float(ntok.mean())))
seq_off = np.load(f'{V2D}/chunk_store_off.npy'); ln = np.load(f'{JS}/len.npy').astype(np.int64)
LAY = {'seq': (seq_off[:-1], ln), 'doc': (np.load(f'{JS}/doc_off.npy'), ln), 'rand': (np.load(f'{JS}/rand_off.npy'), ln)}
def blks(o, cids): return sorted({k for c in cids for k in range(int(o[c]) // BLK, (int(o[c]) + int(ln[c]) - 1) // BLK + 1)})
def extents(bl):
    if not bl: return []
    b = np.array(bl); cut = np.where(np.diff(b) > 1)[0]; return list(zip(np.r_[b[0], b[cut + 1]].tolist(), np.r_[b[cut], b[-1]].tolist()))
def a1_select(cid, ann):
    x = int(round(0.3 * B)); M = np.arange(100) < B - x; d = doc[cid]; u, inv = np.unique(d, return_inverse=True)
    smax = np.full(len(u), -9.0); np.maximum.at(smax, inv, ann); dsc = (smax * np.log1p(np.bincount(inv)))[inv]
    cand = np.where(~M)[0]; o = np.lexsort((-ann[cand], -dsc[cand])); M[cand[o[:x]]] = True; return np.where(M)[0]
def nb_order(R, sel):
    sel = set(sel); out = []
    for p in R:
        for k in (p - 1, p + 1):
            if k in sel and k not in out: out.append(k)
    return out + [k for k in sorted(sel) if k not in out]
def fill(order, T):
    o, t = [], 0
    for c in order:
        if t + ntok[c] > T: break
        o.append(c); t += ntok[c]
    return o
rows, plans, sel_t = [], {}, []
for setname, path in (('test', f'{C2X}/results/test_rerank_top100.csv'), ('dev', f'{V2D}/rerank_top100_real.csv')):
    rr = pd.read_csv(path).sort_values(['q_idx', 'rank'])
    for q, g in rr.groupby('q_idx'):
        cid = g.chunk_id.values.astype(np.int64); ann = g.ann_score.values; ce = g.ce_score.values
        t = time.perf_counter(); ia = a1_select(cid, ann); sel_t.append(time.perf_counter() - t)
        for m, idx in (('TopB', np.arange(B)), ('A1', ia)):
            S = cid[idx]; top10 = list(S[np.argsort(-ce[idx], kind='stable')][:10]); nbo = nb_order(top10, select('BC1', top10, doc))
            for bud in ('S', 15, 20):
                read = set(S.tolist()) if bud == 'S' else set(S.tolist()) | set(fill(top10 + nbo, bud * TOKC))
                for lay, (o, _) in LAY.items():
                    bl = blks(o, read); ex = extents(bl)
                    rows.append(dict(set=setname, q=q, method=m, budget=str(bud), layout=lay, chunks=len(read), blocks=len(bl), req=len(ex)))
                    if setname == 'test' and lay in ('seq', 'rand'): plans[(m, str(bud), lay, int(q))] = ex
df = pd.DataFrame(rows); df.to_pickle(f'{OUT}/stage0_per_query.pkl')
s = df.groupby(['set', 'budget', 'layout', 'method'])[['chunks', 'blocks', 'req']].mean().unstack('method')
for k in ('blocks', 'req'): s[(k, 'A1_vs_TopB')] = s[(k, 'A1')] / s[(k, 'TopB')] - 1
s.to_csv(f'{OUT}/stage0_summary.csv')
import pickle; pickle.dump(plans, open(f'{OUT}/read_plans_test.pkl', 'wb'))
json.dump(dict(a1_select_ms_mean=float(np.mean(sel_t) * 1e3), a1_select_ms_p99=float(np.percentile(sel_t, 99) * 1e3), n=len(sel_t)), open(f'{OUT}/a1_select_time.json', 'w'), indent=1)
pd.set_option('display.width', 250); print(s.round(4).to_string()); print('A1 select ms', np.mean(sel_t) * 1e3)
