# v3_s1_check.py: 1단계 FiQA 비교 가능성 확인 (CPU, 읽기 전용). 결과: results_v3/s1/
import os, sys, json, numpy as np, pandas as pd, pyarrow as pa
V3 = '/workspace/jaeeun/sel_fetch_v3'; OUT = f'{V3}/results_v3/s1'; os.makedirs(OUT, exist_ok=True)
FJ = '/workspace/junlim/data'; HF = '/workspace/junlim/hf/datasets/mteb___fiqa/default/0.0.0/5e59eeb3a7df6b85882112b747008547c21587ea'
def arrow(p):
    with pa.memory_map(p) as src:
        try: t = pa.ipc.open_stream(src).read_all()
        except Exception: t = pa.ipc.open_file(src).read_all()
    return t.to_pandas()
qrels = {s: arrow(f'{HF}/fiqa-{s}.arrow') for s in ('train', 'dev', 'test')}
print({s: (len(d), d['query-id'].nunique(), list(d.columns)) for s, d in qrels.items()})
ch = pd.read_json(f'{FJ}/chunks.jsonl', lines=True)[['doc_idx', 'doc_id', 'chunk_idx', 'text']]
ch['nw'] = ch.text.str.split().str.len()
q = pd.read_json(f'{FJ}/queries.jsonl', lines=True, dtype={'query_id': str}); q['qi'] = np.arange(len(q))
qid2qi = dict(zip(q.query_id, q.qi)); did2idx = dict(zip(ch.doc_id.astype(str), ch.doc_idx))
rows = []
for s, d in qrels.items():
    d = d.assign(qi=d['query-id'].astype(str).map(qid2qi), doc_idx=d['corpus-id'].astype(str).map(did2idx))
    d[['qi', 'doc_idx', 'score']].dropna().astype({'qi': int, 'doc_idx': int}).assign(split=s).pipe(rows.append)
qr = pd.concat(rows); qr.to_csv(f'{OUT}/fiqa_qrels_doc.csv', index=False)
miss = {s: float(qrels[s]['corpus-id'].astype(str).map(did2idx).isna().mean()) for s in qrels}
# 문서당 chunk 수
cpd_f = ch.groupby('doc_idx').size()
m = np.load('/workspace/jaeeun/sel_fetch_v2/sel_fetch/data/chunk_meta.npz'); cpd_n = pd.Series(np.bincount(m['doc_idx']))
def dist(s): return dict(mean=s.mean(), median=s.median(), p90=s.quantile(.9), frac_1chunk=(s == 1).mean(), frac_ge5=(s >= 5).mean())
gold_docs = qr[qr.split == 'test'].doc_idx.unique()
tab = pd.DataFrame({'NQ (1M chunks)': dist(cpd_n), 'FiQA (all docs)': dist(cpd_f), 'FiQA (test gold docs)': dist(cpd_f[gold_docs])}).T
tab.to_csv(f'{OUT}/chunks_per_doc.csv')
# 질문당 정답 문서 수, 질문 길이
qs = qr.groupby(['split', 'qi']).size().groupby('split').describe()[['count', 'mean', '50%']]
ql_f = q.text.str.split().str.len(); ql_n = pd.read_json('/workspace/junlim/data_nq/queries.jsonl', lines=True).text[:3452].str.split().str.len()
# 검정력: NQ test에서 A1/B1 - TopB (B=20) 질문별 차이의 표준편차
per = pd.read_csv('/workspace/jaeeun/sel_fetch_v2/results_v2/s4/test_per_query.csv.gz')
pw = {}
for mth in ('A1', 'B1', 'M1-noPos'):
    a = per[(per.method == mth) & (per.B == 20)].sort_values('qi').ndcg_dedup.values; b = per[(per.method == 'TopB') & (per.B == 20)].sort_values('qi').ndcg_dedup.values
    sd = float(np.std(a - b, ddof=1));
    for n in (648, 1726):
        pw[f'{mth}_n{n}'] = dict(sd_nq=sd, mde80=2.80 * sd / np.sqrt(n), se=sd / np.sqrt(n))
pw = pd.DataFrame(pw).T; pw.to_csv(f'{OUT}/power.csv')
out = dict(qrels_rows={s: len(d) for s, d in qrels.items()}, qrels_queries={s: int(d['query-id'].nunique()) for s, d in qrels.items()},
           qrels_doc_unmapped_frac=miss, q_per_split=qs.to_dict(), query_words_median=dict(fiqa=float(ql_f.median()), nq=float(ql_n.median())),
           chunk_words_mean=dict(fiqa=float(ch.nw.mean())), n_chunks=len(ch), n_docs=int(ch.doc_idx.nunique()))
json.dump(out, open(f'{OUT}/check.json', 'w'), indent=1, default=float)
pd.set_option('display.width', 200); print(tab.round(3)); print(json.dumps(out, indent=1, default=float)); print(pw.round(4))
