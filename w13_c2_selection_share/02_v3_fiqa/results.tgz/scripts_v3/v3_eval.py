# v3_eval.py: FiQA 비교 (PLAN_v3 고정 규칙). v2 s4_offline.py의 선별 함수를 그대로 옮겨 씀. CPU만 사용.
# 실행: python -B -I scripts_v3/v3_eval.py > results_v3/s3/eval.log 2>&1
import os, sys, json, time, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common_v2 as C
import joblib
V3 = '/workspace/jaeeun/sel_fetch_v3'; OUT = f'{V3}/results_v3/s3'; os.makedirs(OUT, exist_ok=True); FJ = '/workspace/junlim/data'
BS = (10, 15, 20, 30); NQHP = dict(A1=dict(agg='maxlog', alpha=0.3), B1=dict(beta=0.3, gamma=0.05))
# NQ e2e 단가 (v2 results_v2/s42, warm): 임베딩+ANN 고정 9.3ms, Rerank 1.73ms/후보, 추가 Rerank 호출 0.9ms
FIX_MS, RR_MS, CALL_MS = 9.3, 1.73, 0.9
t0 = time.time()
def log(*a): print(f'[{time.time()-t0:6.1f}s]', *a, flush=True)
meta = np.load(f'{V3}/results_v3/fiqa_chunk_meta.npz'); docarr = meta['doc_idx']
rr = C.load_rr(f'{V3}/results_v3', 'rerank_top100_fiqa.csv'); rr = C.add_features(rr, docarr, vec_path=f'{FJ}/chunk_vecs.npy')
qr = pd.read_csv(f'{V3}/results_v3/s1/fiqa_qrels_doc.csv'); qr = qr[qr.split.isin(['dev', 'test'])]
split = qr.groupby('qi').split.first(); gdocs = qr.groupby('qi').doc_idx.apply(set).to_dict()
Q = np.unique(rr.q_idx.values); NQ = len(Q); sh = (NQ, 100); A = lambda c: rr[c].values.reshape(sh)
cid, rank, ann, ce, y, doc = A('chunk_id'), A('rank'), A('ann_score'), A('ce_score'), A('y').astype(bool), A('doc_idx')
gold = np.array([[d in gdocs[q] for d in doc[i]] for i, q in enumerate(Q)])
Vall = np.load(f'{FJ}/chunk_vecs.npy', mmap_mode='r'); ids = np.unique(cid); V = np.asarray(Vall[ids], np.float32); pos = np.searchsorted(ids, cid)
SIM = np.einsum('qid,qjd->qij', V[pos], V[pos]).astype(np.float32); del V
dev_i = np.where(split.reindex(Q).values == 'dev')[0]; test_i = np.where(split.reindex(Q).values == 'test')[0]
log('loaded', NQ, 'dev', len(dev_i), 'test', len(test_i))

def evaluate(M, qsel):
    n = M.sum(1); cem = np.where(M, ce[qsel], -np.inf); order = np.argsort(-cem, 1, kind='stable')[:, :10]; top = np.take_along_axis(M, order, 1)
    out = dict(qi=qsel, n_sel=n, retained=(np.take_along_axis(y[qsel], order, 1) & top).sum(1) / 10)
    ndd = np.zeros(len(qsel)); hit = np.zeros(len(qsel)); pn = np.zeros(len(qsel)); pd_ = np.zeros(len(qsel))
    for k, i in enumerate(qsel):
        seen = set(); dcg = 0.0
        chosen = [order[k, t] for t in range(10) if top[k, t]]
        for r_, j in enumerate(chosen):
            d = doc[i, j]
            if d in gdocs[Q[i]] and d not in seen: dcg += 1 / np.log2(r_ + 2); seen.add(d)
        ng = len(gdocs[Q[i]]); idcg = sum(1 / np.log2(t + 2) for t in range(min(ng, 10)))
        ndd[k] = dcg / idcg if idcg else 0; hit[k] = float(len(seen) > 0)
        nn = int(n[k]); o_ = y[i] & (rank[i] >= nn); pd_[k] = o_.sum(); pn[k] = (o_ & M[k]).sum()
    out.update(ndcg_dedup=ndd, hit10=hit, prom_num=pn, prom_den=pd_); return pd.DataFrame(out)
def summ(df): return dict(n_sel=df.n_sel.mean(), ndcg_dedup=df.ndcg_dedup.mean(), hit10=df.hit10.mean(), retained=df.retained.mean(),
                          prom_recovery=df.prom_num.sum() / max(df.prom_den.sum(), 1))
# ---- 선별 함수 (v2 s4_offline.py와 같은 공식) ----
def m_topk(i, B): return rank[i] < B
def m_score(row, B): M = np.zeros(100, bool); M[np.argsort(-row, kind='stable')[:B]] = True; return M
def m_random_deep(i, B, rng):
    x = int(np.ceil(0.2 * B)); M = rank[i] < B - x; pool = np.where(rank[i] >= B - x)[0]; M[rng.choice(pool, x, replace=False)] = True; return M
def m_A1(i, B, agg, alpha):
    x = int(round(alpha * B)); M = rank[i] < B - x; d = doc[i]; s = ann[i]; u, inv = np.unique(d, return_inverse=True)
    smax = np.full(len(u), -9.0); np.maximum.at(smax, inv, s); cnt = np.bincount(inv)
    dsc = (np.bincount(inv, s) if agg == 'sum' else smax * np.log1p(cnt))[inv]
    cand = np.where(~M)[0]; o = np.lexsort((-s[cand], -dsc[cand])); M[cand[o[:x]]] = True; return M
def feedback_next(i, M, k, beta, gamma):
    sel = np.where(M)[0]; top3 = sel[np.argsort(-ce[i, sel])[:3]]
    f = (1 - beta) * ann[i] + beta * SIM[i][:, top3].max(1) + gamma * np.isin(doc[i], doc[i, top3]); f[M] = -np.inf
    M = M.copy(); M[np.argsort(-f, kind='stable')[:k]] = True; return M
def m_B1(i, B, beta, gamma):
    M = rank[i] < 10
    while M.sum() < B: M = feedback_next(i, M, min(10, B - M.sum()), beta, gamma)
    return M
def build(qsel, fn):
    t = time.perf_counter(); M = np.stack([fn(i) for i in qsel]); return M, (time.perf_counter() - t) / len(qsel) * 1e3
def calls(nm, B): return int(np.ceil(B / 10)) if nm.startswith('B1') else 1

# ---- M1-noPos (a) NQ 학습 모델 그대로, (b) FiQA dev로 학습 ----
m1a = joblib.load('/workspace/jaeeun/sel_fetch_v2/results_v2/s4/m1nopos_dev.joblib')
t = time.perf_counter(); p_a = m1a.predict_proba(rr[C.M1NOPOS_COLS])[:, 1].reshape(sh); ms_a = (time.perf_counter() - t) / NQ * 1e3
dmask = rr.q_idx.isin(Q[dev_i]).values; m1b = C.hgb().fit(rr.loc[dmask, C.M1NOPOS_COLS], rr.y[dmask])
p_b = m1b.predict_proba(rr[C.M1NOPOS_COLS])[:, 1].reshape(sh)
from sklearn.metrics import roc_auc_score
deep_t = (rank[test_i] >= 10)
auc = dict(M1a_test_auc_deep=roc_auc_score(y[test_i][deep_t], p_a[test_i][deep_t]), M1b_test_auc_deep=roc_auc_score(y[test_i][deep_t], p_b[test_i][deep_t]),
           rank_test_auc_deep=roc_auc_score(y[test_i][deep_t], -rank[test_i][deep_t]))
log('AUC', auc)

# ---- FiQA dev 재튜닝 (참고용) ----
tune = []
for agg in ('sum', 'maxlog'):
    for a in (0.2, 0.3, 0.5): M, _ = build(dev_i, lambda i: m_A1(i, 20, agg, a)); tune.append(dict(method='A1', agg=agg, alpha=a, **summ(evaluate(M, dev_i))))
for be in (0.3, 0.5, 0.7, 1.0):
    for ga in (0.0, 0.05): M, _ = build(dev_i, lambda i: m_B1(i, 20, be, ga)); tune.append(dict(method='B1', beta=be, gamma=ga, **summ(evaluate(M, dev_i))))
tune = pd.DataFrame(tune); tune.to_csv(f'{OUT}/tune_fiqa_dev_ref.csv', index=False)
def best(m, keys):
    t_ = tune[tune.method == m]; r = t_[t_.ndcg_dedup >= t_.ndcg_dedup.max() - 1e-12].iloc[0]; return {k: r[k] for k in keys}
FQHP = dict(A1=best('A1', ['agg', 'alpha']), B1=best('B1', ['beta', 'gamma'])); log('FiQA-dev HP (ref)', FQHP)

# ---- 평가: test (주), dev+test (보조, FiQA 데이터 안 쓴 방법만) ----
both_i = np.sort(np.r_[dev_i, test_i])
def run(qsel, include_fiqa_trained):
    rows, per = [], {}
    for B in BS:
        rng = np.random.default_rng(0)
        mm = {'TopB': lambda i: m_topk(i, B), 'A1': lambda i: m_A1(i, B, **NQHP['A1']), 'B1': lambda i: m_B1(i, B, **NQHP['B1']),
              'M1-noPos(a,NQ)': lambda i: m_score(p_a[i], B), 'Random-deep': lambda i: m_random_deep(i, B, rng)}
        if include_fiqa_trained:
            mm.update({'M1-noPos(b,FiQA-dev)': lambda i: m_score(p_b[i], B),
                       'A1(FiQA-tuned,ref)': lambda i: m_A1(i, B, FQHP['A1']['agg'], FQHP['A1']['alpha']),
                       'B1(FiQA-tuned,ref)': lambda i: m_B1(i, B, FQHP['B1']['beta'], FQHP['B1']['gamma'])})
        for nm, fn in mm.items():
            M, ms = build(qsel, fn); ms += ms_a if nm.startswith('M1') else 0
            df = evaluate(M, qsel); per[(nm, B)] = df
            est = FIX_MS + RR_MS * B + CALL_MS * (calls(nm, B) - 1) + ms
            rows.append(dict(method=nm, B=B, sel_ms=ms, rerank_calls=calls(nm, B), est_ms=est, **summ(df)))
    full = evaluate(np.ones((len(qsel), 100), bool), qsel)
    for B in range(1, 101):
        if B in BS: continue
        per[('TopB', B)] = evaluate(np.stack([m_topk(i, B) for i in qsel]), qsel)
    return pd.DataFrame(rows), per, full
res_t, per_t, full_t = run(test_i, True); res_b, per_b, full_b = run(both_i, False)
for res, full in ((res_t, full_t), (res_b, full_b)):
    tb = res[res.method == 'TopB'].set_index('B').est_ms
    res['est_cost_vs_topB'] = res.apply(lambda r: r.est_ms / tb[r.B] - 1, axis=1)
    res['ndcg_full'] = full.ndcg_dedup.mean(); res['hit_full'] = full.hit10.mean()
res_t.to_csv(f'{OUT}/test_summary.csv', index=False); res_b.to_csv(f'{OUT}/devtest_summary.csv', index=False)
pd.set_option('display.width', 250); log('\nTEST\n' + res_t.round(4).to_string(index=False)); log('\nDEV+TEST\n' + res_b.round(4).to_string(index=False))
# ---- 포화 ----
sat = []
for nm_, per, full in (('test', per_t, full_t), ('dev+test', per_b, full_b)):
    for B in (10, 15, 20, 30, 50):
        sat.append(dict(set=nm_, B=B, topB_ndcg=per[('TopB', B)].ndcg_dedup.mean(), full_ndcg=full.ndcg_dedup.mean(),
                        frac=per[('TopB', B)].ndcg_dedup.mean() / full.ndcg_dedup.mean(), topB_hit=per[('TopB', B)].hit10.mean(), full_hit=full.hit10.mean()))
sat = pd.DataFrame(sat); sat.to_csv(f'{OUT}/saturation.csv', index=False); log('\n' + sat.round(4).to_string(index=False))
# ---- paired bootstrap vs Top-B (같은 |S|) ----
ci = []
for setname, per, qsel in (('test', per_t, test_i), ('dev+test', per_b, both_i)):
    for (nm, B), df in per.items():
        if nm == 'TopB' or B not in BS: continue
        base = per[('TopB', B)]; r = dict(set=setname, method=nm, B=B, n_q=len(qsel))
        for metric in ('ndcg_dedup', 'hit10', 'retained'):
            d = df[metric].values - base[metric].values; m_, l_, h_ = C.paired_boot(d)
            r.update({f'd_{metric}': m_, f'd_{metric}_lo': l_, f'd_{metric}_hi': h_, f'se_{metric}': float(np.std(d, ddof=1) / np.sqrt(len(d)))})
        r['prom_recovery'] = df.prom_num.sum() / max(df.prom_den.sum(), 1)
        lo, hi = r['d_ndcg_dedup_lo'], r['d_ndcg_dedup_hi']
        r['verdict'] = ('better' if lo > 0 else 'worse' if hi < 0 else ('undetermined' if (hi - lo) / 2 > 0.006 else 'no difference'))
        ci.append(r)
ci = pd.DataFrame(ci); ci.to_csv(f'{OUT}/ci_vs_topB.csv', index=False)
log('\n' + ci[['set', 'method', 'B', 'd_ndcg_dedup', 'd_ndcg_dedup_lo', 'd_ndcg_dedup_hi', 'd_hit10', 'd_hit10_lo', 'd_hit10_hi', 'prom_recovery', 'verdict']].round(4).to_string(index=False))
# ---- 사례: B=20 test, 이득 큰 질문 ----
qtext = pd.read_json(f'{FJ}/queries.jsonl', lines=True).text.tolist(); ex = []
for nm, fn in (('A1', lambda i: m_A1(i, 20, **NQHP['A1'])), ('B1', lambda i: m_B1(i, 20, **NQHP['B1']))):
    d = per_t[(nm, 20)].ndcg_dedup.values - per_t[('TopB', 20)].ndcg_dedup.values
    for k in np.argsort(-d)[:4]:
        i = test_i[k]; T = rank[i] < 20; Mx = fn(i); new = np.where(Mx & ~T & (gold[i] | y[i]))[0]
        top3 = np.where(rank[i] < 10)[0][np.argsort(-ce[i, rank[i] < 10])[:3]]
        ex.append(dict(method=nm, q=int(Q[i]), question=qtext[Q[i]], d=float(d[k]), new=[dict(ann_rank=int(rank[i, j]), gold=bool(gold[i, j]), ref10=bool(y[i, j]),
                       same_doc_as_topB=bool(doc[i, j] in set(doc[i, T])), sim_top3ce=float(SIM[i, j, top3].max())) for j in new]))
json.dump(ex, open(f'{OUT}/cases_B20.json', 'w'), indent=1, ensure_ascii=False)
# ---- 데이터 특성 비교 (NQ test vs FiQA test) ----
def chars(rank_, ce_rank_, y_, doc_):
    tau = []
    from scipy.stats import kendalltau
    for a, b in zip(rank_, ce_rank_): tau.append(kendalltau(a, b)[0])
    fin = y_; return dict(kendall_tau=float(np.mean(tau)), overlap10=float(((rank_ < 10) & fin).sum(1).mean()),
                          final_from_rank_ge20=float((fin & (rank_ >= 20)).sum() / fin.sum()),
                          ref10_same_doc_as_top20=float(np.mean([np.isin(d[f & (r >= 20)], d[r < 20]).mean() for r, f, d in zip(rank_, fin, doc_) if (f & (r >= 20)).any()])),
                          distinct_docs_top100=float(np.mean([len(set(d)) for d in doc_])))
ce_rank = A('ce_rank'); fq = chars(rank[test_i], ce_rank[test_i], y[test_i], doc[test_i])
nrr = C.load_rr(); sp = C.split_B() if os.path.exists(f'{C.R}/split_B.csv') else None
nt = nrr[nrr.q_idx.isin(sp[sp.split == 'test'].q_idx)]; nsh = (nt.q_idx.nunique(), 100)
nq_ = chars(nt['rank'].values.reshape(nsh), nt.ce_rank.values.reshape(nsh), (nt.ce_rank.values < 10).reshape(nsh), nt.doc_idx.values.reshape(nsh))
dc = pd.DataFrame({'NQ test': nq_, 'FiQA test': fq}); dc.to_csv(f'{OUT}/data_characteristics.csv'); log('\n' + dc.round(4).to_string())
json.dump(dict(env=C.env_info(), NQ_HP=NQHP, FiQA_HP_ref=FQHP, auc=auc, cost_model=dict(fixed_ms=FIX_MS, rerank_ms_per_cand=RR_MS, extra_call_ms=CALL_MS, source='v2 results_v2/s42 warm'),
               cmd='python -B -I scripts_v3/v3_eval.py'), open(f'{OUT}/config.json', 'w'), indent=1, default=float)
pd.concat([df.assign(method=nm, B=B) for (nm, B), df in per_t.items()]).to_csv(f'{OUT}/test_per_query.csv.gz', index=False)
log('ALL DONE')
