# v3_post.py: (1) Rerank 없이 ANN 순위만 쓴 Top-10 품질 (Reranker 도메인 적합성 확인), (2) NQ vs FiQA 곡선 그림
import os, sys, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common_v2 as C
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
V3 = '/workspace/jaeeun/sel_fetch_v3'; OUT = f'{V3}/results_v3/s3'
rr = pd.read_csv(f'{V3}/results_v3/rerank_top100_fiqa.csv').sort_values(['q_idx', 'rank'])
qr = pd.read_csv(f'{V3}/results_v3/s1/fiqa_qrels_doc.csv'); qr = qr[qr.split.isin(['dev', 'test'])]
gd = qr.groupby('qi').doc_idx.apply(set).to_dict(); sp = qr.groupby('qi').split.first()
def dd(docs, g):
    seen = set(); dcg = 0
    for r, d in enumerate(docs[:10]):
        if d in g and d not in seen: dcg += 1 / np.log2(r + 2); seen.add(d)
    return dcg / sum(1 / np.log2(t + 2) for t in range(min(len(g), 10))), float(len(seen) > 0)
rows = []
for q, g in rr.groupby('q_idx'):
    a = dd(g.sort_values('rank').doc_idx.tolist(), gd[q]); f = dd(g.sort_values('ce_rank').doc_idx.tolist(), gd[q])
    rows.append(dict(qi=q, split=sp[q], ann_ndcg=a[0], ann_hit=a[1], ce_full_ndcg=f[0], ce_full_hit=f[1]))
t = pd.DataFrame(rows); s = t.groupby('split')[['ann_ndcg', 'ann_hit', 'ce_full_ndcg', 'ce_full_hit']].mean()
d = (t.ce_full_ndcg - t.ann_ndcg)[t.split == 'test'].values; m, lo, hi = C.paired_boot(d)
s.to_csv(f'{OUT}/ann_only_vs_rerank.csv'); print(s.round(4)); print('test: full rerank - ANN order, dedup nDCG', round(m, 4), [round(lo, 4), round(hi, 4)])
open(f'{OUT}/ann_only_vs_rerank.txt', 'w').write(f'{s.round(4).to_string()}\ntest full-rerank minus ANN-order dedup nDCG: {m:.4f} [{lo:.4f}, {hi:.4f}]\n')
# 그림
nq = pd.read_csv('/workspace/jaeeun/sel_fetch_v2/results_v2/s4/test_summary.csv'); fq = pd.read_csv(f'{OUT}/test_summary.csv')
nqc = pd.read_csv('/workspace/jaeeun/sel_fetch_v2/results_v2/s4/test_topB_curve_per_query.csv.gz').groupby('B')[['ndcg_dedup', 'hit10']].mean()
fqc = pd.read_csv(f'{OUT}/test_per_query.csv.gz'); fqc = fqc[fqc.method == 'TopB'].groupby('B')[['ndcg_dedup', 'hit10']].mean()
COL = {'M1-noPos': '#d62728', 'M1-noPos(a,NQ)': '#d62728', 'M1-noPos(b,FiQA-dev)': '#ff9896', 'A1': '#2ca02c', 'B1': '#1f77b4', 'Random-deep': '#7f7f7f'}
fig, ax = plt.subplots(2, 2, figsize=(13, 9))
for c_, (name, res, cur, full_n) in enumerate((('NQ test (n=1726, passage-dedup)', nq, nqc, None), ('FiQA test (n=648, doc-dedup)', fq, fqc, None))):
    for r_, metric in enumerate(('ndcg_dedup', 'hit10')):
        a = ax[r_, c_]; cc = cur[cur.index <= 60]; a.plot(cc.index, cc[metric], 'k-', label='Top-B'); a.axhline(cur.loc[100, metric], color='k', ls=':', lw=1, label='full Top-100 rerank')
        for m_, col in COL.items():
            dd_ = res[(res.method == m_) & res.B.isin([10, 15, 20, 30])]
            if len(dd_): a.plot(dd_.B, dd_[metric], 'o-', color=col, label=m_, ms=5)
        a.set_title(name, fontsize=10); a.set_xlabel('Rerank candidates |S|'); a.set_ylabel(metric); a.grid(alpha=.3)
ax[0, 0].legend(fontsize=8); ax[0, 1].legend(fontsize=8)
plt.tight_layout(); plt.savefig(f'{OUT}/fig_nq_vs_fiqa.png', dpi=110); print('saved')
