# v3_prep.py: FiQA dev+test -> numpy 정확 검색 Top-100 -> Top-100 전체 Rerank (v2 q1_rerank.py와 같은 모델·설정). GPU0.
# 실행: CUDA_VISIBLE_DEVICES=0 nohup python -B -I scripts_v3/v3_prep.py > results_v3/prep.log 2>&1 &
import os, json, time, numpy as np, pandas as pd
V3 = '/workspace/jaeeun/sel_fetch_v3'; OUT = f'{V3}/results_v3'; FJ = '/workspace/junlim/data'
t0 = time.time()
def log(*a): print(f'[{time.time()-t0:6.1f}s]', *a, flush=True)
qr = pd.read_csv(f'{OUT}/s1/fiqa_qrels_doc.csv'); qr = qr[qr.split.isin(['dev', 'test'])]
QI = np.sort(qr.qi.unique()); log('queries', len(QI), qr.groupby('split').qi.nunique().to_dict())
ch = pd.read_json(f'{FJ}/chunks.jsonl', lines=True); text = ch.text.tolist()
doc = ch.doc_idx.values.astype(np.int64); cix = ch.chunk_idx.values.astype(np.int32); nb = np.array([len(t.encode('utf-8')) for t in text], np.int32)
assert (np.diff(doc) >= 0).all(), 'doc order'
np.savez(f'{OUT}/fiqa_chunk_meta.npz', doc_idx=doc, chunk_idx=cix, nbytes=nb)
V = np.load(f'{FJ}/chunk_vecs.npy', mmap_mode='r'); Q = np.asarray(np.load(f'{FJ}/query_vecs.npy', mmap_mode='r')[QI], dtype=np.float32)
Vf = np.asarray(V, dtype=np.float32); S = Q @ Vf.T                       # (1148, 133919) 정확 내적
top = np.argpartition(-S, 100, axis=1)[:, :100]; ts = np.take_along_axis(S, top, 1); o = np.argsort(-ts, 1, kind='stable')
top = np.take_along_axis(top, o, 1); ts = np.take_along_axis(ts, o, 1); del S
ann = pd.DataFrame(dict(q_idx=np.repeat(QI, 100), rank=np.tile(np.arange(100), len(QI)), chunk_id=top.ravel(), ann_score=ts.ravel()))
ann['doc_idx'] = doc[ann.chunk_id]; ann['chunk_idx'] = cix[ann.chunk_id]; ann['nbytes'] = nb[ann.chunk_id]
log('exact search done')
import torch; from sentence_transformers import CrossEncoder
torch.set_num_threads(4); log('gpu', os.popen('nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv,noheader').read().strip().replace('\n', ' | '))
ce = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2', device='cuda', max_length=256)
qtext = pd.read_json(f'{FJ}/queries.jsonl', lines=True).text.tolist()
rows = []; t1 = time.time()
for k, (q, sub) in enumerate(ann.groupby('q_idx', sort=True)):
    s = ce.predict([(qtext[q], text[c]) for c in sub.chunk_id], batch_size=100, show_progress_bar=False)
    sub = sub.assign(ce_score=np.asarray(s, np.float32)); sub['ce_rank'] = (-sub.ce_score).rank(method='first').astype(int) - 1; rows.append(sub)
    if (k + 1) % 200 == 0: log('reranked', k + 1, f'({(k+1)/(time.time()-t1):.1f} q/s)')
rr = pd.concat(rows); rr.to_csv(f'{OUT}/rerank_top100_fiqa.csv', index=False)
json.dump(dict(n_q=len(QI), search='numpy exact inner product float32 (normalized MiniLM)', reranker='cross-encoder/ms-marco-MiniLM-L-6-v2 max_len 256 batch 100',
               torch=torch.__version__, gpu=torch.cuda.get_device_name(0), rerank_qps=len(QI) / (time.time() - t1),
               cmd='CUDA_VISIBLE_DEVICES=0 python -B -I scripts_v3/v3_prep.py'), open(f'{OUT}/prep_config.json', 'w'), indent=1)
log('ALL DONE')
