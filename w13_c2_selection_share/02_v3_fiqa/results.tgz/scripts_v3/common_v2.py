# common.py: sel_fetch_v2 공통 유틸 (데이터 로드, 피처, C1 블록 비용, 평가, bootstrap)
# 피처 계산은 기존 scripts/q2_predict.py 로직을 그대로 옮겼다 (경로만 v2로 바꿈).
import os, time, json, numpy as np, pandas as pd

V2 = '/workspace/jaeeun/sel_fetch_v2'
D = f'{V2}/sel_fetch/data'                     # tgz에서 푼 데이터 (rerank, ann, meta, qrels, off)
D_OLD = '/workspace/jaeeun/sel_fetch/data'     # 읽기 전용: chunk_store_seq.bin, q_train_minilm.npy
J = '/workspace/junlim/data_nq'                # 읽기 전용: chunk_vecs.npy, queries.jsonl, chunks.jsonl
R = f'{V2}/results_v2'
STORE = f'{D_OLD}/chunk_store_seq.bin'
BLK = 4096
SPLIT_SEED = 20261122
NQ_REAL = 3452

T0 = time.time()
def log(*a): print(f'[{time.time()-T0:7.1f}s]', *a, flush=True)

def load_meta():
    m = np.load(f'{D}/chunk_meta.npz'); off = np.load(f'{D}/chunk_store_off.npy')
    return m['doc_idx'], m['chunk_idx'], m['nbytes'], off

def split_B():
    """(B) 분할: 3,452개를 seed로 섞어 앞 1,726 dev, 뒤 1,726 test. 파일로 고정."""
    p = f'{R}/split_B.csv'
    if os.path.exists(p):
        return pd.read_csv(p)
    perm = np.random.default_rng(SPLIT_SEED).permutation(NQ_REAL); h = NQ_REAL // 2
    df = pd.DataFrame(dict(q_idx=perm, split=['dev'] * h + ['test'] * (NQ_REAL - h))).sort_values('q_idx')
    df.to_csv(p, index=False); return df

def load_rr(D_=D, rr_file='rerank_top100_real.csv'):
    rr = pd.read_csv(f'{D_}/{rr_file}').sort_values(['q_idx', 'rank']).reset_index(drop=True)
    rr['y'] = (rr.ce_rank < 10).astype(np.int8)
    return rr

def add_features(rr, docarr, vec_path=f'{J}/chunk_vecs.npy'):
    """q2_predict.py의 F0 + FDOC + FEMB + f_nbytes (동일 공식)."""
    N = len(docarr); doc_len = np.bincount(docarr)
    g = rr.groupby('q_idx')
    s1 = g.ann_score.transform('max')
    rr['f_rank'] = rr['rank']; rr['f_score'] = rr.ann_score; rr['f_gap_top1'] = s1 - rr.ann_score
    rr['f_rel_score'] = rr.ann_score / s1
    rr['f_z'] = (rr.ann_score - g.ann_score.transform('mean')) / (g.ann_score.transform('std') + 1e-6)
    rr['f_q_s1'] = s1; rr['f_q_gap10'] = s1 - g.ann_score.transform(lambda x: x.iloc[9])
    rr['is_top10'] = (rr['rank'] < 10).astype(int)
    gd = rr.groupby(['q_idx', 'doc_idx'])
    rr['f_doc_hits'] = gd['rank'].transform('size')
    rr['f_doc_hits_top10'] = gd.is_top10.transform('sum')
    rr['f_doc_best_rank'] = gd['rank'].transform('min')
    rr['f_doc_score_sum'] = gd.ann_score.transform('sum')
    rr['f_doc_rank_within'] = gd['rank'].rank(method='first') - 1
    rr['f_chunk_pos'] = rr.chunk_idx
    rr['f_doc_len'] = doc_len[rr.doc_idx.values]
    rr['f_rel_pos'] = rr.chunk_idx / np.maximum(rr.f_doc_len - 1, 1)
    rr['f_first_chunk'] = (rr.chunk_idx == 0).astype(int)
    key = rr.q_idx.values.astype(np.int64) * 10**8 + rr.chunk_id.values
    rank_of = pd.Series(rr['rank'].values, index=key)
    def nb_rank(o):
        nid = rr.chunk_id.values + o; ok = (nid >= 0) & (nid < N)
        same = np.zeros(len(rr), bool); same[ok] = docarr[nid[ok]] == rr.doc_idx.values[ok]
        r = rank_of.reindex(rr.q_idx.values.astype(np.int64) * 10**8 + nid).values.astype(float)
        return np.where(same, r, np.nan)
    nbmin = np.fmin(nb_rank(-1), nb_rank(1))
    rr['f_nb_in_cand'] = (~np.isnan(nbmin)).astype(int)
    rr['f_nb_best_rank'] = np.where(np.isnan(nbmin), 200, nbmin)
    ids = np.unique(rr.chunk_id.values)
    V = np.asarray(np.load(vec_path, mmap_mode='r')[ids], dtype=np.float32)
    pos = np.searchsorted(ids, rr.chunk_id.values)
    cen10 = np.zeros(len(rr), np.float32); maxhi = np.zeros(len(rr), np.float32)
    sim1 = np.zeros(len(rr), np.float32); meanall = np.zeros(len(rr), np.float32)
    low = None
    for q, idx in g.indices.items():
        X = V[pos[idx]]; S = X @ X.T; n = len(idx)
        if low is None or low.shape[0] != n: low = np.tri(n, k=-1, dtype=bool)
        np.fill_diagonal(S, np.nan)
        cen10[idx] = np.nanmean(S[:, :10], 1)
        mh = np.where(low, S, -np.inf).max(1); mh[0] = 0; maxhi[idx] = mh
        sim1[idx] = np.nan_to_num(S[:, 0], nan=1.0)
        meanall[idx] = np.nanmean(S, 1)
    rr['f_cen10'] = cen10; rr['f_maxsim_higher'] = maxhi; rr['f_sim_top1'] = sim1; rr['f_meansim'] = meanall
    rr['f_nbytes'] = rr.nbytes
    return rr

F0 = ['f_rank', 'f_score', 'f_gap_top1', 'f_rel_score', 'f_z', 'f_q_s1', 'f_q_gap10']
FDOC = ['f_doc_hits', 'f_doc_hits_top10', 'f_doc_best_rank', 'f_doc_score_sum', 'f_doc_rank_within', 'f_chunk_pos',
        'f_doc_len', 'f_rel_pos', 'f_first_chunk', 'f_nb_in_cand', 'f_nb_best_rank']
FEMB = ['f_cen10', 'f_maxsim_higher', 'f_sim_top1', 'f_meansim']
POS = ['f_chunk_pos', 'f_rel_pos', 'f_first_chunk', 'f_doc_len']
M1_COLS = F0 + FDOC + FEMB + ['f_nbytes']
M1NOPOS_COLS = [c for c in M1_COLS if c not in POS]

def hgb():
    from sklearn.ensemble import HistGradientBoostingClassifier
    return HistGradientBoostingClassifier(max_iter=300, learning_rate=0.05, max_leaf_nodes=31, early_stopping=False, random_state=0)

def oof(rr, cols, make=hgb, n_splits=5):
    from sklearn.model_selection import GroupKFold
    p = np.zeros(len(rr))
    for tr, te in GroupKFold(n_splits=n_splits).split(rr, rr.y, rr.q_idx):
        m = make().fit(rr.iloc[tr][cols], rr.y.iloc[tr]); p[te] = m.predict_proba(rr.iloc[te][cols])[:, 1]
    return p

# ---------------- C1 블록 비용 ----------------
def block_ranges(off, cid):
    s = off[cid]; e = off[cid + 1] - 1
    return s // BLK, e // BLK

def c1_cost(b0, b1):
    """선택된 chunk들의 블록 범위 (b0,b1 배열) → (블록 수, extent 수)."""
    if len(b0) == 0: return 0, 0
    bl = np.unique(np.concatenate([np.arange(a, b + 1) for a, b in zip(b0, b1)]))
    return len(bl), 1 + int(np.sum(np.diff(bl) > 1))

# ---------------- 평가 ----------------
def ndcg10_list(ids, rel):
    dcg = sum(1 / np.log2(i + 2) for i, c in enumerate(ids[:10]) if c in rel)
    idcg = sum(1 / np.log2(i + 2) for i in range(min(len(rel), 10)))
    return dcg / idcg if idcg else 0.0

class Evaluator:
    """질문별 배열로 미리 정리해서 정책 평가를 빠르게 한다. rr은 (q_idx, rank) 정렬, 질문마다 100행."""
    def __init__(self, rr, off, qrels=None):
        self.q = np.unique(rr.q_idx.values); nq = len(self.q); K = 100
        assert len(rr) == nq * K
        sh = (nq, K)
        self.cid = rr.chunk_id.values.reshape(sh); self.ce = rr.ce_score.values.reshape(sh)
        self.y = rr.y.values.reshape(sh).astype(bool); self.rank = rr['rank'].values.reshape(sh)
        self.doc = rr.doc_idx.values.reshape(sh)
        b0, b1 = block_ranges(off, rr.chunk_id.values); self.b0 = b0.reshape(sh); self.b1 = b1.reshape(sh)
        self.qi = {q: i for i, q in enumerate(self.q)}
        self.rel = None
        if qrels is not None:
            self.rel = [qrels.get(q, set()) for q in self.q]
            self.gold = np.array([[c in self.rel[i] for c in self.cid[i]] for i in range(nq)])

    def eval_mask(self, M, with_cost=True):
        """M: (nq,100) bool 선택 마스크 → 질문별 지표 DataFrame."""
        nq = len(self.q); out = dict(q_idx=self.q, n_sel=M.sum(1))
        ce = np.where(M, self.ce, -np.inf); order = np.argsort(-ce, 1, kind='stable')[:, :10]
        top = np.take_along_axis(M, order, 1)  # 선택된 것만 유효
        fin_y = np.take_along_axis(self.y, order, 1) & top
        out['retained'] = fin_y.sum(1) / 10
        if self.rel is not None:
            fg = np.take_along_axis(self.gold, order, 1) & top
            out['hit10'] = fg.any(1).astype(float)
            nd = np.zeros(nq)
            for i in range(nq):
                ids = [self.cid[i, j] for j, t in zip(order[i], top[i]) if t]
                nd[i] = ndcg10_list(ids, self.rel[i])
            out['ndcg10'] = nd
            out['gold_fetched'] = (self.gold & M).any(1).astype(float)
        if with_cost:
            blk = np.zeros(nq, int); ext = np.zeros(nq, int)
            for i in range(nq):
                s = M[i]; blk[i], ext[i] = c1_cost(self.b0[i, s], self.b1[i, s])
            out['blocks'] = blk; out['extents'] = ext; out['bytes'] = blk * BLK
        return pd.DataFrame(out)

    def mask_topk_by(self, score, B):
        """score (nq,100) 높은 순 상위 B개."""
        o = np.argsort(-score, 1, kind='stable')[:, :B]
        M = np.zeros_like(self.y); np.put_along_axis(M, o, True, 1); return M

def paired_boot(d, n=2000, seed=0):
    d = np.asarray(d, float); rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(d), (n, len(d))); m = d[idx].mean(1)
    return float(d.mean()), float(np.quantile(m, .025)), float(np.quantile(m, .975))

def env_info():
    import sys, platform, sklearn, scipy
    return dict(python=sys.version.split()[0], numpy=np.__version__, pandas=pd.__version__, sklearn=sklearn.__version__,
                scipy=scipy.__version__, host=platform.node(), time_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
