# s4_cost_fig.py: 단가(s1_unit) × |S|·호출 횟수로 Rerank 지연 환산, 포화 곡선 그림. CPU만.
# 실행: python -I scripts/s4_cost_fig.py
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v4common import *
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
OUT = f'{RES}/s4'; os.makedirs(OUT, exist_ok=True)
fit = pd.read_csv(f'{RES}/s1_unit/fit.csv'); summ = pd.read_csv(f'{RES}/s3/summary.csv')
um = pd.read_csv(f'{RES}/s1_unit/summary.csv')
# 호출 1회 지연 = 측정 p50(n)의 구간 선형 보간 (직선 적합은 m3에서 절편이 음수라 분할 호출을 과소평가함).
# n<10은 n=10·20 두 점의 기울기로 외삽 (B1의 B=15 둘째 호출 n=5에만 해당, 표에 표시).
def call_ms(model, n):
    g = um[(um.model == model) & (um.dtype == 'fp16')].sort_values('n'); x, y = g.n.values.astype(float), g.p50.values
    if n >= x[0]: return float(np.interp(n, x, y))
    return float(y[0] + (n - x[0]) * (y[1] - y[0]) / (x[1] - x[0]))
rows = []
for r in summ.itertuples():
    if r.method == 'B1':
        sizes = [10] + [min(10, r.B - 10 - 10 * k) for k in range(int(np.ceil((r.B - 10) / 10)))]
    else:
        sizes = [r.B]
    rows.append(dict(set=r.set, reranker=r.reranker, method=r.method, B=r.B, S=r.B, rerank_calls=len(sizes), sel_ms=r.sel_ms,
                     rerank_ms_est=sum(call_ms(r.reranker, n) for n in sizes), total_sel_plus_rerank_ms=r.sel_ms + sum(call_ms(r.reranker, n) for n in sizes),
                     extrapolated=any(n < 10 for n in sizes),
                     ans=r.ans, ndcg_dedup=r.ndcg_dedup))
cost = pd.DataFrame(rows); cost.to_csv(f'{OUT}/cost.csv', index=False)
print(cost[cost.set == 'test'].round(3).to_string(index=False))
# 포화 곡선
cv = pd.read_csv(f'{RES}/s3/topB_curve.csv'); pre = pd.read_csv(f'{RES}/s3/prereq.csv')
fig, ax = plt.subplots(1, 3, figsize=(15, 4.2))
for k, (sn, metric) in enumerate((('dev', 'ans'), ('dev', 'ndcg_dedup'), ('test', 'ans'))):
    for rk, col in (('minilm', '#4C72B0'), ('m3', '#DD8452')):
        g = cv[(cv.set == sn) & (cv.reranker == rk)].sort_values('B')
        full = pre[(pre.set == sn) & (pre.system == f'full-{rk}')][metric].iloc[0]
        ax[k].plot(g.B, g[metric] / full, marker='.', color=col, label=f'{rk} (full={full:.3f})')
    ax[k].axhline(0.98, ls='--', c='gray', lw=1); ax[k].axvline(20, ls=':', c='gray', lw=1)
    ax[k].set_xscale('log'); ax[k].set_xlabel('B (Top-B = rerank candidates)'); ax[k].set_title(f'{sn}: Top-B / full Top-100 rerank ({metric})')
    ax[k].set_ylim(0.6, 1.05); ax[k].grid(alpha=.3); ax[k].legend(fontsize=8)
plt.tight_layout(); plt.savefig(f'{OUT}/fig_saturation.png', dpi=130)
print('saved', f'{OUT}/fig_saturation.png')
