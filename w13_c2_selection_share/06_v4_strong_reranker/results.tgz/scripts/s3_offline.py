# s3_offline.py: 전제 확인, 포화도, 같은 |S| 비교 (MiniLM vs bge-reranker-v2-m3, dev·test). CPU만.
# 선별 함수(Top-B, A1, B1, Random-deep, M1-noPos)와 평가 공식은 v2 s4_offline.py와 같다. HP는 v2 chosen_hp.json 그대로.
# 실행: cd /workspace/jaeeun/sel_fetch_v4 && source /workspace/jaeeun/sel_fetch_v2/sel_fetch/env.sh && nohup python -I scripts/s3_offline.py > logs/s3.log 2>&1 &
import sys, os, json, time, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v4common import *
OUT = f'{RES}/s3'; os.makedirs(OUT, exist_ok=True)
BS = (10, 15, 20, 30)
HP = json.load(open('/workspace/jaeeun/sel_fetch_v2/results_v2/s4/chosen_hp.json'))
A1_AGG, A1_ALPHA = HP['A1']['agg'], float(HP['A1']['alpha']); B1_BETA, B1_GAMMA = float(HP['B1']['beta']), float(HP['B1']['gamma'])
assert (A1_AGG, A1_ALPHA, B1_BETA, B1_GAMMA) == ('maxlog', 0.3, 0.3, 0.05)
RERANKERS = ('minilm', 'm3')
docarr = meta()[0]; st = Store()
pd.set_option('display.width', 250)

def boot_idx(n, nb=2000, seed=0): return np.random.default_rng(seed).integers(0, n, (nb, n))
def pboot(d):
    d = np.asarray(d, float); m = d[boot_idx(len(d))].mean(1); return float(d.mean()), float(np.quantile(m, .025)), float(np.quantile(m, .975))

# ---------------------------------------------------------------- 데이터
def prepare(name):
    rr, qtext, ans = load_set(name)
    s2 = pd.read_csv(f'{RES}/s2/{name}_scores.csv').sort_values(['q_idx', 'rank']).reset_index(drop=True)
    assert (s2.q_idx.values == rr.q_idx.values).all() and (s2.chunk_id.values == rr.chunk_id.values).all()
    rr['ce_m3'] = s2.ce2_score.values; rr['ce_minilm'] = rr.ce_score.values
    Q = np.unique(rr.q_idx.values); NQ = len(Q); sh = (NQ, 100); A = lambda c: rr[c].values.reshape(sh)
    D = dict(name=name, rr=rr, Q=Q, NQ=NQ, cid=A('chunk_id'), rank=A('rank'), ann=A('ann_score'), doc=A('doc_idx'),
             ce={'minilm': A('ce_minilm'), 'm3': A('ce_m3')})
    D['y'] = {k: np.argsort(np.argsort(-v, 1, kind='stable'), 1, kind='stable') < 10 for k, v in D['ce'].items()}
    # 정답 문자열 (chunk 단위)
    D['ans_eval'] = np.array([q in ans for q in Q]); anshit = np.zeros(sh, bool)
    for i, q in enumerate(Q):
        if q in ans:
            for j in range(100):
                t = ' ' + toks(st.text(D['cid'][i, j])) + ' '; anshit[i, j] = any(a in t for a in ans[q])
    D['anshit'] = anshit
    # qrels (dev만)
    D['gold'] = None
    if name == 'dev':
        qr = pd.read_csv(f'{V2D}/qrels_chunk.tsv', sep='\t'); pas = {}
        for q, c, p in zip(qr.q_idx, qr.chunk_id, qr.corpus_id): pas.setdefault((q, c), set()).add(p)
        D['pas'] = pas; D['npas'] = qr.groupby('q_idx').corpus_id.nunique().to_dict()
        D['gold'] = np.array([[(q, c) in pas for c in D['cid'][i]] for i, q in enumerate(Q)])
    # 후보 간 임베딩 유사도 (B1)
    Vall = np.load(f'{J}/chunk_vecs.npy', mmap_mode='r'); ids = np.unique(D['cid'])
    V = np.asarray(Vall[ids], dtype=np.float32); pos = np.searchsorted(ids, D['cid'])
    D['SIM'] = np.einsum('qid,qjd->qij', V[pos], V[pos]).astype(np.float32)
    log(name, 'prepared', NQ, 'ans_eval', int(D['ans_eval'].sum()), 'answer in top100', int((anshit.any(1) & D['ans_eval']).sum()))
    return D

# ---------------------------------------------------------------- 평가 (v2 evaluate와 같은 공식)
def evaluate(D, M, score):
    """M: (NQ,100) 선택, score: 최종 정렬 점수 (Reranker 점수, ANN 순서면 -rank). 질문별 지표."""
    NQ = D['NQ']; sm = np.where(M, score, -np.inf); order = np.argsort(-sm, 1, kind='stable')[:, :10]
    top = np.take_along_axis(M, order, 1)
    ah = np.take_along_axis(D['anshit'], order, 1) & top
    out = dict(n_sel=M.sum(1), ans=np.where(D['ans_eval'], ah.any(1).astype(float), np.nan))
    if D['gold'] is not None:
        ndd = np.zeros(NQ)
        for i in range(NQ):
            q = D['Q'][i]; seen = set(); dcg = 0.0; r_ = 0
            for t in range(10):
                if not top[i, t]: continue
                j = order[i, t]
                if D['gold'][i, j]:
                    new = D['pas'][(q, D['cid'][i, j])] - seen
                    if new: dcg += 1 / np.log2(r_ + 2); seen |= D['pas'][(q, D['cid'][i, j])]
                r_ += 1
            ip = sum(1 / np.log2(t + 2) for t in range(min(D['npas'].get(q, 0), 10)))
            ndd[i] = dcg / ip if ip else 0.0
        out['ndcg_dedup'] = ndd
    return pd.DataFrame(out)

def prom(D, M, rk, B):
    outside = D['y'][rk] & (D['rank'] >= B); return (outside & M).sum(1), outside.sum(1)

# ---------------------------------------------------------------- 선별 (v2 s4_offline.py 그대로, CE만 교체)
def m_topk(D, i, B): return D['rank'][i] < B
def m_score(sc_row, B):
    M = np.zeros(100, bool); M[np.argsort(-sc_row, kind='stable')[:B]] = True; return M
def m_random_deep(D, i, B, rng):
    x = int(np.ceil(0.2 * B)); M = D['rank'][i] < B - x; pool = np.where(D['rank'][i] >= B - x)[0]; M[rng.choice(pool, x, replace=False)] = True; return M
def m_A1(D, i, B, agg=A1_AGG, alpha=A1_ALPHA):
    x = int(round(alpha * B)); M = D['rank'][i] < B - x
    d = D['doc'][i]; s = D['ann'][i]; u, inv = np.unique(d, return_inverse=True)
    ssum = np.bincount(inv, s); smax = np.full(len(u), -9.0); np.maximum.at(smax, inv, s); cnt = np.bincount(inv)
    dsc = (ssum if agg == 'sum' else smax * np.log1p(cnt))[inv]
    cand = np.where(~M)[0]; o = np.lexsort((-s[cand], -dsc[cand])); M[cand[o[:x]]] = True; return M
def feedback_next(D, ce, i, M, k, beta, gamma):
    sel = np.where(M)[0]; top3 = sel[np.argsort(-ce[i, sel])[:3]]
    f = (1 - beta) * D['ann'][i] + beta * D['SIM'][i][:, top3].max(1) + gamma * np.isin(D['doc'][i], D['doc'][i, top3])
    f[M] = -np.inf; nx = np.argsort(-f, kind='stable')[:k]; M = M.copy(); M[nx] = True; return M
def m_B1(D, ce, i, B, beta=B1_BETA, gamma=B1_GAMMA):
    M = D['rank'][i] < 10
    while M.sum() < B: M = feedback_next(D, ce, i, M, min(10, B - M.sum()), beta, gamma)
    return M
def b1_calls(B): return 1 + int(np.ceil(max(B - 10, 0) / 10))
def build(D, fn):
    t = time.perf_counter(); M = np.stack([fn(i) for i in range(D['NQ'])]); return M, (time.perf_counter() - t) / D['NQ'] * 1e3

# ---------------------------------------------------------------- M1-noPos (라벨 = 해당 Reranker 전체 Top-10, dev로만 학습)
def m1_scores(DV, DT):
    feats = {}
    for D in (DV, DT):
        rr = D['rr'][['q_idx', 'rank', 'chunk_id', 'ann_score', 'doc_idx', 'chunk_idx', 'nbytes']].copy()
        feats[D['name']] = v2c.add_features(rr, docarr)
    out = {}
    for rk in RERANKERS:
        Xd = feats['dev'].copy(); Xd['y'] = DV['y'][rk].ravel().astype(np.int8)
        oof = v2c.oof(Xd, v2c.M1NOPOS_COLS).reshape(DV['NQ'], 100)
        m = v2c.hgb().fit(Xd[v2c.M1NOPOS_COLS], Xd.y)
        t = time.perf_counter(); pt = m.predict_proba(feats['test'][v2c.M1NOPOS_COLS])[:, 1].reshape(DT['NQ'], 100)
        ms = (time.perf_counter() - t) / DT['NQ'] * 1e3
        out[rk] = dict(dev=oof, test=pt, predict_ms=ms); log('M1-noPos', rk, 'trained; predict ms/q', round(ms, 3))
    return out

# ---------------------------------------------------------------- 실행
DV, DT = prepare('dev'), prepare('test')
M1 = m1_scores(DV, DT)
SETS = {'dev': DV, 'test': DT}

# 1) 전제 확인: 전체 Top-100 Rerank vs ANN 순서 vs MiniLM 전체 Rerank
pre, full = [], {}
for sn, D in SETS.items():
    ALL = np.ones((D['NQ'], 100), bool)
    E = {'ANN-order(top10)': evaluate(D, D['rank'] < 10, -D['rank'].astype(float)),
         'full-minilm': evaluate(D, ALL, D['ce']['minilm']), 'full-m3': evaluate(D, ALL, D['ce']['m3'])}
    full[sn] = E
    for k, e in E.items():
        r = dict(set=sn, system=k, ans=np.nanmean(e.ans))
        if 'ndcg_dedup' in e: r['ndcg_dedup'] = e.ndcg_dedup.mean()
        pre.append(r)
    ok = D['ans_eval']
    for a_, b_ in (('full-m3', 'ANN-order(top10)'), ('full-m3', 'full-minilm'), ('full-minilm', 'ANN-order(top10)')):
        r = dict(set=sn, system=f'{a_} − {b_}')
        r['ans'], r['ans_lo'], r['ans_hi'] = pboot((E[a_].ans.values - E[b_].ans.values)[ok])
        if D['gold'] is not None:
            r['ndcg_dedup'], r['ndcg_dedup_lo'], r['ndcg_dedup_hi'] = pboot(E[a_].ndcg_dedup.values - E[b_].ndcg_dedup.values)
        pre.append(r)
pre = pd.DataFrame(pre); pre.to_csv(f'{OUT}/prereq.csv', index=False); log('\n' + pre.round(4).to_string(index=False))

# 2) 선별 비교 (모든 Reranker × 집합 × B × 방법)
per, sel_ms, rows = {}, {}, []
for sn, D in SETS.items():
    for rk in RERANKERS:
        ce = D['ce'][rk]
        for B in BS:
            rng = np.random.default_rng(0)
            meths = {'TopB': lambda i: m_topk(D, i, B), 'A1': lambda i: m_A1(D, i, B), 'B1': lambda i: m_B1(D, ce, i, B),
                     'M1-noPos': lambda i: m_score(M1[rk][sn][i], B), 'Random-deep': lambda i: m_random_deep(D, i, B, rng)}
            for nm, fn in meths.items():
                M, ms = build(D, fn)
                if nm == 'M1-noPos': ms += M1[rk]['predict_ms']
                assert (M.sum(1) == B).all(), (nm, B)
                e = evaluate(D, M, ce); pn, pd_ = prom(D, M, rk, B); e['prom_num'] = pn; e['prom_den'] = pd_
                per[(sn, rk, nm, B)] = e; sel_ms[(sn, rk, nm, B)] = ms
                rows.append(dict(set=sn, reranker=rk, method=nm, B=B, ans=np.nanmean(e.ans), ndcg_dedup=e['ndcg_dedup'].mean() if 'ndcg_dedup' in e else np.nan,
                                 prom_recovery=pn.sum() / max(pd_.sum(), 1), sel_ms=ms, rerank_calls=b1_calls(B) if nm == 'B1' else 1))
        log(sn, rk, 'methods done')
summ = pd.DataFrame(rows); summ.to_csv(f'{OUT}/summary.csv', index=False)

# 3) 포화도: Top-B / 전체 Top-100 Rerank (정답 기준), 비율의 bootstrap CI
sat = []
for sn, D in SETS.items():
    ok = D['ans_eval']; bi = boot_idx(int(ok.sum()))
    for rk in RERANKERS:
        F = full[sn][f'full-{rk}']
        for B in (10, 15, 20, 30):
            T = per[(sn, rk, 'TopB', B)]
            for metric in (('ans', 'ndcg_dedup') if D['gold'] is not None else ('ans',)):
                t = T[metric].values[ok] if metric == 'ans' else T[metric].values; f = F[metric].values[ok] if metric == 'ans' else F[metric].values
                b_ = bi if metric == 'ans' else boot_idx(len(t))
                ratio = t.mean() / f.mean(); rb = t[b_].mean(1) / f[b_].mean(1)
                sat.append(dict(set=sn, reranker=rk, metric=metric, B=B, topB=t.mean(), full=f.mean(), ratio=ratio,
                                ratio_lo=float(np.quantile(rb, .025)), ratio_hi=float(np.quantile(rb, .975))))
sat = pd.DataFrame(sat); sat.to_csv(f'{OUT}/saturation.csv', index=False); log('\n' + sat.round(4).to_string(index=False))

# 4) 같은 |S|에서 Top-B 대비 Δ (전체 / headroom), paired bootstrap
ci = []
for sn, D in SETS.items():
    ok = D['ans_eval']
    for rk in RERANKERS:
        for B in BS:
            hr_ans = ok & D['anshit'].any(1) & ~(D['anshit'] & (D['rank'] < B)).any(1)
            hr_gold = (D['gold'].any(1) & ~(D['gold'] & (D['rank'] < B)).any(1)) if D['gold'] is not None else None
            base = per[(sn, rk, 'TopB', B)]
            for nm in ('A1', 'B1', 'M1-noPos', 'Random-deep'):
                e = per[(sn, rk, nm, B)]
                for sub in ('all', 'headroom'):
                    r = dict(set=sn, reranker=rk, method=nm, B=B, subset=sub)
                    m_ans = ok if sub == 'all' else hr_ans
                    r['n_q_ans'] = int(m_ans.sum())
                    if m_ans.sum():
                        r['d_ans'], r['d_ans_lo'], r['d_ans_hi'] = pboot((e.ans.values - base.ans.values)[m_ans])
                        r['method_ans'] = float(np.nanmean(e.ans.values[m_ans])); r['topB_ans'] = float(np.nanmean(base.ans.values[m_ans]))
                    if D['gold'] is not None:
                        m_g = np.ones(D['NQ'], bool) if sub == 'all' else hr_gold
                        r['n_q_gold'] = int(m_g.sum())
                        r['d_ndcg'], r['d_ndcg_lo'], r['d_ndcg_hi'] = pboot((e.ndcg_dedup.values - base.ndcg_dedup.values)[m_g])
                    pn, pdn = e.prom_num.values, e.prom_den.values
                    mm = ok if sub == 'all' else hr_ans
                    r['prom_recovery'] = pn[mm].sum() / max(pdn[mm].sum(), 1)
                    ci.append(r)
ci = pd.DataFrame(ci); ci.to_csv(f'{OUT}/ci_vs_topB.csv', index=False)
log('\n' + ci[ci.subset == 'all'].round(4).to_string(index=False))

# 5) 판정 (PLAN §6, 기계적으로)
dec = {}
pv = pre.set_index(['set', 'system'])
def lo(sn, sysn): return pv.loc[(sn, sysn), 'ans_lo']
dec['prereq_a_vs_ANN'] = bool(all(lo(s, 'full-m3 − ANN-order(top10)') > 0 for s in ('dev', 'test')))
dec['prereq_b_vs_MiniLM'] = bool(all(lo(s, 'full-m3 − full-minilm') > 0 for s in ('dev', 'test')))
s20 = sat[(sat.reranker == 'm3') & (sat.B == 20)]
dec['saturation_B20_m3'] = {f'{r.set}/{r.metric}': float(r.ratio) for r in s20.itertuples()}
dec['still_saturated'] = bool((s20.ratio >= 0.98).all())
adopt = []
c = ci[(ci.reranker == 'm3') & (ci.subset == 'all')].set_index(['set', 'method', 'B'])
for nm in ('A1', 'B1'):
    for B in BS:
        d = c.loc[('dev', nm, B)]; t = c.loc[('test', nm, B)]
        pass_ans = d.d_ans >= 0.01 and d.d_ans_lo > 0
        pass_nd = d.d_ndcg >= 0.01 and d.d_ndcg_lo > 0
        test_ok = t.d_ans_lo > 0 and (t.d_ans >= 0.01 if (pass_ans and not pass_nd) else True)
        adopt.append(dict(method=nm, B=B, dev_d_ans=d.d_ans, dev_d_ans_ci=[d.d_ans_lo, d.d_ans_hi], dev_d_ndcg=d.d_ndcg,
                          dev_d_ndcg_ci=[d.d_ndcg_lo, d.d_ndcg_hi], test_d_ans=t.d_ans, test_d_ans_ci=[t.d_ans_lo, t.d_ans_hi],
                          dev_pass=bool(pass_ans or pass_nd), test_maintained=bool(test_ok), adopted=bool((pass_ans or pass_nd) and test_ok)))
dec['adoption_checks'] = adopt
dec['verdict'] = ('강한 Reranker 조건에서 학습 없는 선별이 유효' if any(a['adopted'] for a in adopt) else 'Top-B로 충분')
json.dump(dec, open(f'{OUT}/decision.json', 'w'), indent=1, ensure_ascii=False, default=float)
log(json.dumps(dec, ensure_ascii=False, default=float, indent=1))

# 6) 보조: Top-B 곡선 (B=1..100, 정답 기준) — 포화 곡선 그림용
curve = []
for sn, D in SETS.items():
    ok = D['ans_eval']
    for rk in RERANKERS:
        for B in list(range(5, 101, 5)) + [1, 2, 3, 4]:
            e = evaluate(D, D['rank'] < B, D['ce'][rk])
            curve.append(dict(set=sn, reranker=rk, B=B, ans=np.nanmean(e.ans.values[ok]), ndcg_dedup=e['ndcg_dedup'].mean() if 'ndcg_dedup' in e else np.nan))
pd.DataFrame(curve).sort_values(['set', 'reranker', 'B']).to_csv(f'{OUT}/topB_curve.csv', index=False)
pd.concat([df.assign(set=k[0], reranker=k[1], method=k[2], B=k[3]) for k, df in per.items()]).to_csv(f'{OUT}/per_query.csv.gz', index=False)
json.dump(dict(env=env_info(), HP=HP, BS=BS, bootstrap='paired, 2000, seed 0', random_deep_seed=0,
               n=dict(dev=DV['NQ'], test=DT['NQ']), m1_cols=v2c.M1NOPOS_COLS,
               cmd='cd /workspace/jaeeun/sel_fetch_v4 && source /workspace/jaeeun/sel_fetch_v2/sel_fetch/env.sh && python -I scripts/s3_offline.py'),
          open(f'{OUT}/config.json', 'w'), indent=1, ensure_ascii=False, default=float)
log('ALL DONE')
