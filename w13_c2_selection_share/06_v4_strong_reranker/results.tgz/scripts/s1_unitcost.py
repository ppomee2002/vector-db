# s1_unitcost.py: Reranker 후보당 Rerank 시간 (같은 조건: GPU0, max_len 256, 배치 = 후보 수 n, 질문·순서 동일, 모델 교대).
# 정답 품질은 계산하지 않는다 (PLAN §1: 선택은 속도로만).
# 실행 예: CUDA_VISIBLE_DEVICES=0 python -I scripts/s1_unitcost.py --tag select --models minilm,base,m3 --ns 100 --nq 30 --warm 5 --dtypes fp16
import sys, os, json, time, argparse, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v4common import *
import torch
from sentence_transformers import CrossEncoder
MODELS = {'minilm': 'cross-encoder/ms-marco-MiniLM-L-6-v2', 'base': 'BAAI/bge-reranker-base', 'm3': 'BAAI/bge-reranker-v2-m3'}
ap = argparse.ArgumentParser()
ap.add_argument('--tag', required=True); ap.add_argument('--models', default='minilm,base')
ap.add_argument('--ns', default='10,20,30,50,100'); ap.add_argument('--nq', type=int, default=100); ap.add_argument('--warm', type=int, default=10)
ap.add_argument('--dtypes', default='fp16,fp32')
a = ap.parse_args()
torch.set_num_threads(4)
OUT = f'{RES}/s1_{a.tag}'; os.makedirs(OUT, exist_ok=True)
NS = [int(x) for x in a.ns.split(',')]; names = a.models.split(','); dts = a.dtypes.split(',')
rr, qtext, ans = load_set('dev'); st = Store()
qs = np.random.default_rng(1).choice(np.unique(rr.q_idx.values), a.nq + a.warm, replace=False)
cand = {q: rr[rr.q_idx == q].chunk_id.values for q in qs}; txt = {q: [st.text(c) for c in cand[q]] for q in qs}
smi = lambda: os.popen('nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv,noheader').read().strip().replace('\n', ' | ')
log('nvidia-smi before:', smi())
models = {}
for nm in names:
    for dt in dts:
        kw = {'torch_dtype': torch.float16} if dt == 'fp16' else {}
        models[(nm, dt)] = CrossEncoder(MODELS[nm], device='cuda', max_length=256, model_kwargs=kw)
        log('loaded', nm, dt, f'gpu mem alloc {torch.cuda.memory_allocated() / 2**30:.2f} GiB')
rows = []
for k, q in enumerate(qs):
    for n in NS:
        pairs = [(qtext[q], t) for t in txt[q][:n]]
        keys = list(models); keys = keys[k % len(keys):] + keys[:k % len(keys)]   # 순서 교대
        for key in keys:
            torch.cuda.synchronize(); t = time.perf_counter()
            models[key].predict(pairs, batch_size=n, show_progress_bar=False); torch.cuda.synchronize()
            ms = (time.perf_counter() - t) * 1e3
            if k >= a.warm: rows.append(dict(q_idx=int(q), model=key[0], dtype=key[1], n=n, ms=ms))
log('nvidia-smi after:', smi(), '| peak alloc GiB', round(torch.cuda.max_memory_allocated() / 2**30, 2))
df = pd.DataFrame(rows); df.to_csv(f'{OUT}/raw.csv', index=False)
s = df.groupby(['model', 'dtype', 'n']).ms.agg(p50='median', mean='mean', p95=lambda x: np.percentile(x, 95)).reset_index()
fits = []
for (m, d), g in df.groupby(['model', 'dtype']):
    if g.n.nunique() >= 2:
        med = g.groupby('n').ms.median(); b, a0 = np.polyfit(med.index.values, med.values, 1)
        fits.append(dict(model=m, dtype=d, a_ms=a0, b_ms_per_cand=b, est_B20_ms=a0 + 20 * b))
    else:
        med = g.ms.median(); n = g.n.iloc[0]; fits.append(dict(model=m, dtype=d, a_ms=np.nan, b_ms_per_cand=med / n, est_B20_ms=np.nan))
fits = pd.DataFrame(fits)
s.to_csv(f'{OUT}/summary.csv', index=False); fits.to_csv(f'{OUT}/fit.csv', index=False)
json.dump(dict(env=env_info(), gpu=torch.cuda.get_device_name(0), args=vars(a), models={k: MODELS[k] for k in names}, seed=1,
               cmd='CUDA_VISIBLE_DEVICES=0 python -I scripts/s1_unitcost.py ' + ' '.join(sys.argv[1:])),
          open(f'{OUT}/config.json', 'w'), indent=1)
print(s.round(2).to_string(index=False)); print(fits.round(4).to_string(index=False)); log('ALL DONE')
