# v4common.py: sel_fetch_v4 공통 로더. 기존 파일은 읽기만 한다 (v2 common.py를 import해서 재사용).
import os, sys, re, json, time, unicodedata, numpy as np, pandas as pd
sys.path.insert(0, '/workspace/jaeeun/sel_fetch_v2/scripts_v2')
import common as v2c   # noqa: E402  (v2 피처, HGB, paired_boot, Evaluator 공식)

V4 = '/workspace/jaeeun/sel_fetch_v4'; RES = os.environ.get('V4_RES', f'{V4}/results')
V2D = '/workspace/jaeeun/sel_fetch_v2/sel_fetch/data'
C2X = '/workspace/jaeeun/sel_fetch_c2x/results'
J = '/workspace/junlim/data_nq'; PF = '/workspace/junlim/pf3_out'
STORE = '/workspace/jaeeun/sel_fetch/data/chunk_store_seq.bin'
T0 = time.time()
def log(*a): print(f'[{time.time()-T0:7.1f}s]', *a, flush=True)

WORD = re.compile(r'\w+', re.UNICODE)
def toks(s):
    s = unicodedata.normalize('NFD', s); s = ''.join(ch for ch in s if unicodedata.category(ch) != 'Mn')
    return ' '.join(WORD.findall(s.lower()))

_meta = None
def meta():
    global _meta
    if _meta is None:
        m = np.load(f'{V2D}/chunk_meta.npz'); off = np.load(f'{V2D}/chunk_store_off.npy')
        _meta = (m['doc_idx'], m['chunk_idx'], m['nbytes'], off)
    return _meta

class Store:
    def __init__(self):
        self.off = meta()[3]; self.fd = os.open(STORE, os.O_RDONLY)
    def text(self, c):
        c = int(c); return os.pread(self.fd, int(self.off[c + 1] - self.off[c]), int(self.off[c])).decode('utf-8')

def dev_answers():
    """NQ test qi -> 정규화 정답 목록 (평가 가능 2,254개)."""
    ans = {}
    for l in open(f'{PF}/nq_gold.jsonl', encoding='utf-8'):
        r = json.loads(l)
        if r.get('ans'):
            a = [' ' + toks(x) + ' ' for x in r['ans'] if toks(x)]
            if a: ans[int(r['qi'])] = a
    return ans

def load_set(name):
    """(rr DataFrame [q_idx, rank, chunk_id, ann_score, doc_idx, chunk_idx, nbytes, ce_score(MiniLM)], 질문 텍스트 dict, 정답 dict)."""
    doc, cix, nb, off = meta()
    if name == 'dev':
        rr = pd.read_csv(f'{V2D}/rerank_top100_real.csv')
        ans = dev_answers()
        rr = rr[rr.q_idx.isin(list(ans))]
        qt = [json.loads(l)['text'] for l in open(f'{J}/queries.jsonl', encoding='utf-8')][:3452]
        qtext = {q: qt[q] for q in ans}
    elif name == 'test':
        rr = pd.read_csv(f'{C2X}/test_rerank_top100.csv')
        rr['chunk_idx'] = cix[rr.chunk_id.values]; rr['nbytes'] = nb[rr.chunk_id.values]
        qtext, ans = {}, {}
        for l in open(f'{C2X}/test_queries.jsonl', encoding='utf-8'):
            r = json.loads(l); q = int(r['q_idx']); qtext[q] = r['text']
            a = [' ' + toks(x) + ' ' for x in r['ans'] if toks(x)]
            if a: ans[q] = a
    else:
        raise KeyError(name)
    rr = rr.sort_values(['q_idx', 'rank']).reset_index(drop=True)
    assert (rr.groupby('q_idx').size() == 100).all()
    assert (rr.doc_idx.values == doc[rr.chunk_id.values]).all()
    return rr, qtext, ans

def env_info():
    import platform, sklearn, torch, transformers
    return dict(python=sys.version.split()[0], numpy=np.__version__, pandas=pd.__version__, sklearn=sklearn.__version__,
                torch=torch.__version__, transformers=transformers.__version__, host=platform.node(),
                time_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()))
