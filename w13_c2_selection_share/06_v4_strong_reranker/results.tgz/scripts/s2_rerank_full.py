# s2_rerank_full.py: dev(2,254)·test(2,000) Top-100 전체를 새 Reranker로 점수화 (PLAN §1 규칙으로 고른 bge-reranker-v2-m3).
# 조건: GPU0, fp16, max_length 256, 질문당 후보 100개 한 배치. 결과: results/s2/{set}_scores.csv (q_idx, rank, chunk_id, ce2_score, ce2_rank)
# 실행: CUDA_VISIBLE_DEVICES=0 nohup python -I scripts/s2_rerank_full.py > logs/s2.log 2>&1 &
import sys, os, json, time, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from v4common import *
import torch
from sentence_transformers import CrossEncoder
MODEL = 'BAAI/bge-reranker-v2-m3'
OUT = f'{RES}/s2'; os.makedirs(OUT, exist_ok=True)
torch.set_num_threads(4)
ce = CrossEncoder(MODEL, device='cuda', max_length=256, model_kwargs={'torch_dtype': torch.float16})
st = Store()
log('gpu', os.popen('nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv,noheader').read().strip().replace('\n', ' | '))
for name in ('dev', 'test'):
    p = f'{OUT}/{name}_scores.csv'
    if os.path.exists(p):
        log('skip (exists)', p); continue
    rr, qtext, ans = load_set(name); Q = np.unique(rr.q_idx.values)
    cid = rr.chunk_id.values.reshape(len(Q), 100); sc = np.zeros((len(Q), 100), np.float32); t1 = time.time()
    for i, q in enumerate(Q):
        sc[i] = ce.predict([(qtext[q], st.text(c)) for c in cid[i]], batch_size=100, show_progress_bar=False)
        if (i + 1) % 250 == 0: log(name, i + 1, len(Q), f'{(i + 1) / (time.time() - t1):.2f} q/s')
    rk = np.argsort(np.argsort(-sc, 1, kind='stable'), 1, kind='stable')
    pd.DataFrame(dict(q_idx=np.repeat(Q, 100), rank=np.tile(np.arange(100), len(Q)), chunk_id=cid.ravel(),
                      ce2_score=sc.ravel(), ce2_rank=rk.ravel())).to_csv(p + '.tmp', index=False)
    os.replace(p + '.tmp', p); log('saved', p, f'{time.time() - t1:.0f}s')
json.dump(dict(env=env_info(), model=MODEL, dtype='fp16', max_length=256, batch='100 per query', gpu=torch.cuda.get_device_name(0),
               cmd='CUDA_VISIBLE_DEVICES=0 python -I scripts/s2_rerank_full.py'), open(f'{OUT}/config.json', 'w'), indent=1)
log('ALL DONE')
