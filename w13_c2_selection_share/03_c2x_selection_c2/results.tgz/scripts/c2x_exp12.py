# c2x_exp12.py: 실험 1 (Rerank Top-10에 C2 규칙, 대조군 R1~R3, 상한) + 실험 2 (같은 토큰 예산 F1~F4). CPU만.
# 실행: python -B -I scripts/c2x_exp12.py dev|test > results/exp12_<set>.log
import os, sys, re, json, time, unicodedata, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pf3_rules import select, RULES
X = '/workspace/jaeeun/sel_fetch_c2x'; OUT = f'{X}/results'; SET = sys.argv[1]; O = f'{OUT}/{SET}'; os.makedirs(O, exist_ok=True)
V2D = '/workspace/jaeeun/sel_fetch_v2/sel_fetch/data'; STORE = '/workspace/jaeeun/sel_fetch/data/chunk_store_seq.bin'; PF = '/workspace/junlim/pf3_out'
NSEED, BLK, BUDGETS = 20, 4096, (10, 15, 20)
t0 = time.time()
def log(*a): print(f'[{time.time()-t0:7.1f}s]', *a, flush=True)
off = np.load(f'{V2D}/chunk_store_off.npy'); doc = np.load(f'{V2D}/chunk_meta.npz')['doc_idx']; NCH = len(doc)
flags = np.load(f'{PF}/nq_flags.npy'); ntok = np.load(f'{OUT}/chunk_tokens_gpt2.npy')
TOKC = int(round(float(ntok.mean()))); TB = {N: N * TOKC for N in BUDGETS}
doc_start = np.r_[0, np.where(np.diff(doc) != 0)[0] + 1]; doc_end = np.r_[doc_start[1:], NCH]   # doc d: [start, end)
WORD = re.compile(r'\w+', re.UNICODE)
def toks(s):
    s = unicodedata.normalize('NFD', s); s = ''.join(ch for ch in s if unicodedata.category(ch) != 'Mn'); return ' '.join(WORD.findall(s.lower()))
fd = os.open(STORE, os.O_RDONLY); TK = {}
def tk(c):
    if c not in TK: TK[c] = toks(os.pread(fd, int(off[c + 1] - off[c]), int(off[c])).decode('utf-8'))
    return TK[c]
def segments(S):   # analyze_pf3.segments와 같음
    out, cur = [], []
    for c in sorted(S):
        if cur and c == cur[-1] + 1 and doc[c] == doc[cur[-1]]: cur.append(c)
        else:
            if cur: out.append(cur)
            cur = [c]
    if cur: out.append(cur)
    return [' ' + ' '.join(tk(c) for c in seg) + ' ' for seg in out]
def has_ans(S, A): return bool(A) and any(a in s for s in segments(S) for a in A)
def has_ans_chunk(S, A): return bool(A) and any(a in ' ' + tk(c) + ' ' for c in S for a in A)
def blocks(S):
    b = set()
    for c in S: b.update(range(int(off[c]) // BLK, (int(off[c + 1]) - 1) // BLK + 1))
    return b

# ---- 데이터 ----
if SET == 'dev':
    rr = pd.read_csv(f'{V2D}/rerank_top100_real.csv').sort_values(['q_idx', 'rank'])
    gold = {}; ANS = {}
    for l in open(f'{PF}/nq_gold.jsonl', encoding='utf-8'):
        r = json.loads(l)
        if r.get('ans'):
            a = [' ' + toks(x) + ' ' for x in r['ans'] if toks(x)]
            if a: ANS[r['qi']] = a
    qr = pd.read_csv(f'{V2D}/qrels_chunk.tsv', sep='\t'); PAS = {}
    for q, c, p in zip(qr.q_idx, qr.chunk_id, qr.corpus_id): PAS.setdefault(q, {}).setdefault(c, set()).add(p)
    NPAS = qr.groupby('q_idx').corpus_id.nunique().to_dict()
    hits = {json.loads(l)['qi']: json.loads(l)['ids'] for l in open(f'{PF}/hits_nq.jsonl')}
else:
    rr = pd.read_csv(f'{OUT}/test_rerank_top100.csv').sort_values(['q_idx', 'rank'])
    ANS = {r['q_idx']: [' ' + a + ' ' for a in r['ans']] for r in map(json.loads, open(f'{OUT}/test_queries.jsonl', encoding='utf-8'))}
    PAS, NPAS, hits = None, None, None
Qs = sorted(q for q in rr.q_idx.unique() if q in ANS)
G = {q: g for q, g in rr.groupby('q_idx') if q in ANS}
def is_short(A): return any((len(a.split()) <= 2) or a.strip().replace(' ', '').isdigit() for a in A)
SHORT = {q: is_short(ANS[q]) for q in Qs}
log(SET, 'queries with answers', len(Qs), 'short-answer queries', sum(SHORT.values()), 'TOKC', TOKC)

def ce_order(g, B):
    s = g[g['rank'] < B]; return s.sort_values('ce_score', ascending=False).chunk_id.astype(int).tolist()
def nb_order(R, sel):
    """담는 순서 (e): 부모 CE 순위 → 앞 조각 → 뒤 조각. sel에 있는 것만, 한 번씩."""
    sel = set(sel); out = []
    for p in R:
        for k in (p - 1, p + 1):
            if k in sel and k not in out: out.append(k)
    out += [k for k in sorted(sel) if k not in out]
    return out
def passage_metrics(q, S):
    if PAS is None: return {}
    P = PAS.get(q, {}); touched = set().union(*[P[c] for c in S if c in P] or [set()])
    return dict(pas_any=float(bool(touched)), pas_recall=len(touched) / max(NPAS.get(q, 1), 1))
def ctx_metrics(q, S):
    A = ANS[q]; m = dict(ans=float(has_ans(S, A)), ans_chunk=float(has_ans_chunk(S, A)))
    m.update(passage_metrics(q, S)); return m
def pool_R1(g, R): return [int(c) for c in g.chunk_id if int(c) not in set(R)]
def pool_R2(R):
    Rs = set(R); out = []
    for d in sorted(set(doc[R])): out += [c for c in range(doc_start[d], doc_end[d]) if c not in Rs]
    return out
def pool_R3(R): return select('all', R, doc)

# ================= 실험 1 =================
def exp1_input(q, kind):
    g = G[q]
    if kind == 'rerank10_B20': return ce_order(g, 20)[:10]
    if kind == 'ann10': return g.chunk_id.astype(int).tolist()[:10]
    if kind == 'c2_hits_ef64': return [int(c) for c in hits[q]]
rows1, stats_in, curve = [], [], []
kinds = ['rerank10_B20', 'ann10'] + (['c2_hits_ef64'] if SET == 'dev' else [])
for kind in kinds:
    per = []
    for q in Qs:
        R = exp1_input(q, kind); Rs = set(R); A = ANS[q]
        cnt = pd.Series(doc[R]).value_counts()
        stats_in.append(dict(input=kind, q=q, multi_doc_q=float((cnt >= 2).any()), n_docs=len(cnt), n_nb_all=len(pool_R3(R))))
        base_ans = has_ans(Rs, A)
        r = dict(q=q, short=SHORT[q])
        for rule in RULES:
            sel = select(rule, R, doc, flags); S = Rs | set(sel); m = ctx_metrics(q, S)
            for k, v in m.items(): r[f'{rule}:{k}'] = v
            r[f'{rule}:extra'] = len(sel)
        if kind == 'rerank10_B20':
            k = r['BC1:extra']; P1, P2, P3 = pool_R1(G[q], R), pool_R2(R), pool_R3(R)
            for nm, P in (('R1', P1), ('R2', P2), ('R3', P3)):
                acc = {}
                for s in range(NSEED):
                    rng = np.random.default_rng(s); pick = list(rng.choice(P, min(k, len(P)), replace=False)) if k and len(P) else []
                    m = ctx_metrics(q, Rs | set(int(x) for x in pick))
                    for kk, v in m.items(): acc.setdefault(kk, []).append(v)
                for kk, v in acc.items(): r[f'{nm}:{kk}'] = float(np.mean(v)); r[f'{nm}:{kk}:seeds'] = v
            need = has_ans(Rs | set(P3), A) and not base_ans
            Us = Rs | (set(P3) if need else set()); m = ctx_metrics(q, Us)
            for kk, v in m.items(): r[f'U:{kk}'] = v
            r['U:extra'] = len(P3) if need else 0; r['need'] = float(need)
            # 새 정보 분석 (BC1이 정답을 바꾼 경우)
            S = Rs | set(select('BC1', R, doc))
            r['bc1_new_ans'] = float((not base_ans) and has_ans(S, A))
            r['bc1_new_ans_in_chunk'] = float((not base_ans) and has_ans_chunk(S - Rs, A))    # 이웃 chunk 자체에 정답이 있음
            if PAS is not None:
                P = PAS.get(q, {}); top_p = set().union(*[P[c] for c in Rs if c in P] or [set()])
                nb_g = [c for c in S - Rs if c in P]
                r['bc1_gold_nb_complete'] = sum(1 for c in nb_g if P[c] <= top_p); r['bc1_gold_nb_newpas'] = sum(1 for c in nb_g if not P[c] <= top_p)
            # 곡선: R3 k=1..14 (seed 5개)
            for kk in range(1, 15):
                v = []
                for s in range(5):
                    rng = np.random.default_rng(100 + s); pick = rng.choice(P3, min(kk, len(P3)), replace=False) if len(P3) else []
                    v.append(has_ans(Rs | set(int(x) for x in pick), A))
                curve.append(dict(q=q, k=kk, n=min(kk, len(P3)), ans=float(np.mean(v))))
        per.append(r)
    df = pd.DataFrame(per); df.to_pickle(f'{O}/exp1_{kind}.pkl'); log('exp1 done', kind)
pd.DataFrame(stats_in).groupby('input')[['multi_doc_q', 'n_docs', 'n_nb_all']].mean().to_csv(f'{O}/exp1_input_stats.csv')
pd.DataFrame(curve).to_pickle(f'{O}/exp1_curve_R3.pkl')

# ================= 실험 2 =================
def fill(order, T):
    out, tot = [], 0
    for c in order:
        if tot + ntok[c] > T: break
        out.append(c); tot += ntok[c]
    return out, tot
rows2 = []
for q in Qs:
    g = G[q]; A = ANS[q]; top10_B10 = ce_order(g, 10); top10_B20 = ce_order(g, 20)[:10]
    sel10 = select('BC1', top10_B10, doc); sel20 = select('BC1', top10_B20, doc); k = len(sel10)
    P3 = pool_R3(top10_B10); need = has_ans(set(top10_B10) | set(P3), A) and not has_ans(set(top10_B10), A)
    methods = {f'F1_B{B}': (B, ce_order(g, B)) for B in (10, 15, 20, 30)}
    methods['F2_B10_BC1'] = (10, top10_B10 + nb_order(top10_B10, sel10))
    methods['F2p_B20_BC1'] = (20, top10_B20 + nb_order(top10_B20, sel20))
    methods['F4_U_B10'] = (10, top10_B10 + (nb_order(top10_B10, P3) if need else []))
    rnd = {}
    for nm, P in (('R1', pool_R1(g, top10_B10)), ('R2', pool_R2(top10_B10)), ('R3', P3)):
        rnd[nm] = []
        for s in range(NSEED):
            rng = np.random.default_rng(s); pick = [int(x) for x in rng.choice(P, min(k, len(P)), replace=False)] if k and len(P) else []
            rnd[nm].append(top10_B10 + (nb_order(top10_B10, pick) if nm == 'R3' else pick))
    for N in BUDGETS:
        T = TB[N]
        def rec(name, B, order, seed=None):
            S, tot = fill(order, T); SB = set(g.chunk_id.astype(int).tolist()[:B]); extra = [c for c in S if c not in SB]
            b1 = blocks(SB); b2 = blocks(extra) - b1; m = ctx_metrics(q, set(S))
            return dict(q=q, N=N, method=name, seed=seed, B=B, rerank=B, fetched=B + len(extra), extra_fetch=len(extra), final_chunks=len(S), final_tokens=int(tot),
                        blocks_first=len(b1), blocks_extra=len(b2), short=SHORT[q], **m)
        for nm, (B, order) in methods.items():
            if nm.startswith('F1') and B < N and B != 10: continue
            rows2.append(rec(nm, B, order))
        for nm, lst in rnd.items():
            rs = [rec(f'F3_{nm}_B10', 10, o, s) for s, o in enumerate(lst)]
            agg = {kk: (np.mean([x[kk] for x in rs]) if isinstance(rs[0][kk], (int, float, np.floating, np.integer)) and kk not in ('q', 'N', 'seed') else rs[0][kk]) for kk in rs[0]}
            agg['seed'] = -1; agg['seed_ans'] = [x['ans'] for x in rs]; rows2.append(agg)
df2 = pd.DataFrame(rows2); df2.to_pickle(f'{O}/exp2.pkl')
json.dump(dict(set=SET, n_q=len(Qs), TOKC=TOKC, budgets_tokens=TB, nseed=NSEED, n_short=int(sum(SHORT.values()))), open(f'{O}/meta.json', 'w'), indent=1)
log('ALL DONE')
