# c2x_analyze.py: 실험 1·2 요약, paired bootstrap, 그림. 실행: python -B -I scripts/c2x_analyze.py dev|test
import os, sys, json, numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
X = '/workspace/jaeeun/sel_fetch_c2x'; SET = sys.argv[1]; O = f'{X}/results/{SET}'
RR_MS, BLK_MS = 1.73, 0.131      # v2 e2e 단가 (Rerank ms/후보, cold C1 ms/블록)
def boot(d, n=2000, seed=0):
    d = np.asarray(d, float); rng = np.random.default_rng(seed); m = d[rng.integers(0, len(d), (n, len(d)))].mean(1)
    return float(d.mean()), float(np.quantile(m, .025)), float(np.quantile(m, .975))
RULES = ['none', 'A', 'A3', 'B', 'C1', 'C3', 'BC1', 'all']
MET = ['ans', 'ans_chunk', 'pas_any', 'pas_recall']
out = {}
# ---------- 실험 1 ----------
t1 = []
for kind in ('c2_hits_ef64', 'ann10', 'rerank10_B20'):
    p = f'{O}/exp1_{kind}.pkl'
    if not os.path.exists(p): continue
    df = pd.read_pickle(p)
    names = RULES + (['R1', 'R2', 'R3', 'U'] if kind == 'rerank10_B20' else [])
    for nm in names:
        r = dict(input=kind, method=nm, n_q=len(df), extra=df[f'{nm}:extra'].mean() if f'{nm}:extra' in df else df['BC1:extra'].mean())
        for m in MET:
            if f'{nm}:{m}' in df: r[m] = df[f'{nm}:{m}'].mean()
        if f'{nm}:ans:seeds' in df:
            seedm = np.mean(np.stack(df[f'{nm}:ans:seeds'].values), 0); r['ans_seed_min'], r['ans_seed_max'] = seedm.min(), seedm.max()
        t1.append(r)
    if kind == 'rerank10_B20':
        cmp_ = []
        for a, b in (('BC1', 'R3'), ('BC1', 'R2'), ('BC1', 'R1'), ('BC1', 'none'), ('BC1', 'B'), ('U', 'BC1')):
            for sub, msk in (('all', np.ones(len(df), bool)), ('no_short', ~df.short.values)):
                for m in ('ans', 'ans_chunk') + (('pas_recall',) if 'BC1:pas_recall' in df else ()):
                    mm, lo, hi = boot((df[f'{a}:{m}'] - df[f'{b}:{m}']).values[msk]); cmp_.append(dict(cmp=f'{a}-{b}', subset=sub, metric=m, n=int(msk.sum()), diff=mm, lo=lo, hi=hi))
        cmp_ = pd.DataFrame(cmp_); cmp_.to_csv(f'{O}/exp1_paired.csv', index=False); out['exp1_paired'] = cmp_
        newinfo = dict(bc1_changed_ans=df.bc1_new_ans.mean(), bc1_new_ans_neighbor_contains_answer=df.bc1_new_ans_in_chunk.mean(), need_rate=df.need.mean())
        if 'bc1_gold_nb_complete' in df: newinfo.update(gold_nb_complete_passage=int(df.bc1_gold_nb_complete.sum()), gold_nb_new_passage=int(df.bc1_gold_nb_newpas.sum()))
        json.dump(newinfo, open(f'{O}/exp1_newinfo.json', 'w'), indent=1, default=float); out['newinfo'] = newinfo
t1 = pd.DataFrame(t1); t1.to_csv(f'{O}/exp1_summary.csv', index=False); out['exp1'] = t1
if SET == 'dev':   # C2 원래 수치 재현 확인
    c2 = pd.read_csv('/workspace/junlim/pf3_out/pf3_quality_nq.csv'); c2 = c2[c2.subset == 'ans'].set_index('rule')
    mine = t1[t1.input == 'c2_hits_ef64'].set_index('method')
    rep = pd.DataFrame(dict(c2_reported=c2.ans, mine=mine.ans, c2_extra=c2.extra_pks, mine_extra=mine.extra)).loc[RULES]; rep.to_csv(f'{O}/c2_reproduction.csv'); out['repro'] = rep
# 곡선
cur = pd.read_pickle(f'{O}/exp1_curve_R3.pkl').groupby('k')[['n', 'ans']].mean()
df = pd.read_pickle(f'{O}/exp1_rerank10_B20.pkl')
fig, ax = plt.subplots(figsize=(7, 5)); ax.plot(cur.n, cur.ans, 'k-o', ms=3, label='R3 random neighbors (k=1..14)')
for nm in RULES: ax.plot(df[f'{nm}:extra'].mean(), df[f'{nm}:ans'].mean(), 's', ms=7, label=nm)
ax.plot(df['U:extra'].mean(), df['U:ans'].mean(), '*', ms=12, label='U (oracle need)')
ax.set_xlabel('extra chunks per query'); ax.set_ylabel('answer-string hit (C2 join)'); ax.set_title(f'Exp1 [{SET}] input = Rerank Top-10 (B=20)'); ax.grid(alpha=.3); ax.legend(fontsize=7)
plt.tight_layout(); plt.savefig(f'{O}/fig_exp1_rules_vs_R3.png', dpi=110); plt.close()
# ---------- 실험 2 ----------
d2 = pd.read_pickle(f'{O}/exp2.pkl'); d2['blocks_total'] = d2.blocks_first + d2.blocks_extra; d2['est_ms'] = RR_MS * d2.rerank + BLK_MS * d2.blocks_total
cols = ['ans', 'ans_chunk'] + (['pas_any', 'pas_recall'] if 'pas_any' in d2 else []) + ['rerank', 'fetched', 'extra_fetch', 'final_chunks', 'final_tokens', 'blocks_first', 'blocks_extra', 'blocks_total', 'est_ms']
s2 = d2.groupby(['N', 'method'])[cols].mean().reset_index(); s2.to_csv(f'{O}/exp2_summary.csv', index=False); out['exp2'] = s2
pairs = [(15, 'F2_B10_BC1', 'F1_B15'), (20, 'F2_B10_BC1', 'F1_B20'), (15, 'F2p_B20_BC1', 'F1_B20'), (20, 'F2p_B20_BC1', 'F1_B20'),
         (15, 'F2_B10_BC1', 'F3_R3_B10'), (20, 'F2_B10_BC1', 'F3_R3_B10'), (15, 'F2_B10_BC1', 'F3_R1_B10'), (15, 'F2_B10_BC1', 'F3_R2_B10'),
         (15, 'F2_B10_BC1', 'F1_B10'), (20, 'F2_B10_BC1', 'F1_B10'), (10, 'F2_B10_BC1', 'F1_B10'), (15, 'F4_U_B10', 'F2_B10_BC1'), (20, 'F1_B20', 'F1_B10')]
pc = []
for N, a, b in pairs:
    A_ = d2[(d2.N == N) & (d2.method == a)].set_index('q'); B_ = d2[(d2.N == N) & (d2.method == b)].set_index('q'); k = A_.index.intersection(B_.index)
    for sub in ('all', 'no_short'):
        kk = k if sub == 'all' else k[~A_.loc[k, 'short'].astype(bool).values]
        for m in ('ans', 'ans_chunk') + (('pas_recall',) if 'pas_recall' in d2 else ()):
            mm, lo, hi = boot((A_.loc[kk, m] - B_.loc[kk, m]).values)
            pc.append(dict(N=N, cmp=f'{a} - {b}', subset=sub, metric=m, n=len(kk), diff=mm, lo=lo, hi=hi,
                           d_rerank=(A_.loc[kk, 'rerank'] - B_.loc[kk, 'rerank']).mean(), d_blocks=(A_.loc[kk, 'blocks_total'] - B_.loc[kk, 'blocks_total']).mean(),
                           d_est_ms=(A_.loc[kk, 'est_ms'] - B_.loc[kk, 'est_ms']).mean(), d_tokens=(A_.loc[kk, 'final_tokens'] - B_.loc[kk, 'final_tokens']).mean()))
pc = pd.DataFrame(pc); pc.to_csv(f'{O}/exp2_paired.csv', index=False); out['exp2_paired'] = pc
# 그림: 같은 예산 품질 / 같은 품질 비용
fig, ax = plt.subplots(1, 2, figsize=(14, 5))
for meth, st in (('F1_B10', 'k:'), ('F1_B15', 'C0--'), ('F1_B20', 'C0-'), ('F1_B30', 'C0-.'), ('F2_B10_BC1', 'C3-o'), ('F2p_B20_BC1', 'C1-o'), ('F3_R3_B10', 'C7-s'), ('F3_R1_B10', 'C8-^'), ('F3_R2_B10', 'C5-v'), ('F4_U_B10', 'C2-*')):
    t = s2[s2.method == meth]; ax[0].plot(t.N, t.ans, st, label=meth)
ax[0].set_xlabel('final token budget (chunks x %d tokens)' % 86); ax[0].set_ylabel('answer-string hit'); ax[0].set_title(f'Exp2 [{SET}] same token budget'); ax[0].legend(fontsize=7); ax[0].grid(alpha=.3)
f1 = pd.concat([s2[(s2.method == f'F1_B{B}') & (s2.N == min(B, 20))] for B in (10, 15, 20)] + [s2[(s2.method == 'F1_B30') & (s2.N == 20)]])
ax[1].plot(f1.est_ms, f1.ans, 'C0-o', label='F1 (Rerank B=budget; B30@20)')
for N in (15, 20):
    t = s2[(s2.method == 'F2_B10_BC1') & (s2.N == N)]; ax[1].plot(t.est_ms, t.ans, 'C3o', ms=9); ax[1].annotate(f'F2 B10+BC1 @{N}', (t.est_ms.iloc[0], t.ans.iloc[0]), fontsize=8)
    t = s2[(s2.method == 'F3_R3_B10') & (s2.N == N)]; ax[1].plot(t.est_ms, t.ans, 'C7s', ms=7); ax[1].annotate(f'R3 @{N}', (t.est_ms.iloc[0], t.ans.iloc[0]), fontsize=8)
ax[1].set_xlabel('estimated cost ms (1.73 x rerank + 0.131 x blocks)'); ax[1].set_ylabel('answer-string hit'); ax[1].set_title('same quality -> cost'); ax[1].grid(alpha=.3); ax[1].legend(fontsize=8)
plt.tight_layout(); plt.savefig(f'{O}/fig_exp2_budget_cost.png', dpi=110); plt.close()
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200)
for k, v in out.items(): print(f'=== {k} ===\n', v.round(4).to_string(index=False) if isinstance(v, pd.DataFrame) else v)
