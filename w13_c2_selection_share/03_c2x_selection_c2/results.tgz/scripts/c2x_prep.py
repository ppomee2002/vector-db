# c2x_prep.py: 0단계 준비 - (a) 정합성, (c) 토큰 수, (b) test 질문 (NQ train + nq_open train 정답) 정확 검색 Top-100 + 전체 Rerank
# 실행: CUDA_VISIBLE_DEVICES=0 nohup python -B -I scripts/c2x_prep.py > results/prep.log 2>&1 &
import os, sys, re, json, time, unicodedata, numpy as np, pandas as pd, pyarrow as pa
X = '/workspace/jaeeun/sel_fetch_c2x'; OUT = f'{X}/results'; J = '/workspace/junlim/data_nq'; PF = '/workspace/junlim/pf3_out'
V2D = '/workspace/jaeeun/sel_fetch_v2/sel_fetch/data'; STORE = '/workspace/jaeeun/sel_fetch/data/chunk_store_seq.bin'
NQO = '/workspace/jaeeun/hf/datasets/google-research-datasets___nq_open/nq_open/0.0.0/5dd9790a83002ad084ddeb7c420dc716852c6f28'
SEED, N_TEST = 20261123, 2000
t0 = time.time()
def log(*a): print(f'[{time.time()-t0:7.1f}s]', *a, flush=True)
WORD = re.compile(r'\w+', re.UNICODE)
def toks(s):   # analyze_pf3.py와 같은 정규화
    s = unicodedata.normalize('NFD', s); s = ''.join(ch for ch in s if unicodedata.category(ch) != 'Mn'); return ' '.join(WORD.findall(s.lower()))
def norm_q(s): return ' '.join(re.findall(r'\w+', s.lower()))   # gold_map.py와 같음
off = np.load(f'{V2D}/chunk_store_off.npy'); meta = np.load(f'{V2D}/chunk_meta.npz'); doc = meta['doc_idx']
# ---- (a) 정합성: chunks.jsonl(nq_seq 적재 원본) vs chunk_store_seq.bin(선별 실험 본문) 전수 대조 ----
fd = os.open(STORE, os.O_RDONLY); n = mism = docmis = 0; texts = []
with open(f'{J}/chunks.jsonl', encoding='utf-8') as f:
    for i, l in enumerate(f):
        r = json.loads(l); b = r['text'].encode('utf-8'); texts.append(r['text'])
        if os.pread(fd, int(off[i + 1] - off[i]), int(off[i])) != b: mism += 1
        if r['doc_idx'] != doc[i]: docmis += 1
        n += 1
flags = np.load(f'{PF}/nq_flags.npy'); pk = np.load(f'{J}/pk_seq.npy')
chk = dict(chunks=n, text_mismatch=mism, doc_mismatch=docmis, flags_len=len(flags), pk_seq_identity=bool((pk == np.arange(len(pk))).all()),
           c2_gold_ok=json.load(open(f'{PF}/gold_ok_nq.json')).get('chunk_mismatch'), c2_ans_eval=json.load(open(f'{PF}/gold_ok_nq.json')).get('answers_matched'))
log('consistency', chk)
# ---- (c) 토큰 수: GPT-2 BPE (공개 토크나이저 하나로 고정) ----
from transformers import AutoTokenizer
tk = AutoTokenizer.from_pretrained('gpt2')
ntok = np.zeros(n, np.int32)
for s in range(0, n, 20000): ntok[s:s + 20000] = [len(x) for x in tk(texts[s:s + 20000], add_special_tokens=False)['input_ids']]
np.save(f'{OUT}/chunk_tokens_gpt2.npy', ntok); chk.update(tok_mean=float(ntok.mean()), tok_median=float(np.median(ntok)), tok_p95=float(np.percentile(ntok, 95)))
log('tokens', chk['tok_mean'], chk['tok_median'])
# ---- (b) test 질문: NQ train (q_train_minilm) + nq_open train 정답 ----
def arrow(p):
    with pa.memory_map(p) as src:
        try: t = pa.ipc.open_stream(src).read_all()
        except Exception: t = pa.ipc.open_file(src).read_all()
    return t.to_pandas()
nqo = arrow(f'{NQO}/nq_open-train.arrow'); amap = {}
for q, a in zip(nqo.question, nqo.answer):
    a = [x for x in (list(a) if a is not None else []) if str(x).strip()]
    if a: amap.setdefault(norm_q(q), a)
tm = pd.read_json('/workspace/jaeeun/sel_fetch_v2/sel_fetch/data/q_train_minilm_meta.jsonl', lines=True)
tm['ans'] = tm.text.map(lambda s: amap.get(norm_q(s))); has = np.where(tm.ans.notna())[0]
log('NQ train queries', len(tm), 'with nq_open train answer', len(has))
dev_q = set(norm_q(json.loads(l)['text']) for l in open(f'{J}/queries.jsonl', encoding='utf-8') if json.loads(l)['kind'] == 'real')
has = np.array([i for i in has if norm_q(tm.text[i]) not in dev_q])           # dev(NQ test)와 겹치는 질문 제외
perm = np.random.default_rng(SEED).permutation(has)
QV = np.load('/workspace/jaeeun/sel_fetch/data/q_train_minilm.npy', mmap_mode='r')
CV = np.asarray(np.load(f'{J}/chunk_vecs.npy', mmap_mode='r'), dtype=np.float32)
textok = {}
def ctoks(c):
    if c not in textok: textok[c] = ' ' + toks(texts[c]) + ' '
    return textok[c]
kept, examined = [], 0
for s in range(0, len(perm), 400):
    idx = perm[s:s + 400]; Q = np.asarray(QV[idx], np.float32); S = Q @ CV.T
    top = np.argpartition(-S, 100, 1)[:, :100]; ts = np.take_along_axis(S, top, 1); o = np.argsort(-ts, 1, kind='stable')
    top = np.take_along_axis(top, o, 1); ts = np.take_along_axis(ts, o, 1)
    for k, i in enumerate(idx):
        examined += 1; A = [' ' + toks(a) + ' ' for a in tm.ans[i] if toks(a)]
        if A and any(a in ctoks(int(c)) for c in top[k] for a in A):
            kept.append((int(i), top[k].copy(), ts[k].copy(), A))
        if len(kept) >= N_TEST: break
    log('examined', examined, 'kept', len(kept))
    if len(kept) >= N_TEST: break
chk.update(test_examined=examined, test_kept=len(kept), test_keep_rate=len(kept) / examined)
# ---- Rerank (전체 Top-100, v2와 같은 모델) ----
import torch; from sentence_transformers import CrossEncoder
torch.set_num_threads(4); log('gpu', os.popen('nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv,noheader').read().strip().replace('\n', ' | '))
ce = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2', device='cuda', max_length=256)
rows, ans_out = [], []; t1 = time.time()
for qn, (i, top, ts, A) in enumerate(kept):
    sc = ce.predict([(tm.text[i], texts[c]) for c in top], batch_size=100, show_progress_bar=False)
    cr = np.argsort(np.argsort(-sc, kind='stable'), kind='stable')
    rows.append(pd.DataFrame(dict(q_idx=qn, rank=np.arange(100), chunk_id=top, ann_score=ts, doc_idx=doc[top], ce_score=np.asarray(sc, np.float32), ce_rank=cr)))
    ans_out.append(dict(q_idx=qn, train_row=i, train_id=tm._id[i], text=tm.text[i], ans=[a.strip() for a in A]))
    if (qn + 1) % 500 == 0: log('reranked', qn + 1, f'{(qn+1)/(time.time()-t1):.1f} q/s')
pd.concat(rows).to_csv(f'{OUT}/test_rerank_top100.csv', index=False)
with open(f'{OUT}/test_queries.jsonl', 'w', encoding='utf-8') as f:
    for r in ans_out: f.write(json.dumps(r, ensure_ascii=False) + '\n')
chk.update(seed=SEED, tokenizer='gpt2 (HF transformers AutoTokenizer)', torch=torch.__version__, reranker='cross-encoder/ms-marco-MiniLM-L-6-v2 max_len 256',
           search='numpy exact inner product (MiniLM normalized)', cmd='CUDA_VISIBLE_DEVICES=0 python -B -I scripts/c2x_prep.py')
json.dump(chk, open(f'{OUT}/prep_check.json', 'w'), indent=1); log('ALL DONE', chk)
