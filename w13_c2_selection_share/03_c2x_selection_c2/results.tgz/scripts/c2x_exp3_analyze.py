# c2x_exp3_analyze.py: 실험 3 구간 분해, A/A, paired bootstrap, 그림
import numpy as np, pandas as pd, json
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
X = '/workspace/jaeeun/sel_fetch_c2x'; O = f'{X}/results/exp3'
d = pd.read_csv(f'{O}/exp3_raw.csv'); d = d[~d.warmup]; d['io'] = d.fetch1 + d.fetch2
def boot(x, n=2000):
    x = np.asarray(x, float); rng = np.random.default_rng(0); m = x[rng.integers(0, len(x), (n, len(x)))].mean(1); return x.mean(), np.quantile(m, .025), np.quantile(m, .975)
SEG = ['fetch1', 'rerank', 'select', 'fetch2', 'total']
s = d.groupby('cfg').agg(n=('total', 'size'), p50=('total', 'median'), p95=('total', lambda x: x.quantile(.95)),
                         **{f'{k}_mean': (k, 'mean') for k in SEG}, blocks1=('blocks1', 'mean'), blocks2=('blocks2', 'mean'), io1=('io1', 'mean'), io2=('io2', 'mean'),
                         extra=('extra', 'mean'), final=('final', 'mean'), tokens=('tokens', 'mean')).reset_index()
s.to_csv(f'{O}/exp3_summary.csv', index=False)
m = d.groupby(['cfg', 'q'])[SEG + ['io']].mean()   # 질문별 (2회 평균)
def pair(a, b, col):
    A_, B_ = m.loc[a][col], m.loc[b][col]; k = A_.index.intersection(B_.index); return boot((A_[k] - B_[k]).values)
rows = []
aa = pair('C6_B15_F1_N15_AA', 'C2_B15_F1_N15', 'total'); delta = max(abs(aa[1]), abs(aa[2]))
rows.append(dict(cmp='A/A C6-C2', seg='total', diff=aa[0], lo=aa[1], hi=aa[2]))
for a, b in (('C3_B10_BC1_N15', 'C2_B15_F1_N15'), ('C5_B10_BC1_N20', 'C4_B20_F1_N20'), ('C3_B10_BC1_N15', 'C1_B10_none_N10'), ('C5_B10_BC1_N20', 'C1_B10_none_N10')):
    for col in ('total', 'rerank', 'io', 'fetch1', 'fetch2', 'select'):
        r = pair(a, b, col); rows.append(dict(cmp=f'{a} - {b}', seg=col, diff=r[0], lo=r[1], hi=r[2]))
p = pd.DataFrame(rows); p['delta'] = delta
p['verdict'] = p.apply(lambda r: '' if r.seg != 'total' or r.cmp.startswith('A/A') else ('no difference' if (r.lo <= 0 <= r.hi) or abs(r['diff']) < delta else ('faster' if r['diff'] < 0 else 'slower')), axis=1)
p.to_csv(f'{O}/exp3_paired.csv', index=False)
fig, ax = plt.subplots(figsize=(9, 5)); order = ['C1_B10_none_N10', 'C2_B15_F1_N15', 'C6_B15_F1_N15_AA', 'C3_B10_BC1_N15', 'C4_B20_F1_N20', 'C5_B10_BC1_N20']
t = s.set_index('cfg').loc[order]; bot = np.zeros(len(t))
for seg, col in (('fetch1', '#ff7f0e'), ('rerank', '#1f77b4'), ('select', '#d62728'), ('fetch2', '#ffbb78')):
    ax.bar(range(len(t)), t[f'{seg}_mean'], bottom=bot, color=col, label=seg); bot += t[f'{seg}_mean'].values
ax.set_xticks(range(len(t))); ax.set_xticklabels(order, rotation=30, ha='right', fontsize=8); ax.set_ylabel('mean ms per query (n=300 x 2)'); ax.legend(); ax.grid(axis='y', alpha=.3)
ax.set_title('Exp3: contribution-C1 storage (O_DIRECT), embed/ANN excluded'); plt.tight_layout(); plt.savefig(f'{O}/fig_exp3_breakdown.png', dpi=110)
pd.set_option('display.width', 250); print(s.round(3).to_string(index=False)); print(p.round(3).to_string(index=False)); print('delta', delta)
