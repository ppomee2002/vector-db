# c2x_exp3.py: 실험 3 - 기여 C1 저장소(문서 순, 붙은 4KB 블록 한 번에, O_DIRECT)에서 실제 비용. GPU0. Milvus 안 씀.
# 실행: CUDA_VISIBLE_DEVICES=0 nohup python -B -I scripts/c2x_exp3.py > results/exp3.log 2>&1 &
import os, sys, json, time, mmap, threading, subprocess, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pf3_rules import select
import torch; from sentence_transformers import CrossEncoder
torch.set_num_threads(4)
X = '/workspace/jaeeun/sel_fetch_c2x'; OUT = f'{X}/results/exp3'; os.makedirs(OUT, exist_ok=True)
V2D = '/workspace/jaeeun/sel_fetch_v2/sel_fetch/data'; STORE = '/workspace/jaeeun/sel_fetch/data/chunk_store_seq.bin'
BLK = 4096; NQM, NW, REPS = 300, 30, 2
off = np.load(f'{V2D}/chunk_store_off.npy'); doc = np.load(f'{V2D}/chunk_meta.npz')['doc_idx']; ntok = np.load(f'{X}/results/chunk_tokens_gpt2.npy')
TOKC = int(round(float(ntok.mean())))
rr = pd.read_csv(f'{X}/results/test_rerank_top100.csv').sort_values(['q_idx', 'rank']); top100 = {q: g.chunk_id.values.astype(np.int64) for q, g in rr.groupby('q_idx')}
qtext = {r['q_idx']: r['text'] for r in map(json.loads, open(f'{X}/results/test_queries.jsonl', encoding='utf-8'))}
qsel = np.random.default_rng(11).choice(sorted(top100), NQM + NW, replace=False)
fd = os.open(STORE, os.O_RDONLY | os.O_DIRECT); BUF = mmap.mmap(-1, 16 << 20); MV = memoryview(BUF)
def read_blocks(bl, cache, pos0):
    """bl: 읽을 블록 번호(정렬). 붙은 블록은 preadv 한 번. cache[block] = 버퍼 위치. 반환: (I/O 횟수, 다음 위치)."""
    if not len(bl): return 0, pos0
    bl = np.asarray(bl); cuts = np.where(np.diff(bl) > 1)[0]; st = np.r_[bl[0], bl[cuts + 1]]; en = np.r_[bl[cuts], bl[-1]]; pos = pos0
    for a, b in zip(st, en):
        L = int(b - a + 1) * BLK; os.preadv(fd, [MV[pos:pos + L]], int(a) * BLK)
        for k in range(int(a), int(b) + 1): cache[k] = pos + (k - int(a)) * BLK
        pos += L
    return len(st), pos
def need_blocks(cids): return sorted({k for c in cids for k in range(int(off[c]) // BLK, (int(off[c + 1]) - 1) // BLK + 1)})
def text_of(c, cache):
    s, e = int(off[c]), int(off[c + 1]); out = bytearray()
    for k in range(s // BLK, (e - 1) // BLK + 1):
        p = cache[k]; lo = max(s, k * BLK) - k * BLK; hi = min(e, (k + 1) * BLK) - k * BLK; out += MV[p + lo:p + hi]
    return out.decode('utf-8')
ce = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2', device='cuda', max_length=256)
def sync(): torch.cuda.synchronize()
def run(q, B, mode, N):
    T = {}; cache = {}; t = time.perf_counter(); S = top100[q][:B]; io1, pos = read_blocks(need_blocks(S), cache, 0)
    txt = [text_of(c, cache) for c in S]; T['fetch1'] = time.perf_counter() - t
    t = time.perf_counter(); sc = ce.predict([(qtext[q], x) for x in txt], batch_size=128, show_progress_bar=False); sync(); T['rerank'] = time.perf_counter() - t
    t = time.perf_counter(); order = list(S[np.argsort(-sc, kind='stable')]); top10 = order[:10]
    if mode == 'BC1':
        sel = set(select('BC1', top10, doc)); nb = []
        for p in top10:
            for k in (p - 1, p + 1):
                if k in sel and k not in nb: nb.append(k)
        order = top10 + nb
    final, tot = [], 0
    for c in order:
        if tot + ntok[c] > N * TOKC: break
        final.append(int(c)); tot += ntok[c]
    extra = [c for c in final if c not in set(S.tolist())]; T['select'] = time.perf_counter() - t
    t = time.perf_counter(); nbk = [k for k in need_blocks(extra) if k not in cache]; io2, pos = read_blocks(nbk, cache, pos)
    ctx = [text_of(c, cache) for c in final]; T['fetch2'] = time.perf_counter() - t
    T['total'] = sum(T.values())
    return {k: v * 1e3 for k, v in T.items()}, dict(io1=io1, io2=io2, blocks1=len(need_blocks(S)), blocks2=len(nbk), extra=len(extra), final=len(final), tokens=int(tot))
CFG = [('C1_B10_none_N10', 10, 'none', 10), ('C2_B15_F1_N15', 15, 'none', 15), ('C3_B10_BC1_N15', 10, 'BC1', 15), ('C4_B20_F1_N20', 20, 'none', 20),
       ('C5_B10_BC1_N20', 10, 'BC1', 20), ('C6_B15_F1_N15_AA', 15, 'none', 15)]
stop = threading.Event()
def monitor():
    with open(f'{OUT}/monitor.csv', 'w') as f:
        f.write('ts,load1,gpu0_util,gpu1_util\n')
        while not stop.is_set():
            g = subprocess.run(['nvidia-smi', '--query-gpu=utilization.gpu', '--format=csv,noheader,nounits'], capture_output=True, text=True).stdout.split()
            f.write(f'{time.time():.1f},{os.getloadavg()[0]:.2f},{g[0] if g else ""},{g[1] if len(g) > 1 else ""}\n'); f.flush(); time.sleep(1)
th = threading.Thread(target=monitor, daemon=True); th.start()
print('before', os.popen('uptime').read().strip(), '|', os.popen('nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv,noheader').read().strip().replace('\n', ' | '), flush=True)
rows = []
for rep in range(REPS):
    for k, q in enumerate(qsel):
        sh = (k + rep * 3) % len(CFG); order = CFG[sh:] + CFG[:sh]
        for name, B, mode, N in order:
            T, c = run(int(q), B, mode, N)
            rows.append(dict(rep=rep, warmup=k < NW, q=int(q), cfg=name, slot=order.index((name, B, mode, N)), **T, **c))
    print('rep done', rep, flush=True)
stop.set(); th.join(timeout=3)
pd.DataFrame(rows).to_csv(f'{OUT}/exp3_raw.csv', index=False)
print('after', os.popen('uptime').read().strip(), flush=True)
json.dump(dict(n=NQM, warmup=NW, reps=REPS, seed_q=11, cfg=CFG, TOKC=TOKC, gpu=torch.cuda.get_device_name(0), torch=torch.__version__,
               io='O_DIRECT 4KB, contiguous blocks one preadv, blocks read in fetch1 reused in fetch2', cmd='CUDA_VISIBLE_DEVICES=0 python -B -I scripts/c2x_exp3.py'),
          open(f'{OUT}/config.json', 'w'), indent=1)
print('ALL DONE', flush=True)
