# s1_analysis.py: 1단계 - 기존 로그 재분석 + 수정된 Go/No-go a~c 수치 (CPU만, Milvus/GPU 안 씀)
# 실행: cd /workspace/jaeeun/sel_fetch_v2 && source sel_fetch/env.sh && nohup python -I scripts_v2/s1_analysis.py > results_v2/s1/s1_analysis.log 2>&1 &
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

OUT = f'{R}/s1'; os.makedirs(OUT, exist_ok=True)
docarr, cix, nb, off = load_meta()
sp = split_B(); dev_q = set(sp[sp.split == 'dev'].q_idx)
log('split', sp.split.value_counts().to_dict())

rr = load_rr(); rr = add_features(rr, docarr); log('features done', rr.shape)
qr = pd.read_csv(f'{D}/qrels_chunk.tsv', sep='\t'); qrels = qr.groupby('q_idx').chunk_id.apply(set).to_dict()

# ---- 0) 재현 확인: 전체 3,452 OOF M1이 지난주 q2_oof_pred.csv와 같은가 ----
p_all_M1 = oof(rr, M1_COLS)
old = pd.read_csv(f'{V2}/sel_fetch/results/q2_oof_pred.csv', usecols=['q_idx', 'rank', 'p_M1']).sort_values(['q_idx', 'rank'])
repro_diff = float(np.abs(old.p_M1.values - p_all_M1).max()); log('M1 reproduction max|diff| vs last week =', repro_diff)
p_all_M1np = oof(rr, M1NOPOS_COLS); log('M1-noPos (all 3452, last-week protocol) restored')

# ---- 1) dev 전용 학습 (5-fold OOF, dev 안에서만) ----
dv = rr[rr.q_idx.isin(dev_q)].reset_index(drop=True)
dv['p_M1'] = oof(dv, M1_COLS); dv['p_M1np'] = oof(dv, M1NOPOS_COLS)
dv['f_logrank'] = np.log1p(dv['rank'])
LR_SETS = {'LR1_rank': ['f_logrank'], 'LR2_rank_gap': ['f_logrank', 'f_gap_top1'],
           'LR3_rank_gap_doc': ['f_logrank', 'f_gap_top1', 'f_doc_hits']}
lr_coef = {}
for nm, cols in LR_SETS.items():
    mk = lambda: make_pipeline(StandardScaler(), LogisticRegression(C=1.0, max_iter=1000))
    dv['p_' + nm] = oof(dv, cols, make=mk)
    m = mk().fit(dv[cols], dv.y); lr_coef[nm] = dict(zip(cols, m[-1].coef_[0].round(4).tolist()))
log('dev models done', lr_coef)
from sklearn.metrics import roc_auc_score, average_precision_score
deep = (dv['rank'] >= 10).values
auc = []
for nm in ['ANN rank', 'p_LR1_rank', 'p_LR2_rank_gap', 'p_LR3_rank_gap_doc', 'p_M1np', 'p_M1']:
    s = -dv['rank'].values if nm == 'ANN rank' else dv[nm].values
    auc.append(dict(model=nm, auc_all=roc_auc_score(dv.y, s), ap_all=average_precision_score(dv.y, s),
                    auc_deep=roc_auc_score(dv.y[deep], s[deep]), ap_deep=average_precision_score(dv.y[deep], s[deep])))
auc = pd.DataFrame(auc); auc.to_csv(f'{OUT}/e_auc_dev.csv', index=False); log('\n' + auc.round(4).to_string(index=False))

# ---- 2) 정책 x 예산 전 격자 평가 (dev) ----
EV = Evaluator(dv, off, qrels); nq = len(EV.q); sh = (nq, 100)
POL = {'TopB': -dv['rank'].values.reshape(sh).astype(float), 'M1': dv.p_M1.values.reshape(sh),
       'M1-noPos': dv.p_M1np.values.reshape(sh), 'LR3': dv.p_LR3_rank_gap_doc.values.reshape(sh),
       'LR2': dv.p_LR2_rank_gap.values.reshape(sh)}
GRID = list(range(1, 101))
per = {}   # (pol,B) -> per-query df
summ = []
for pn, sc in POL.items():
    for B in GRID:
        df = EV.eval_mask(EV.mask_topk_by(sc, B)); per[(pn, B)] = df
        summ.append(dict(policy=pn, B=B, **df.drop(columns='q_idx').mean().to_dict()))
    log('grid done', pn)
summ = pd.DataFrame(summ); summ.to_csv(f'{OUT}/grid_dev_summary.csv', index=False)

# ---- 3) a) 같은 B / 같은 블록 예산 비교 (paired bootstrap) ----
def matched(pn, target_blocks, metric):
    """정책 pn의 평균 블록 수가 target이 되도록 인접 두 B 사이를 질문별로 선형 혼합."""
    mb = summ[summ.policy == pn].set_index('B').blocks
    Bs = [b for b in GRID if mb[b] <= target_blocks]
    lo = max(Bs) if Bs else 1; hi = min(lo + 1, 100)
    w = 0.0 if hi == lo or mb[hi] == mb[lo] else float(np.clip((target_blocks - mb[lo]) / (mb[hi] - mb[lo]), 0, 1))
    v = (1 - w) * per[(pn, lo)][metric].values + w * per[(pn, hi)][metric].values
    return v, lo + w
rows = []
for B in (10, 15, 20, 30, 50):
    base = per[('TopB', B)]; tb = base.blocks.mean()
    for pn in ('M1', 'M1-noPos', 'LR3', 'LR2'):
        for metric in ('ndcg10', 'hit10', 'retained'):
            d_sameB = per[(pn, B)][metric].values - base[metric].values
            v, Beq = matched(pn, tb, metric); d_blk = v - base[metric].values
            m1, l1, h1 = paired_boot(d_sameB); m2, l2, h2 = paired_boot(d_blk)
            rows.append(dict(B=B, topB_blocks=tb, policy=pn, metric=metric, topB_value=base[metric].mean(),
                             sameB_diff=m1, sameB_lo=l1, sameB_hi=h1, policy_blocks_sameB=per[(pn, B)].blocks.mean(),
                             blockmatched_B=Beq, blk_diff=m2, blk_lo=l2, blk_hi=h2))
a_tab = pd.DataFrame(rows); a_tab.to_csv(f'{OUT}/a_prior_upper_bound_dev.csv', index=False)

# ---- 4) b) 품질 민감도: Top-B 곡선의 보존율 vs nDCG/Hit ----
tb_curve = summ[summ.policy == 'TopB'][['B', 'retained', 'ndcg10', 'hit10', 'gold_fetched', 'blocks', 'extents']]
full = tb_curve[tb_curve.B == 100].iloc[0]
tb_curve = tb_curve.assign(ndcg_frac_of_full=tb_curve.ndcg10 / full.ndcg10, hit_frac_of_full=tb_curve.hit10 / full.hit10)
tb_curve.to_csv(f'{OUT}/b_topB_curve_dev.csv', index=False)
sens = []
for lo, hi in ((5, 10), (10, 20), (20, 30), (30, 50), (50, 100)):
    a_, b_ = tb_curve.set_index('B').loc[lo], tb_curve.set_index('B').loc[hi]
    dr = (b_.retained - a_.retained) * 100
    sens.append(dict(B_from=lo, B_to=hi, d_retained_pp=dr, d_ndcg=b_.ndcg10 - a_.ndcg10, d_hit_pp=(b_.hit10 - a_.hit10) * 100,
                     ndcg_per_1pp_ret=(b_.ndcg10 - a_.ndcg10) / dr, hitpp_per_1pp_ret=(b_.hit10 - a_.hit10) * 100 / dr))
sens = pd.DataFrame(sens); sens.to_csv(f'{OUT}/b_sensitivity_dev.csv', index=False)

# ---- 5) headroom ----
hr = []
for B in (10, 15, 20, 30, 50):
    sel = EV.rank < B
    miss_ref = (EV.y & ~sel).any(1); gold100 = EV.gold.any(1); gold_out = (EV.gold & ~sel).any(1) & ~(EV.gold & sel).any(1)
    hr.append(dict(B=B, frac_q_ref_top10_outside=miss_ref.mean(), frac_q_gold_in100_not_in_B=(gold100 & gold_out).mean(),
                   mean_ref_outside=(EV.y & ~sel).sum(1).mean()))
hr = pd.DataFrame(hr); hr.to_csv(f'{OUT}/headroom_dev.csv', index=False)
# headroom 질문 정의(PLAN): 기준 Top-10 중 1개 이상이 ANN 순위 >= 20
hq = (EV.y & (EV.rank >= 20)).any(1); log('headroom queries (ref top10 with ANN rank>=20):', hq.mean())

# ---- 6) c') C1 공짜 후보: Top-B가 읽은 블록 안에 완전히 들어 있는 다른 후보 ----
free_rows = []
for B in (5, 10, 15, 20, 30, 50):
    M = EV.rank < B; Mf = M.copy()
    for i in range(nq):
        bl = set()
        for a, b in zip(EV.b0[i, M[i]], EV.b1[i, M[i]]): bl.update(range(a, b + 1))
        for j in np.where(~M[i])[0]:
            if all(x in bl for x in range(EV.b0[i, j], EV.b1[i, j] + 1)): Mf[i, j] = True
    base = per[('TopB', B)]; fr = EV.eval_mask(Mf)
    extra = (Mf & ~M); r = dict(B=B, topB_blocks=base.blocks.mean(), free_blocks=fr.blocks.mean(),
                                extra_cands=extra.sum(1).mean(), extra_in_ref10=(extra & EV.y).sum(1).mean(),
                                frac_q_with_extra=(extra.sum(1) > 0).mean())
    for metric in ('retained', 'ndcg10', 'hit10'):
        m_, l_, h_ = paired_boot(fr[metric].values - base[metric].values)
        r.update({f'{metric}_topB': base[metric].mean(), f'{metric}_free': fr[metric].mean(), f'd_{metric}': m_, f'd_{metric}_lo': l_, f'd_{metric}_hi': h_})
    free_rows.append(r)
free = pd.DataFrame(free_rows); free.to_csv(f'{OUT}/c1_free_candidates_dev.csv', index=False)
log('\n' + free.round(4).to_string(index=False))

# ---- 7) 놓친 기준 Top-10의 특징 (Top-B, M1-noPos, 같은 B) ----
miss_rows = []
for pn in ('TopB', 'M1-noPos'):
    for B in (10, 20, 30):
        M = EV.mask_topk_by(POL[pn], B); missed = EV.y & ~M
        sd = adj1 = adj2 = inblk = 0; ranks = []
        for i in range(nq):
            sel_docs = set(EV.doc[i, M[i]]); sel_c = set(EV.cid[i, M[i]])
            bl = set()
            for a, b in zip(EV.b0[i, M[i]], EV.b1[i, M[i]]): bl.update(range(a, b + 1))
            for j in np.where(missed[i])[0]:
                c = EV.cid[i, j]; d = EV.doc[i, j]; ranks.append(EV.rank[i, j])
                sd += d in sel_docs
                adj1 += any((c + k) in sel_c and docarr[c + k] == d for k in (-1, 1) if 0 <= c + k < len(docarr))
                adj2 += any((c + k) in sel_c and docarr[c + k] == d for k in (-2, -1, 1, 2) if 0 <= c + k < len(docarr))
                inblk += any(x in bl for x in range(EV.b0[i, j], EV.b1[i, j] + 1))
        n = max(len(ranks), 1); ranks = np.array(ranks)
        miss_rows.append(dict(policy=pn, B=B, missed_per_q=missed.sum(1).mean(), n_missed=len(ranks),
                              same_doc_as_selected=sd / n, adjacent_pm1=adj1 / n, adjacent_pm2=adj2 / n, shares_block_with_selected=inblk / n,
                              rank_lt20=(ranks < 20).mean(), rank_20_29=((ranks >= 20) & (ranks < 30)).mean(),
                              rank_30_49=((ranks >= 30) & (ranks < 50)).mean(), rank_50_99=(ranks >= 50).mean(), rank_median=float(np.median(ranks))))
miss = pd.DataFrame(miss_rows); miss.to_csv(f'{OUT}/missed_characteristics_dev.csv', index=False)
log('\n' + miss.round(3).to_string(index=False))

# ---- 8) 같은 문서 후보 구조 (Document-aware 근거) ----
dstat = dv.groupby('q_idx').agg(n_docs=('doc_idx', 'nunique'))
top10docs = dv[dv.y == 1].groupby('q_idx').doc_idx.nunique()
log('Top-100 distinct docs/query median', dstat.n_docs.median(), '| ref top-10 distinct docs median', top10docs.median())

# ---- 9) d) 지난주 Fetch 측정 로그 재분석 ----
io = pd.read_csv(f'{V2}/sel_fetch/results/io_per_query.csv'); ios = pd.read_csv(f'{V2}/sel_fetch/results/io_summary.csv')
run_order = ['TopK10', 'Select10', 'TopK20', 'Select20', 'TopK30', 'Select30', 'Select28', 'TopK100']
io['run'] = io.policy + io.B.astype(str)
d_rows = []
for k, (rn, g) in enumerate(sorted(io.groupby('run'), key=lambda x: run_order.index(x[0]))):
    g = g.reset_index(drop=True); s = ios[(ios.policy + ios.B.astype(str)) == rn].iloc[0]
    d_rows.append(dict(order=k, run=rn, chunks_per_q=g.chunks.mean(), mean_ms=g.fetch_ms.mean(), p50=g.fetch_ms.median(),
                       ms_per_chunk=g.fetch_ms.sum() / g.chunks.sum(), first300_mean=g.fetch_ms[:300].mean(), rest_mean=g.fetch_ms[300:].mean(),
                       dev_reads=s.dev_reads, dev_reads_per_chunk=s.dev_reads / g.chunks.sum(), dev_MB=s.dev_read_MB, app_MB=s.app_MB,
                       read_amp=s.dev_read_MB / s.app_MB))
dlog = pd.DataFrame(d_rows); dlog.to_csv(f'{OUT}/d_lastweek_fetch_log.csv', index=False)
log('\n' + dlog.round(3).to_string(index=False))

# 재현성 기록
json.dump(dict(env=env_info(), split_seed=SPLIT_SEED, n_dev=nq, m1_repro_maxdiff=repro_diff, lr_coef=lr_coef,
               hgb='HistGradientBoosting(max_iter=300, lr=0.05, leaves=31, random_state=0), GroupKFold(5)',
               bootstrap='paired, 2000, seed 0', blk=BLK, store=STORE,
               cmd='cd /workspace/jaeeun/sel_fetch_v2 && source sel_fetch/env.sh && python -I scripts_v2/s1_analysis.py'),
          open(f'{OUT}/config.json', 'w'), indent=1, ensure_ascii=False)
pd.set_option('display.width', 250)
print('\n=== a) same-B & block-matched (dev) ===\n' + a_tab.round(4).to_string(index=False))
print('\n=== b) Top-B curve (dev) ===\n' + tb_curve[tb_curve.B.isin([5, 10, 15, 20, 30, 40, 50, 70, 100])].round(4).to_string(index=False))
print('\n=== b) sensitivity ===\n' + sens.round(4).to_string(index=False))
print('\n=== headroom ===\n' + hr.round(4).to_string(index=False))
log('ALL DONE')
