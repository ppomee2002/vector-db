# s1_microbench.py: 1단계 c) 예비 측정 - Rerank 시간 vs 후보 수, C1(O_DIRECT) Fetch vs 개별 pread, 질문 임베딩 (GPU0, 1회, Milvus 안 씀)
# 실행: CUDA_VISIBLE_DEVICES=0 python -I scripts_v2/s1_microbench.py
import sys, os, json, time, mmap, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
import torch
from sentence_transformers import CrossEncoder, SentenceTransformer
torch.set_num_threads(4)
OUT = f'{R}/s1'; NQB = 200; NS = (10, 20, 30, 50, 100)
docarr, cix, nb, off = load_meta()
sp = split_B(); dev = np.sort(sp[sp.split == 'dev'].q_idx.values)
q_sel = np.random.default_rng(1).choice(dev, NQB + 20, replace=False)   # 20개 warmup
rr = load_rr(); rr = rr[rr.q_idx.isin(q_sel)]
qs = [json.loads(l)['text'] for l in open(f'{J}/queries.jsonl', encoding='utf-8')][:NQ_REAL]
fd_buf = os.open(STORE, os.O_RDONLY); fd_dir = os.open(STORE, os.O_RDONLY | os.O_DIRECT)
buf = mmap.mmap(-1, 4 << 20); mv = memoryview(buf)
def text(c): return os.pread(fd_buf, int(off[c + 1] - off[c]), int(off[c])).decode('utf-8')
def c1_read(cids):
    b0 = off[cids] // BLK; b1 = (off[cids + 1] - 1) // BLK
    bl = np.unique(np.concatenate([np.arange(a, b + 1) for a, b in zip(b0, b1)]))
    cuts = np.where(np.diff(bl) > 1)[0]; starts = np.r_[bl[0], bl[cuts + 1]]; ends = np.r_[bl[cuts], bl[-1]]
    for a, e in zip(starts, ends): os.preadv(fd_dir, [mv[:(e - a + 1) * BLK]], int(a) * BLK)
    return len(bl), len(starts)
def pread_each(cids):
    for c in cids: os.pread(fd_dir if False else fd_buf, int(off[c + 1] - off[c]), int(off[c]))
log('nvidia-smi:', os.popen('nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv,noheader').read().strip().replace('\n', ' | '))
log('uptime:', os.popen('uptime').read().strip())
ce = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2', device='cuda', max_length=256)
emb = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2', device='cuda')
rows = []
for k, q in enumerate(q_sel):
    g = rr[rr.q_idx == q].sort_values('rank'); cid = g.chunk_id.values
    torch.cuda.synchronize(); t = time.perf_counter(); emb.encode([qs[q]], normalize_embeddings=True); torch.cuda.synchronize()
    t_emb = (time.perf_counter() - t) * 1e3
    for n in NS:
        c = cid[:n]
        t = time.perf_counter(); blk, ext = c1_read(c); t_c1 = (time.perf_counter() - t) * 1e3
        t = time.perf_counter(); pread_each(c); t_pr = (time.perf_counter() - t) * 1e3    # buffered (참고)
        texts = [text(x) for x in c]
        torch.cuda.synchronize(); t = time.perf_counter()
        ce.predict([(qs[q], x) for x in texts], batch_size=128, show_progress_bar=False); torch.cuda.synchronize()
        t_rr = (time.perf_counter() - t) * 1e3
        if k >= 20: rows.append(dict(q_idx=q, n=n, embed_ms=t_emb, c1_odirect_ms=t_c1, blocks=blk, extents=ext, pread_buffered_ms=t_pr, rerank_ms=t_rr))
df = pd.DataFrame(rows); df.to_csv(f'{OUT}/c_microbench_raw.csv', index=False)
s = df.groupby('n').agg(embed_ms=('embed_ms', 'median'), c1_ms_p50=('c1_odirect_ms', 'median'), c1_ms_mean=('c1_odirect_ms', 'mean'),
                        blocks=('blocks', 'mean'), extents=('extents', 'mean'), pread_buf_p50=('pread_buffered_ms', 'median'),
                        rerank_ms_p50=('rerank_ms', 'median'), rerank_ms_mean=('rerank_ms', 'mean')).reset_index()
s.to_csv(f'{OUT}/c_microbench_summary.csv', index=False)
log('uptime after:', os.popen('uptime').read().strip())
json.dump(dict(env=env_info(), torch=torch.__version__, gpu=torch.cuda.get_device_name(0), n_queries=NQB, warmup=20, seed=1,
               note='예비 측정 1회. Milvus 제외. C1은 O_DIRECT라 page cache를 거치지 않음, pread_buffered는 참고용(캐시 영향 받음)'),
          open(f'{OUT}/c_microbench_config.json', 'w'), indent=1, ensure_ascii=False)
print(s.round(3).to_string(index=False)); log('ALL DONE')
