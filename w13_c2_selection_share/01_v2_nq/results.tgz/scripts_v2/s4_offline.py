# s4_offline.py: 3~4단계 오프라인 비교 (dev 튜닝 -> test 1회 평가). CPU만 사용.
# 실행: cd /workspace/jaeeun/sel_fetch_v2 && source sel_fetch/env.sh && nohup python -I scripts_v2/s4_offline.py > results_v2/s4/s4.log 2>&1 &
import sys, os, json, re, time, unicodedata, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
OUT = f'{R}/s4'; os.makedirs(OUT, exist_ok=True)
BS = (10, 15, 20, 30)
docarr, cix, nb, off = load_meta(); sp = split_B()
rr = load_rr(); rr = add_features(rr, docarr); rr['f_logrank'] = np.log1p(rr['rank'])
Q = np.unique(rr.q_idx.values); NQ = len(Q); sh = (NQ, 100)
A = lambda c: rr[c].values.reshape(sh)
cid, rank, ann, ce, y, doc = A('chunk_id'), A('rank'), A('ann_score'), A('ce_score'), A('y').astype(bool), A('doc_idx')
b0, b1 = block_ranges(off, cid)
log('loaded', NQ)

# ---- 정답: chunk 단위 qrels, passage 매핑, 정답 문자열 ----
qr = pd.read_csv(f'{D}/qrels_chunk.tsv', sep='\t')
pas = {}   # (q, chunk) -> set(passage)
for q, c, p in zip(qr.q_idx, qr.chunk_id, qr.corpus_id): pas.setdefault((q, c), set()).add(p)
npas = qr.groupby('q_idx').corpus_id.nunique().to_dict()
gold = np.array([[(q, c) in pas for c in cid[i]] for i, q in enumerate(Q)])
WORD = re.compile(r'\w+', re.UNICODE)
def toks(s):
    s = unicodedata.normalize('NFD', s); s = ''.join(ch for ch in s if unicodedata.category(ch) != 'Mn')
    return ' '.join(WORD.findall(s.lower()))
ans = {}
for l in open('/workspace/junlim/pf3_out/nq_gold.jsonl', encoding='utf-8'):   # 팀원 C2 gold_map 결과 (읽기 전용)
    r = json.loads(l)
    if r.get('ans'):
        a = [' ' + toks(x) + ' ' for x in r['ans'] if toks(x)]
        if a: ans[r['qi']] = a
fd = os.open(STORE, os.O_RDONLY)
ans_eval = np.array([q in ans for q in Q]); anshit = np.zeros(sh, bool)
for i, q in enumerate(Q):
    if q not in ans: continue
    for j in range(100):
        c = cid[i, j]; t = ' ' + toks(os.pread(fd, int(off[c + 1] - off[c]), int(off[c])).decode('utf-8')) + ' '
        anshit[i, j] = any(a in t for a in ans[q])
log('answers: eval queries', int(ans_eval.sum()))

# ---- 임베딩 유사도 (후보 간) ----
Vall = np.load(f'{J}/chunk_vecs.npy', mmap_mode='r')
ids = np.unique(cid); V = np.asarray(Vall[ids], dtype=np.float32); pos = np.searchsorted(ids, cid)
SIM = np.einsum('qid,qjd->qij', V[pos], V[pos]).astype(np.float32); del V
log('sim done')

# ---- 평가 ----
def evaluate(M, qsel):
    """M: (len(qsel),100) bool, qsel: 행 인덱스 배열 -> 질문별 지표."""
    n = M.sum(1); cem = np.where(M, ce[qsel], -np.inf); order = np.argsort(-cem, 1, kind='stable')[:, :10]
    top = np.take_along_axis(M, order, 1)
    yy = np.take_along_axis(y[qsel], order, 1) & top
    out = dict(qi=qsel, n_sel=n, retained=yy.sum(1) / 10)
    nd = np.zeros(len(qsel)); ndd = np.zeros(len(qsel)); hit = np.zeros(len(qsel)); ah = np.full(len(qsel), np.nan)
    pnum = np.zeros(len(qsel)); pden = np.zeros(len(qsel))
    for k, i in enumerate(qsel):
        q = Q[i]; chosen = [order[k, t] for t in range(10) if top[k, t]]
        dcg = dcgd = 0.0; seen = set()
        for r_, j in enumerate(chosen):
            if gold[i, j]:
                dcg += 1 / np.log2(r_ + 2)
                new = pas[(q, cid[i, j])] - seen
                if new: dcgd += 1 / np.log2(r_ + 2); seen |= pas[(q, cid[i, j])]
        ng = int(gold[i].sum()) if False else len({c for c in qr_c.get(q, ())})
        idcg = sum(1 / np.log2(t + 2) for t in range(min(ng, 10))); ip = sum(1 / np.log2(t + 2) for t in range(min(npas.get(q, 0), 10)))
        nd[k] = dcg / idcg if idcg else 0; ndd[k] = dcgd / ip if ip else 0
        hit[k] = any(gold[i, j] for j in chosen)
        if ans_eval[i]: ah[k] = float(any(anshit[i, j] for j in chosen))
        nn = int(n[k]); outside = y[i] & (rank[i] >= nn); pden[k] = outside.sum(); pnum[k] = (outside & M[k]).sum()
    out.update(ndcg=nd, ndcg_dedup=ndd, hit10=hit, ans=ah, prom_num=pnum, prom_den=pden)
    blk = np.zeros(len(qsel)); ext = np.zeros(len(qsel))
    for k, i in enumerate(qsel):
        s = M[k]; blk[k], ext[k] = c1_cost(b0[i, s], b1[i, s])
    out.update(blocks=blk, extents=ext)
    return pd.DataFrame(out)
qr_c = qr.groupby('q_idx').chunk_id.apply(set).to_dict()

def summarize(df):
    return dict(n_sel=df.n_sel.mean(), ndcg_dedup=df.ndcg_dedup.mean(), ans=np.nanmean(df.ans), prom_recovery=df.prom_num.sum() / max(df.prom_den.sum(), 1),
                ndcg=df.ndcg.mean(), hit10=df.hit10.mean(), retained=df.retained.mean(), blocks=df.blocks.mean(), extents=df.extents.mean())

# ---- 선별 방법 ----
def m_topk(i, B): return rank[i] < B
def m_score(sc_row, B):
    M = np.zeros(100, bool); M[np.argsort(-sc_row, kind='stable')[:B]] = True; return M
def m_random_deep(i, B, rng):
    x = int(np.ceil(0.2 * B)); M = rank[i] < B - x; pool = np.where(rank[i] >= B - x)[0]; M[rng.choice(pool, x, replace=False)] = True; return M
def m_A1(i, B, agg, alpha):
    x = int(round(alpha * B)); M = rank[i] < B - x
    d = doc[i]; s = ann[i]; u, inv = np.unique(d, return_inverse=True)
    ssum = np.bincount(inv, s); smax = np.full(len(u), -9.0); np.maximum.at(smax, inv, s); cnt = np.bincount(inv)
    dsc = (ssum if agg == 'sum' else smax * np.log1p(cnt))[inv]
    cand = np.where(~M)[0]; o = np.lexsort((-s[cand], -dsc[cand])); M[cand[o[:x]]] = True; return M
def m_A2(i, B, c):
    M = np.zeros(100, bool); used = {}
    for j in np.argsort(rank[i]):
        if M.sum() >= B: break
        if used.get(doc[i, j], 0) < c: M[j] = True; used[doc[i, j]] = used.get(doc[i, j], 0) + 1
    for j in np.argsort(rank[i]):
        if M.sum() >= B: break
        M[j] = True
    return M
def feedback_next(i, M, k, beta, gamma):
    sel = np.where(M)[0]; top3 = sel[np.argsort(-ce[i, sel])[:3]]
    f = (1 - beta) * ann[i] + beta * SIM[i][:, top3].max(1) + gamma * np.isin(doc[i], doc[i, top3])
    f[M] = -np.inf; nx = np.argsort(-f, kind='stable')[:k]; M = M.copy(); M[nx] = True; return M
def m_B1(i, B, beta, gamma):
    M = rank[i] < 10
    while M.sum() < B: M = feedback_next(i, M, min(10, B - M.sum()), beta, gamma)
    return M
def m_B2(i, beta, gamma, step=10, maxn=50):
    M = rank[i] < step
    while M.sum() < maxn:
        cur = set(np.where(M)[0][np.argsort(-ce[i, M])[:10]]); M2 = feedback_next(i, M, step, beta, gamma)
        new = set(np.where(M2 & ~M)[0]); top_new = set(np.where(M2)[0][np.argsort(-ce[i, M2])[:10]])
        M = M2
        if not (new & top_new): break
    return M
def m_C1free(i, B):
    M = rank[i] < B; bl = set()
    for a, b in zip(b0[i, M], b1[i, M]): bl.update(range(a, b + 1))
    for j in np.where(~M)[0]:
        if all(x in bl for x in range(b0[i, j], b1[i, j] + 1)): M[j] = True
    return M
def build(qsel, fn):
    t = time.perf_counter(); M = np.stack([fn(i) for i in qsel]); return M, (time.perf_counter() - t) / len(qsel) * 1e3

dev_i = np.where(np.isin(Q, sp[sp.split == 'dev'].q_idx))[0]; test_i = np.where(np.isin(Q, sp[sp.split == 'test'].q_idx))[0]

# ---- M1-noPos: dev로 학습 ----
dmask = rr.q_idx.isin(Q[dev_i]).values
m1 = hgb().fit(rr.loc[dmask, M1NOPOS_COLS], rr.y[dmask])
t = time.perf_counter(); p_m1 = m1.predict_proba(rr[M1NOPOS_COLS])[:, 1].reshape(sh); m1_ms = (time.perf_counter() - t) / NQ * 1e3
p_m1_dev = oof(rr[dmask].reset_index(drop=True), M1NOPOS_COLS).reshape(len(dev_i), 100)   # dev 진단용 OOF
log('M1-noPos trained on dev; predict ms/q', round(m1_ms, 3))

# ---- dev 튜닝 (B=20, ndcg_dedup) ----
tune = []
for agg in ('sum', 'maxlog'):
    for a in (0.2, 0.3, 0.5):
        M, _ = build(dev_i, lambda i: m_A1(i, 20, agg, a)); tune.append(dict(method='A1', agg=agg, alpha=a, **summarize(evaluate(M, dev_i))))
for c in (1, 2, 3):
    M, _ = build(dev_i, lambda i: m_A2(i, 20, c)); tune.append(dict(method='A2', c=c, **summarize(evaluate(M, dev_i))))
for be in (0.3, 0.5, 0.7, 1.0):
    for ga in (0.0, 0.05):
        M, _ = build(dev_i, lambda i: m_B1(i, 20, be, ga)); tune.append(dict(method='B1', beta=be, gamma=ga, **summarize(evaluate(M, dev_i))))
M, _ = build(dev_i, lambda i: m_topk(i, 20)); tune.append(dict(method='TopB', **summarize(evaluate(M, dev_i))))
tune = pd.DataFrame(tune); tune.to_csv(f'{OUT}/tune_dev_B20.csv', index=False); log('\n' + tune.round(4).to_string(index=False))
def best(m, keys):
    t = tune[tune.method == m]; mx = t.ndcg_dedup.max(); r = t[t.ndcg_dedup >= mx - 1e-12].iloc[0]; return {k: r[k] for k in keys}
HP = dict(A1=best('A1', ['agg', 'alpha']), A2=best('A2', ['c']), B1=best('B1', ['beta', 'gamma']))
HP['A2']['c'] = int(HP['A2']['c']); log('chosen HP', HP)
json.dump(HP, open(f'{OUT}/chosen_hp.json', 'w'), indent=1, default=float)

# ---- test 평가 (한 번) ----
pi = {i: k for k, i in enumerate(test_i)}
rows, per, masks, sel_ms = [], {}, {}, {}
for B in BS:
    rng = np.random.default_rng(0)
    meths = {'TopB': lambda i: m_topk(i, B), 'M1-noPos': lambda i: m_score(p_m1[i], B), 'Random-deep': lambda i: m_random_deep(i, B, rng),
             'A1': lambda i: m_A1(i, B, HP['A1']['agg'], HP['A1']['alpha']), 'A2': lambda i: m_A2(i, B, HP['A2']['c']),
             'B1': lambda i: m_B1(i, B, HP['B1']['beta'], HP['B1']['gamma']), 'C1free(ref)': lambda i: m_C1free(i, B)}
    for nm, fn in meths.items():
        M, ms = build(test_i, fn); df = evaluate(M, test_i); per[(nm, B)] = df; masks[(nm, B)] = M
        sel_ms[(nm, B)] = ms + (m1_ms if nm == 'M1-noPos' else 0)
        rows.append(dict(method=nm, B=B, sel_ms_offline=sel_ms[(nm, B)], **summarize(df)))
M, ms = build(test_i, lambda i: m_B2(i, HP['B1']['beta'], HP['B1']['gamma'])); df = evaluate(M, test_i)
per[('B2', 0)] = df; masks[('B2', 0)] = M; rows.append(dict(method='B2', B=0, sel_ms_offline=ms, **summarize(df)))
topcurve = {B: evaluate(np.stack([m_topk(i, B) for i in test_i]), test_i) for B in range(1, 101)}
for B in (5, 40, 50, 70, 100): rows.append(dict(method='TopB', B=B, sel_ms_offline=0, **summarize(topcurve[B])))
res = pd.DataFrame(rows); res.to_csv(f'{OUT}/test_summary.csv', index=False)
log('\n' + res.round(4).to_string(index=False))

# ---- paired bootstrap vs Top-B (같은 |S|), 전체 / headroom ----
hr = gold.any(1) & ~(gold & (rank < 20)).any(1); hr_t = hr[test_i]
def topB_interp(n, metric):
    lo = np.clip(np.floor(n).astype(int), 1, 100); hi = np.clip(lo + 1, 1, 100); w = n - lo
    Am = np.stack([topcurve[b][metric].values for b in range(1, 101)], 1); k = np.arange(len(n))
    return (1 - w) * Am[k, lo - 1] + w * Am[k, hi - 1]
def boot_ratio(num, den, num0, den0, n=2000):
    rng = np.random.default_rng(0); idx = rng.integers(0, len(num), (n, len(num)))
    d = num[idx].sum(1) / np.maximum(den[idx].sum(1), 1) - num0[idx].sum(1) / np.maximum(den0[idx].sum(1), 1)
    return float(np.quantile(d, .025)), float(np.quantile(d, .975))
ci = []
for (nm, B), df in per.items():
    if nm == 'TopB': continue
    for sub, msk in (('all', np.ones(len(test_i), bool)), ('headroom', hr_t)):
        r = dict(method=nm, B=B, subset=sub, n_q=int(msk.sum()), mean_S=df.n_sel[msk].mean())
        for metric in ('ndcg_dedup', 'ans', 'ndcg', 'hit10'):
            base = topB_interp(df.n_sel.values.astype(float), metric) if metric != 'ans' else None
            if metric == 'ans':
                b_ = per[('TopB', B)] if B else None
                base = topB_interp(df.n_sel.values.astype(float), 'ans')
                ok = msk & ~np.isnan(df.ans.values) & ~np.isnan(base)
                d = df.ans.values[ok] - base[ok]
            else:
                d = (df[metric].values - base)[msk]
            m_, l_, h_ = paired_boot(d); r.update({f'd_{metric}': m_, f'd_{metric}_lo': l_, f'd_{metric}_hi': h_})
        # 승격 후보 회수율 (Top-B는 정의상 0)
        r['prom_recovery'] = df.prom_num[msk].sum() / max(df.prom_den[msk].sum(), 1)
        r['prom_lo'], r['prom_hi'] = boot_ratio(df.prom_num.values[msk], df.prom_den.values[msk], np.zeros(msk.sum()), np.ones(msk.sum()))
        ci.append(r)
ci = pd.DataFrame(ci); ci.to_csv(f'{OUT}/test_ci_vs_topB.csv', index=False)
pd.set_option('display.width', 260); log('\n' + ci[ci.subset == 'all'].round(4).to_string(index=False))

# ---- M1-noPos와의 관계 (overlap, M1이 놓친 후보 확보) ----
ov = []
for B in BS:
    T = np.stack([m_topk(i, B) for i in test_i]); Mm = masks[('M1-noPos', B)]
    tgt = y[test_i] & ~T; m1miss = tgt & ~Mm
    for nm in ('A1', 'A2', 'B1', 'Random-deep', 'C1free(ref)', 'M1-noPos'):
        Mx = masks[(nm, B)]; pick = Mx & ~T; pm = Mm & ~T
        ov.append(dict(method=nm, B=B, promoted_picks_per_q=pick.sum(1).mean(),
                       jaccard_promoted_vs_M1=(pick & pm).sum() / max((pick | pm).sum(), 1),
                       frac_picks_also_M1=(pick & pm).sum() / max(pick.sum(), 1),
                       precision_picks=(pick & y[test_i]).sum() / max(pick.sum(), 1),
                       recovers_M1_missed=(Mx & m1miss).sum() / max(m1miss.sum(), 1),
                       picks_same_doc_as_topB=np.mean([np.isin(doc[i, pick[k]], doc[i, T[k]]).mean() if pick[k].any() else np.nan for k, i in enumerate(test_i)]),
                       picks_mean_ann_rank=rank[test_i][pick].mean() if pick.any() else np.nan))
ov = pd.DataFrame(ov); ov.to_csv(f'{OUT}/test_overlap_M1.csv', index=False); log('\n' + ov.round(3).to_string(index=False))

# ---- 사례 분석: 질문 유형별 차이 (B=20) ----
ndoc10 = np.array([len(set(doc[i, rank[i] < 10])) for i in test_i])
grp = np.where(ndoc10 <= 5, 'concentrated(<=5 docs in ANN top10)', 'diverse(>5 docs)')
case = []
for nm in ('M1-noPos', 'A1', 'A2', 'B1'):
    d = per[(nm, 20)].ndcg_dedup.values - per[('TopB', 20)].ndcg_dedup.values
    for g in np.unique(grp):
        m_, l_, h_ = paired_boot(d[grp == g]); case.append(dict(method=nm, group=g, n=int((grp == g).sum()), d_ndcg_dedup=m_, lo=l_, hi=h_,
                                                                  frac_improved=(d[grp == g] > 0).mean(), frac_worse=(d[grp == g] < 0).mean()))
case = pd.DataFrame(case); case.to_csv(f'{OUT}/test_case_groups_B20.csv', index=False); log('\n' + case.round(4).to_string(index=False))
qs_text = [json.loads(l)['text'] for l in open(f'{J}/queries.jsonl', encoding='utf-8')][:NQ_REAL]
ex = []
for nm in ('A1', 'B1'):
    d = per[(nm, 20)].ndcg_dedup.values - per[('TopB', 20)].ndcg_dedup.values
    for k in np.argsort(-d)[:3]:
        i = test_i[k]; T = rank[i] < 20; Mx = masks[(nm, 20)][k]; new = np.where(Mx & ~T & (gold[i] | y[i]))[0]
        ex.append(dict(method=nm, q_idx=int(Q[i]), question=qs_text[Q[i]], d_ndcg_dedup=float(d[k]),
                       new_useful=[dict(ann_rank=int(rank[i, j]), gold=bool(gold[i, j]), ref10=bool(y[i, j]), same_doc_as_topB=bool(doc[i, j] in set(doc[i, T])),
                                        max_sim_to_top3ce=float(SIM[i, j, np.where(rank[i] < 10)[0][np.argsort(-ce[i, rank[i] < 10])[:3]]].max())) for j in new]))
json.dump(ex, open(f'{OUT}/test_case_examples_B20.json', 'w'), indent=1, ensure_ascii=False)

# ---- C1 확장 원인 분해 (참고): 중복 라벨 vs Reranker 오류 감소 ----
dec = []
full = evaluate(np.ones((len(test_i), 100), bool), test_i)
for B in (10, 20):
    F = per[('C1free(ref)', B)]; Mf = masks[('C1free(ref)', B)]
    n = F.n_sel.values.astype(int); Tb = np.stack([rank[i] < n[k] for k, i in enumerate(test_i)]); Tdf = evaluate(Tb, test_i)
    dup = newp = 0; imp_q = 0
    for k, i in enumerate(test_i):
        if F.ndcg.values[k] <= Tdf.ndcg.values[k]: continue
        imp_q += 1; q = Q[i]
        def top10(M): s = np.where(M)[0]; return s[np.argsort(-ce[i, s], kind='stable')[:10]]
        tf, tt = top10(Mf[k]), top10(Tb[k]); pas_tt = set().union(*[pas[(q, cid[i, j])] for j in tt if gold[i, j]] or [set()])
        for j in set(tf) - set(tt):
            if gold[i, j]:
                if pas[(q, cid[i, j])] <= pas_tt: dup += 1
                else: newp += 1
    better_than_full = (F.ndcg_dedup.values > full.ndcg_dedup.values).mean(); worse = (F.ndcg_dedup.values < full.ndcg_dedup.values).mean()
    dec.append(dict(B=B, mean_S=F.n_sel.mean(), raw_ndcg_free=F.ndcg.mean(), raw_ndcg_topB_sameS=Tdf.ndcg.mean(),
                    dedup_ndcg_free=F.ndcg_dedup.mean(), dedup_ndcg_topB_sameS=Tdf.ndcg_dedup.mean(), dedup_ndcg_full=full.ndcg_dedup.mean(), raw_ndcg_full=full.ndcg.mean(),
                    improved_queries=imp_q, new_gold_chunks_dup_passage=dup, new_gold_chunks_new_passage=newp,
                    frac_q_dedup_better_than_full=better_than_full, frac_q_dedup_worse_than_full=worse))
dec = pd.DataFrame(dec); dec.to_csv(f'{OUT}/c1free_decomposition_test.csv', index=False); log('\n' + dec.round(4).to_string(index=False))

# e2e용 저장 (작은 파일)
json.dump(dict(env=env_info(), HP=HP, split_seed=SPLIT_SEED, m1_cols=M1NOPOS_COLS, n_test=len(test_i), n_dev=len(dev_i),
               ans_eval_test=int(ans_eval[test_i].sum()), headroom_test=int(hr_t.sum()),
               cmd='cd /workspace/jaeeun/sel_fetch_v2 && source sel_fetch/env.sh && python -I scripts_v2/s4_offline.py'),
          open(f'{OUT}/config.json', 'w'), indent=1, ensure_ascii=False, default=float)
import joblib; joblib.dump(m1, f'{OUT}/m1nopos_dev.joblib')
for B in BS: per[('TopB', B)]  # noqa
pd.concat([df.assign(method=nm, B=B) for (nm, B), df in per.items()]).to_csv(f'{OUT}/test_per_query.csv.gz', index=False)
pd.concat([topcurve[b].assign(B=b) for b in range(1, 101)]).to_csv(f'{OUT}/test_topB_curve_per_query.csv.gz', index=False)
log('ALL DONE')
