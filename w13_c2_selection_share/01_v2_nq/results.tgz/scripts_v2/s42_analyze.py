# s42_analyze.py: 4-2 결과 분석 - 구간 분해, A/A 잡음, 같은 품질 비교, 손익분기, 그림
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
OUT = f'{R}/s42'
d = pd.read_csv(f'{OUT}/e2e_raw.csv'); d = d[~d.warmup]
d['cfg'] = d.method + '@' + d.B.astype(str)
SEG = ['embed', 'ann', 'select', 'fetch', 'rerank', 'other']
summ = d.groupby(['phase', 'cfg']).agg(n=('total', 'size'), n_sel=('n_sel', 'mean'), blocks=('blocks', 'mean'), ios=('ios', 'mean'),
                                       p50=('total', 'median'), p95=('total', lambda x: x.quantile(.95)), p99=('total', lambda x: x.quantile(.99)),
                                       **{f'{s}_mean': (s, 'mean') for s in SEG}, total_mean=('total', 'mean'), ann_match=('ann_match', 'mean')).reset_index()
for s in SEG: summ[f'{s}_share'] = summ[f'{s}_mean'] / summ.total_mean
summ.to_csv(f'{OUT}/e2e_summary.csv', index=False)
def paired(phase, a, b, col='total'):
    x = d[(d.phase == phase) & (d.cfg == a)].set_index('q_idx')[col]; y = d[(d.phase == phase) & (d.cfg == b)].set_index('q_idx')[col]
    k = x.index.intersection(y.index); return paired_boot((x[k] - y[k]).values)
rows = []; delta = {}
for ph in ('warm', 'cold'):
    m, lo, hi = paired(ph, 'TopB-AA@30', 'TopB@30'); delta[ph] = max(abs(lo), abs(hi))
    rows.append(dict(phase=ph, comparison='A/A: TopB-AA@30 - TopB@30', seg='total', diff_ms=m, lo=lo, hi=hi, delta=delta[ph]))
    for x in ('M1-noPos@20', 'A1@20', 'B1@20', 'TopB@20'):
        for base in ('TopB@30',):
            for seg in ('total', 'select', 'fetch', 'rerank'):
                m, lo, hi = paired(ph, x, base, seg); rows.append(dict(phase=ph, comparison=f'{x} - {base}', seg=seg, diff_ms=m, lo=lo, hi=hi, delta=delta[ph]))
    for x in ('M1-noPos@20', 'A1@20', 'B1@20'):
        for seg in ('total', 'select', 'fetch', 'rerank'):
            m, lo, hi = paired(ph, x, 'TopB@20', seg); rows.append(dict(phase=ph, comparison=f'{x} - TopB@20', seg=seg, diff_ms=m, lo=lo, hi=hi, delta=delta[ph]))
    for x in ('M1-noPos@30', 'A1@30', 'B1@30'):
        m, lo, hi = paired(ph, x, 'TopB@30'); rows.append(dict(phase=ph, comparison=f'{x} - TopB@30', seg='total', diff_ms=m, lo=lo, hi=hi, delta=delta[ph]))
cmp_ = pd.DataFrame(rows)
def verdict(r):
    if r.seg != 'total' or r.comparison.startswith('A/A'): return ''
    if (r.lo <= 0 <= r.hi) or abs(r.diff_ms) < r.delta: return 'no difference'
    return 'faster' if r.diff_ms < 0 else 'slower'
cmp_['verdict'] = cmp_.apply(verdict, axis=1); cmp_.to_csv(f'{OUT}/e2e_paired.csv', index=False)
# 같은 품질 표 (오프라인 test 품질과 결합)
q = pd.read_csv(f'{R}/s4/test_summary.csv'); q['cfg'] = q.method + '@' + q.B.astype(str)
qual = summ.merge(q[['cfg', 'ndcg_dedup', 'ans', 'prom_recovery']], on='cfg', how='left')
qual.to_csv(f'{OUT}/e2e_with_quality.csv', index=False)
# 손익분기: cold fetch ms/블록 회귀
c = d[d.phase == 'cold']; slope = np.polyfit(c.blocks, c.fetch, 1)
json.dump(dict(delta_ms=delta, cold_fetch_ms_per_block=float(slope[0]), cold_fetch_intercept=float(slope[1])), open(f'{OUT}/e2e_noise_breakeven.json', 'w'), indent=1)
pd.set_option('display.width', 250)
print(summ[['phase', 'cfg', 'n_sel', 'blocks', 'ios', 'p50', 'p95', 'p99', 'total_mean'] + [f'{s}_mean' for s in SEG] + ['fetch_share', 'rerank_share', 'ann_match']].round(3).to_string(index=False))
print(cmp_.round(3).to_string(index=False)); print('delta', delta, 'cold ms/block', slope)
# 그림: 구간 분해
fig, ax = plt.subplots(1, 2, figsize=(15, 5), sharey=True)
COLS = {'embed': '#bbbbbb', 'ann': '#8c564b', 'select': '#d62728', 'fetch': '#ff7f0e', 'rerank': '#1f77b4', 'other': '#2ca02c'}
order = ['TopB@20', 'TopB@30', 'TopB-AA@30', 'M1-noPos@20', 'M1-noPos@30', 'A1@20', 'A1@30', 'B1@20', 'B1@30']
for a, ph in zip(ax, ('warm', 'cold')):
    s = summ[summ.phase == ph].set_index('cfg').loc[order]; bot = np.zeros(len(s))
    for seg in SEG:
        a.bar(range(len(s)), s[f'{seg}_mean'], bottom=bot, color=COLS[seg], label=seg); bot += s[f'{seg}_mean'].values
    a.set_xticks(range(len(s))); a.set_xticklabels(order, rotation=40, ha='right', fontsize=8); a.set_title(f'{ph} (mean ms per query, n=300)'); a.grid(axis='y', alpha=.3)
ax[0].set_ylabel('ms'); ax[0].legend(fontsize=8)
plt.tight_layout(); plt.savefig(f'{OUT}/fig_e2e_breakdown.png', dpi=110); print('saved fig')
