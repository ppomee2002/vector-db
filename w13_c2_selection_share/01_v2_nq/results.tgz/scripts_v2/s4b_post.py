# s4b_post.py: s4 결과 후처리 - 방법 간 직접 비교(A1/B1 vs M1-noPos), 그림 (비용-품질 곡선)
import sys, os, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
OUT = f'{R}/s4'
per = pd.read_csv(f'{OUT}/test_per_query.csv.gz'); cur = pd.read_csv(f'{OUT}/test_topB_curve_per_query.csv.gz')
qr = pd.read_csv(f'{D}/qrels_chunk.tsv', sep='\t'); rr = load_rr(); sp = split_B()
Q = np.unique(rr.q_idx); sh = (len(Q), 100); rank = rr['rank'].values.reshape(sh)
gold = np.array([[c in s for c in row] for row, s in zip(rr.chunk_id.values.reshape(sh), [set(qr[qr.q_idx == q].chunk_id) for q in Q])])
hr_all = gold.any(1) & ~(gold & (rank < 20)).any(1)
# 1) 직접 비교
rows = []
for B in (10, 15, 20, 30):
    g = {m: per[(per.method == m) & (per.B == B)].sort_values('qi') for m in ('M1-noPos', 'A1', 'B1')}
    for m in ('A1', 'B1'):
        for metric in ('ndcg_dedup', 'ans', 'ndcg'):
            a, b = g[m][metric].values, g['M1-noPos'][metric].values; ok = ~np.isnan(a) & ~np.isnan(b)
            mm, lo, hi = paired_boot(a[ok] - b[ok]); rows.append(dict(B=B, method=m, vs='M1-noPos', metric=metric, diff=mm, lo=lo, hi=hi))
pd.DataFrame(rows).to_csv(f'{OUT}/test_direct_vs_M1.csv', index=False)
print(pd.DataFrame(rows).round(4).to_string(index=False))
# 2) 그림
COL = {'M1-noPos': '#d62728', 'A1': '#2ca02c', 'B1': '#1f77b4', 'A2': '#9467bd', 'Random-deep': '#7f7f7f', 'C1free(ref)': '#ff7f0e', 'B2': '#17becf'}
fig, ax = plt.subplots(2, 3, figsize=(16, 9))
for r_, (sub, qmask) in enumerate((('all test (n=1726)', None), ('headroom: gold in Top-100, not in Top-20', hr_all))):
    for c_, (metric, xk, xl) in enumerate((('ndcg_dedup', 'n_sel', 'Rerank candidates |S|'), ('ans', 'n_sel', 'Rerank candidates |S|'), ('ndcg_dedup', 'blocks', 'C1 4KB blocks read'))):
        a = ax[r_, c_]
        def f(df):
            if qmask is None: return df
            return df[df.qi.map(lambda i: hr_all[i])]
        t = f(cur).groupby('B').agg(x=(xk, 'mean'), y=(metric, 'mean')).reset_index(); t = t[t.B <= 60]
        a.plot(t.x, t.y, 'k-', lw=1.5, label='Top-B');
        for m, col in COL.items():
            d = f(per[per.method == m]).groupby('B').agg(x=(xk, 'mean'), y=(metric, 'mean')).reset_index()
            a.plot(d.x, d.y, 'o-' if len(d) > 1 else 's', color=col, label=m, ms=5)
        a.set_xlabel(xl); a.set_ylabel({'ndcg_dedup': 'passage-dedup nDCG@10', 'ans': 'answer-string hit (final 10)'}[metric]); a.set_title(sub, fontsize=9); a.grid(alpha=.3)
ax[0, 0].legend(fontsize=8)
plt.tight_layout(); plt.savefig(f'{OUT}/fig_cost_quality.png', dpi=110); print('saved fig')
