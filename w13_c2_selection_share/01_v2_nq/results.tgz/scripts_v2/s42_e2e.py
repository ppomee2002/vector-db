# s42_e2e.py: 4-2단계 End-to-end 지연시간 (질문 → 임베딩 → Milvus ANN → 선별 → C1 Fetch → Rerank → Context 10개)
# 실행: CUDA_VISIBLE_DEVICES=0 nohup python -I scripts_v2/s42_e2e.py > results_v2/s42/e2e.log 2>&1 &
import sys, os, json, time, mmap, threading, subprocess, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
import torch, joblib
from sentence_transformers import CrossEncoder, SentenceTransformer
from pymilvus import MilvusClient
torch.set_num_threads(4)
OUT = f'{R}/s42'; os.makedirs(OUT, exist_ok=True)
NQ_MEAS, NWARM = (6, 3) if os.environ.get('SMOKE') else (300, 30)
if os.environ.get('SMOKE'): OUT = f'{OUT}/smoke'; os.makedirs(OUT, exist_ok=True)
HP = json.load(open(f'{R}/s4/chosen_hp.json')); m1 = joblib.load(f'{R}/s4/m1nopos_dev.joblib')
docarr, cix, nbarr, off = load_meta(); doc_len = np.bincount(docarr); NCH = len(docarr)
Vall = np.load(f'{J}/chunk_vecs.npy', mmap_mode='r')
qs = [json.loads(l)['text'] for l in open(f'{J}/queries.jsonl', encoding='utf-8')][:NQ_REAL]
sp = split_B(); dev = np.sort(sp[sp.split == 'dev'].q_idx.values)
qsel = np.random.default_rng(7).choice(dev, NQ_MEAS + NWARM, replace=False)
stored = load_rr(); stored_top = {q: g.sort_values('rank').chunk_id.values for q, g in stored[stored.q_idx.isin(qsel)].groupby('q_idx')}

# ---------- 선별 함수 (온라인, numpy) ----------
def feats_m1nopos(cid, sc, V):
    """common.add_features와 같은 공식 (위치 피처 제외), 질문 1개분."""
    n = len(cid); rk = np.arange(n, dtype=float); d = docarr[cid]; s1 = sc.max()
    F = {'f_rank': rk, 'f_score': sc, 'f_gap_top1': s1 - sc, 'f_rel_score': sc / s1, 'f_z': (sc - sc.mean()) / (sc.std(ddof=1) + 1e-6),
         'f_q_s1': np.full(n, s1), 'f_q_gap10': np.full(n, s1 - sc[9])}
    u, inv = np.unique(d, return_inverse=True); cnt = np.bincount(inv); top10 = np.bincount(inv, rk < 10)
    best = np.full(len(u), 1e9); np.minimum.at(best, inv, rk); ssum = np.bincount(inv, sc)
    within = np.zeros(n); seen = {}
    for j in range(n): within[j] = seen.get(inv[j], 0); seen[inv[j]] = within[j] + 1
    pos = {c: j for j, c in enumerate(cid)}; nbb = np.full(n, 200.0); nbin = np.zeros(n)
    for j, c in enumerate(cid):
        for o in (-1, 1):
            k = c + o
            if 0 <= k < NCH and docarr[k] == d[j] and k in pos: nbb[j] = min(nbb[j], pos[k]); nbin[j] = 1
    F.update({'f_doc_hits': cnt[inv], 'f_doc_hits_top10': top10[inv], 'f_doc_best_rank': best[inv], 'f_doc_score_sum': ssum[inv],
              'f_doc_rank_within': within, 'f_nb_in_cand': nbin, 'f_nb_best_rank': nbb})
    S = V @ V.T; np.fill_diagonal(S, np.nan)
    low = np.tri(n, k=-1, dtype=bool); mh = np.where(low, S, -np.inf).max(1); mh[0] = 0
    F.update({'f_cen10': np.nanmean(S[:, :10], 1), 'f_maxsim_higher': mh, 'f_sim_top1': np.nan_to_num(S[:, 0], nan=1.0),
              'f_meansim': np.nanmean(S, 1), 'f_nbytes': nbarr[cid].astype(float)})
    return pd.DataFrame({c: F[c] for c in M1NOPOS_COLS})
def sel_topk(cid, sc, B, **k): return np.arange(B)
def sel_m1(cid, sc, B, **k):
    V = np.asarray(Vall[cid], dtype=np.float32); p = m1.predict_proba(feats_m1nopos(cid, sc, V))[:, 1]
    return np.argsort(-p, kind='stable')[:B]
def sel_a1(cid, sc, B, **k):
    x = int(round(HP['A1']['alpha'] * B)); M = np.arange(100) < B - x; d = docarr[cid]
    u, inv = np.unique(d, return_inverse=True); smax = np.full(len(u), -9.0); np.maximum.at(smax, inv, sc); cnt = np.bincount(inv)
    dsc = (np.bincount(inv, sc) if HP['A1']['agg'] == 'sum' else smax * np.log1p(cnt))[inv]
    cand = np.where(~M)[0]; o = np.lexsort((-sc[cand], -dsc[cand])); M[cand[o[:x]]] = True; return np.where(M)[0]

# ---------- Fetch (C1) ----------
fd_dir = os.open(STORE, os.O_RDONLY | os.O_DIRECT); fd_buf = os.open(STORE, os.O_RDONLY)
BUF = mmap.mmap(-1, 8 << 20); MV = memoryview(BUF)
def c1_fetch(cids, direct):
    s = off[cids]; e = off[cids + 1]; bl = np.unique(np.concatenate([np.arange(a // BLK, (b - 1) // BLK + 1) for a, b in zip(s, e)]))
    cuts = np.where(np.diff(bl) > 1)[0]; st = np.r_[bl[0], bl[cuts + 1]]; en = np.r_[bl[cuts], bl[-1]]
    pos = 0; ext = []
    for a, b in zip(st, en):
        L = int(b - a + 1) * BLK
        if direct: os.preadv(fd_dir, [MV[pos:pos + L]], int(a) * BLK)
        else: BUF[pos:pos + L] = os.pread(fd_buf, L, int(a) * BLK).ljust(L, b'\0')
        ext.append((int(a) * BLK, pos, L)); pos += L
    texts = []
    for a, b in zip(s, e):
        for fo, bo, L in ext:
            if fo <= a and b <= fo + L: texts.append(bytes(MV[bo + a - fo: bo + b - fo]).decode('utf-8')); break
    return texts, len(bl), len(st)

# ---------- 파이프라인 ----------
ce = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2', device='cuda', max_length=256)
emb = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2', device='cuda')
def sync(): torch.cuda.synchronize()
def run_query(cl, q, method, B, direct):
    T = {}; t = time.perf_counter()
    qv = emb.encode([qs[q]], normalize_embeddings=True); sync(); T['embed'] = time.perf_counter() - t
    t = time.perf_counter()
    res = cl.search('nq1m_sel', data=qv.tolist(), limit=100, search_params={'metric_type': 'IP', 'params': {'ef': 256}})[0]
    cid = np.array([h['id'] if 'id' in h else h['pk'] for h in res], dtype=np.int64); sc = np.array([h['distance'] for h in res], dtype=np.float32)
    T['ann'] = time.perf_counter() - t
    T['select'] = T['fetch'] = T['rerank'] = 0.0; blocks = ios = 0
    if method == 'B1':     # 반복 피드백: 10개씩
        S = np.arange(10); ces = np.full(100, -np.inf); V = None
        while True:
            new = S[np.isinf(ces[S])]
            t = time.perf_counter(); txt, b_, e_ = c1_fetch(cid[new], direct); T['fetch'] += time.perf_counter() - t; blocks += b_; ios += e_
            t = time.perf_counter(); ces[new] = ce.predict([(qs[q], x) for x in txt], batch_size=128, show_progress_bar=False); sync(); T['rerank'] += time.perf_counter() - t
            if len(S) >= B: break
            t = time.perf_counter()
            if V is None: V = np.asarray(Vall[cid], dtype=np.float32)
            top3 = S[np.argsort(-ces[S])[:3]]; be, ga = HP['B1']['beta'], HP['B1']['gamma']
            f = (1 - be) * sc + be * (V @ V[top3].T).max(1) + ga * np.isin(docarr[cid], docarr[cid[top3]]); f[S] = -np.inf
            S = np.r_[S, np.argsort(-f, kind='stable')[:min(10, B - len(S))]]; T['select'] += time.perf_counter() - t
    else:
        t = time.perf_counter(); S = {'TopB': sel_topk, 'M1-noPos': sel_m1, 'A1': sel_a1}[method](cid, sc, B); T['select'] = time.perf_counter() - t
        t = time.perf_counter(); txt, blocks, ios = c1_fetch(cid[S], direct); T['fetch'] = time.perf_counter() - t
        t = time.perf_counter(); ces = np.full(100, -np.inf); ces[S] = ce.predict([(qs[q], x) for x in txt], batch_size=128, show_progress_bar=False); sync(); T['rerank'] = time.perf_counter() - t
    t = time.perf_counter(); final = cid[np.argsort(-ces, kind='stable')[:10]]; ctx = [int(c) for c in final]; T['other'] = time.perf_counter() - t
    T['total'] = sum(T.values())
    ann_match = len(set(cid.tolist()) & set(stored_top[q].tolist())) / 100
    return {k: v * 1e3 for k, v in T.items()}, blocks, ios, len(S), ann_match, ctx

CONFIGS = [('TopB', 20), ('TopB', 30), ('TopB', 30, 'AA'), ('M1-noPos', 20), ('M1-noPos', 30), ('A1', 20), ('A1', 30), ('B1', 20), ('B1', 30)]
# ---------- 모니터 (1초 간격 GPU/CPU) ----------
stop = threading.Event()
def monitor():
    with open(f'{OUT}/monitor.csv', 'w') as f:
        f.write('ts,load1,gpu0_util,gpu0_mem,gpu1_util,gpu1_mem\n')
        while not stop.is_set():
            g = subprocess.run(['nvidia-smi', '--query-gpu=utilization.gpu,memory.used', '--format=csv,noheader,nounits'], capture_output=True, text=True).stdout.split('\n')
            g0 = g[0].split(', ') if g and g[0] else ['', '']; g1 = g[1].split(', ') if len(g) > 1 and g[1] else ['', '']
            f.write(f'{time.time():.1f},{os.getloadavg()[0]:.2f},{g0[0]},{g0[1]},{g1[0]},{g1[1]}\n'); f.flush(); time.sleep(1)
th = threading.Thread(target=monitor, daemon=True); th.start()
log('before: uptime', os.popen('uptime').read().strip()); log('before: nvidia-smi', os.popen('nvidia-smi --query-gpu=index,memory.used,utilization.gpu --format=csv,noheader').read().strip().replace('\n', ' | '))
cl = MilvusClient(uri='http://localhost:19530', db_name='jaeeun')
rows = []
try:
    log('load state before', cl.get_load_state('nq1m_sel')); t = time.time(); cl.load_collection('nq1m_sel'); log(f'loaded in {time.time()-t:.1f}s', cl.get_load_state('nq1m_sel'))
    for phase, direct in (('warm', False), ('cold', True)):
        if phase == 'warm':   # page cache 예열: 측정 질문들의 Top-100 블록을 한 번 읽음
            for q in qsel: c1_fetch(stored_top[q], False)
        for k, q in enumerate(qsel):
            order = CONFIGS[k % len(CONFIGS):] + CONFIGS[:k % len(CONFIGS)]   # 질문마다 순환 (Latin square)
            for cf in order:
                T, blk, io_, nS, am, ctx = run_query(cl, q, cf[0], cf[1], direct)
                rows.append(dict(phase=phase, warmup=k < NWARM, q_idx=int(q), method=cf[0] + ('-AA' if len(cf) > 2 else ''), B=cf[1], slot=order.index(cf),
                                 n_sel=nS, blocks=blk, ios=io_, ann_match=am, **T))
            if (k + 1) % 50 == 0: log(phase, k + 1, '/', len(qsel))
finally:
    cl.release_collection('nq1m_sel'); log('released', cl.get_load_state('nq1m_sel')); cl.close()
    stop.set(); th.join(timeout=3)
    pd.DataFrame(rows).to_csv(f'{OUT}/e2e_raw.csv', index=False)
log('after: uptime', os.popen('uptime').read().strip())
json.dump(dict(env=env_info(), torch=torch.__version__, gpu=torch.cuda.get_device_name(0), HP=HP, n_meas=NQ_MEAS, n_warm=NWARM, seed_q=7,
               configs=[list(c) for c in CONFIGS], fetch='C1 extents; warm=buffered pread after prewarm, cold=O_DIRECT (loop dio=1)',
               milvus='nq1m_sel HNSW ef=256, warm only (reclaim not run: needs user approval)', vectors='local mmap /workspace/junlim/data_nq/chunk_vecs.npy',
               cmd='CUDA_VISIBLE_DEVICES=0 python -I scripts_v2/s42_e2e.py'), open(f'{OUT}/config.json', 'w'), indent=1, ensure_ascii=False)
log('ALL DONE')
