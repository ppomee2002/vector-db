# s1b_same_rerank.py: 1단계 보충 - Rerank 비용이 지배적(c)이므로 "같은 Rerank 대상 수(|S|)" 기준 비교
#   Top-B+free(C1 블록 안 공짜 후보 추가) 와 M1-noPos 를 같은 |S|의 Top-B와 비교 (dev, paired bootstrap)
import sys, os, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *
OUT = f'{R}/s1'
docarr, cix, nb, off = load_meta(); sp = split_B(); dev_q = set(sp[sp.split == 'dev'].q_idx)
rr = load_rr(); dv = rr[rr.q_idx.isin(dev_q)].reset_index(drop=True)
qr = pd.read_csv(f'{D}/qrels_chunk.tsv', sep='\t'); qrels = qr.groupby('q_idx').chunk_id.apply(set).to_dict()
EV = Evaluator(dv, off, qrels); nq = len(EV.q)
topb = {B: EV.eval_mask(EV.rank < B, with_cost=False) for B in range(1, 101)}
def topB_at(n_sel, metric):
    """질문별 |S|=n (실수)에 맞춰 Top-floor(n), Top-ceil(n)을 선형 혼합."""
    lo = np.clip(np.floor(n_sel).astype(int), 1, 100); hi = np.clip(lo + 1, 1, 100); w = n_sel - lo
    A = np.stack([topb[b][metric].values for b in range(1, 101)], 1)
    i = np.arange(nq); return (1 - w) * A[i, lo - 1] + w * A[i, hi - 1]
gold_hr = (EV.gold.any(1) & ~(EV.gold & (EV.rank < 20)).any(1))   # 정답이 Top-100에 있으나 Top-20 밖
rows = []
for B in (5, 10, 15, 20, 30):
    M = EV.rank < B; Mf = M.copy()
    for i in range(nq):
        bl = set()
        for a, b in zip(EV.b0[i, M[i]], EV.b1[i, M[i]]): bl.update(range(a, b + 1))
        for j in np.where(~M[i])[0]:
            if all(x in bl for x in range(EV.b0[i, j], EV.b1[i, j] + 1)): Mf[i, j] = True
    fr = EV.eval_mask(Mf, with_cost=False); n = fr.n_sel.values.astype(float)
    for metric in ('ndcg10', 'hit10', 'retained'):
        ref = topB_at(n, metric); d = fr[metric].values - ref
        m_, l_, h_ = paired_boot(d); mh, lh, hh = paired_boot(d[gold_hr])
        rows.append(dict(B=B, mean_S=n.mean(), metric=metric, free=fr[metric].mean(), topB_sameS=ref.mean(),
                         diff=m_, lo=l_, hi=h_, diff_goldHR=mh, lo_goldHR=lh, hi_goldHR=hh, n_goldHR=int(gold_hr.sum())))
out = pd.DataFrame(rows); out.to_csv(f'{OUT}/s1b_free_vs_topB_sameS_dev.csv', index=False)
pd.set_option('display.width', 250); print(out.round(4).to_string(index=False))
